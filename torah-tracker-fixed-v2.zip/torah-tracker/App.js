// App.js
import React, { useEffect, useState } from 'react';
import { View, I18nManager, StyleSheet, AppState } from 'react-native';
import { initDatabase } from './src/database/db';
import { runRolloverIfNeeded, startMidnightScheduler } from './src/services/rollover';
import { FocusModeProvider } from './src/context/FocusModeContext';
import { GoogleAuthProvider } from './src/context/GoogleAuthContext';
import RootNavigator from './src/navigation/RootNavigator';
import colors from './src/theme/colors';

import {
  requestNotificationPermissions, configureNotificationHandler,
} from './src/services/notifications/notificationSetup';
import { registerEveningNotificationDeliveryListener } from './src/services/notifications/notificationListeners';
import { registerBackgroundTask } from './src/services/notifications/backgroundTask';
import { refreshEveningNotification } from './src/services/notifications/eveningScheduler';

I18nManager.forceRTL(true);

// Configuring the foreground handler must happen at module scope (not
// inside a component effect) so it's active before any notification
// could possibly be delivered.
configureNotificationHandler();

export default function App() {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let stopScheduler;
    let removeDeliveryListener;

    (async () => {
      await initDatabase();
      // Covers "first app launch of a new calendar day", including the
      // case where the device was asleep/closed through midnight.
      await runRolloverIfNeeded();
      setReady(true);
      // Covers the app being left open across midnight.
      stopScheduler = startMidnightScheduler();

      // Notifications: ask permission, wire up delivery tracking, register
      // the best-effort background re-check task, then do an initial
      // evening-notification refresh so today's schedule is correct from
      // the moment the app opens.
      const granted = await requestNotificationPermissions();
      removeDeliveryListener = registerEveningNotificationDeliveryListener();
      if (granted) {
        await registerBackgroundTask();
        await refreshEveningNotification();
      }
    })();

    // Also re-check on foreground, in case the OS killed the midnight
    // timer while backgrounded (mobile OSes routinely suspend timers).
    const sub = AppState.addEventListener('change', async (state) => {
      if (state === 'active') {
        await runRolloverIfNeeded();
        await refreshEveningNotification();
      }
    });

    return () => {
      stopScheduler?.();
      removeDeliveryListener?.();
      sub.remove();
    };
  }, []);

  if (!ready) {
    return <View style={styles.loadingScreen} />;
  }

  return (
    <GoogleAuthProvider>
      <FocusModeProvider>
        <RootNavigator />
      </FocusModeProvider>
    </GoogleAuthProvider>
  );
}

const styles = StyleSheet.create({
  loadingScreen: {
    flex: 1,
    backgroundColor: colors.background,
  },
});
