# Torah Tracker — Phase 1: Infrastructure, Database, Data Models

Expo (React Native) project scaffold with a local SQLite database.

## Setup

```bash
npm install
npx expo start
```

## What's included

**Theme** (`src/theme/`)
- `colors.js` — calm pastel/earth/mint/deep-blue palette. Overdue items use a
  gentle gray (`colors.overdue`), never red.
- `fonts.js` — classic, Hebrew-friendly typography (Frank Ruhl Libre for
  headings/quotes, Assistant for body text). Add the actual font files under
  `assets/fonts/` and load them via `expo-font` in `App.js`.

**Database** (`src/database/db.js`)
- SQLite schema with two core tables:
  - `topics (id, name, icon, type ['fixed'|'flexible'], sort_order)`
  - `tasks (id, topic_id, date, status ['completed'|'pending'|'overdue'], note_text)`
    with a `UNIQUE(topic_id, date)` constraint (one task row per topic per day).
  - `kv_store (key, value)` — small generic table used for caching the
    daily quote.
- On first run, seeds the 5 mandatory topics from `src/data/topics.seed.js`:
  גמרא (דף יומי), משנה ברורה, עץ חיים, תהילים, זוהר.

**Models** (`src/models/`)
- `Topic.js` — CRUD helpers. Deletion is blocked for `type: 'fixed'` topics.
- `Task.js` — get-or-create today's task per topic, update status/notes,
  and `markPastPendingAsOverdue()` to sweep stale `pending` rows to `overdue`.

**Daily quote** (`src/data/quotes.js`, `src/utils/dailyQuote.js`)
- 6 Hebrew quotes in a plain array.
- `getDailyQuote()` picks one at random and caches the choice (date + index)
  in `kv_store`, so it stays stable all day and only rerolls after local
  midnight. `msUntilNextMidnight()` is used to schedule an in-app refresh
  if the app is left open overnight.

## Phase 2 — Main Dashboard (UI & Core Interactions)

**Header** (`src/components/DashboardHeader.js`)
- Daily quote centered at the top, sourced from Phase 1's `getDailyQuote()`.
- Dual date line below it — Hebrew/Jewish calendar date (via `@hebcal/core`,
  `src/utils/dateFormat.js`) and Gregorian date, both rendered in Hebrew.
- Bell icon in the top corner toggles Focus/DND mode
  (`src/context/FocusModeContext.js`), a boolean persisted to `kv_store` via
  React Context so it survives app restarts and is available anywhere in
  the tree via `useFocusMode()`.

**Progress ring** (`src/components/ProgressRing.js`)
- Animated SVG ring (via `react-native-svg`) showing today's
  completed/total task ratio, pulled from `getTodayProgress()`
  (added to `src/models/Task.js`). Updates whenever the dashboard refreshes.

**Overdue alert** (`src/components/OverdueAlert.js`)
- Renders only when `getOverdueCount() > 0`. Uses a soft, low-opacity gray
  chip (`colors.overdue` at ~15% opacity) — never red — with the exact copy
  `יש לך X משימות להשלמה`.

**Schedule planner button** (`src/components/SchedulePlannerButton.js`)
- Full-width primary button, `תכנון לו"ז יומי 📅`. UI/styling only in this
  phase — `onPress` is wired up but intentionally a no-op until the
  drag-and-drop timeline phase.

**Topics grid** (`src/components/TopicsGrid.js`, `TopicCard.js`, `AddTopicCard.js`)
- Two-column grid of all topics as cards (icon + name), with a trailing
  dashed "+" card.
- Tapping "+" opens `AddTopicModal.js`, a bottom sheet with a name input,
  a horizontal icon picker (`src/theme/topicIcons.js`), and a Save button
  that calls `createTopic()` (Phase 1 model) and refreshes the grid
  immediately.

## Phase 3 — Drill-Down Screens and Micro-interactions

**Navigation** (`src/navigation/RootNavigator.js`)
- `@react-navigation/native` + native-stack. `App.js` now just initializes
  the database and renders the navigator inside `FocusModeProvider`.
- Tapping any `TopicCard` on the Dashboard calls
  `navigation.navigate('TopicDetails', { topicId, topicName })`.
- Dashboard listens for the screen `focus` event to re-run
  `refreshDashboardData()`, so progress/overdue counts stay correct after
  returning from a topic where something was checked off.

**Topic Details screen** (`src/screens/TopicDetailsScreen.js`)
- **ההספק להיום** — today's task for this topic
  (`getOrCreateTaskForToday(topicId)`).
- **חוסרים** — every task for this topic with `status = 'overdue'`, oldest
  first (new `getOverdueTasksForTopic(topicId)` on the Task model). Shows a
  calm empty state when there's nothing outstanding.

**Circular checkbox** (`src/components/CircularCheckbox.js`)
- Large, round, custom-drawn. Tapping plays a two-step animation: the
  circle fills with the mint accent color, then an SVG checkmark "draws"
  itself via an animated `strokeDashoffset`, with a light fade-in — all on
  `Easing.out` curves, no bounce/overshoot/confetti, ~200–260ms each step.

**Hybrid note input** (`src/components/TaskEntryRow.js`)
- Pairs the checkbox with a semi-transparent, optional `TextInput` bound to
  `note_text`. Typing works independently of the checkbox — text can be
  entered before or after checking the box. Toggling the box saves the
  current note text and new status together
  (`toggleTaskCompletion` in `Task.js`); editing the note alone (blur)
  saves it via `updateTaskNote` without touching status.

## Phase 4 — End-of-Day Rollover Logic and Automatic Task Generation

**Rollover service** (`src/services/rollover.js`)
- `runRolloverIfNeeded(now)` — idempotent, guarded by a `last_rollover_date`
  key in `kv_store` so it only actually does work once per calendar day no
  matter how often it's called:
  1. `markPastPendingAsOverdue()` — migrates any `pending` task dated
     before today to `overdue` (Phase 1 model function).
  2. `generateTodaysTasks()` — creates today's task row for every topic
     via the new `ensureTaskForTopicAndDate()` (Task model), which only
     inserts if the row doesn't already exist and never overwrites one
     that does.
  3. Emits a `rollover complete` event on `rolloverBus.js`.
- `startMidnightScheduler()` — a self-rescheduling `setTimeout` aimed at
  the next local midnight, so an app left open overnight rolls over live.
- `App.js` calls `runRolloverIfNeeded()` once on launch (covers "first
  launch of a new day," including after the device was off through
  midnight), starts the scheduler, and also re-checks on every
  `AppState` → `active` transition, since mobile OSes routinely suspend
  JS timers while backgrounded.

**Global-cycle topics** (Daf Yomi, Tehillim)
- `topics` gained a `sync_source` column (migrated safely for existing
  installs via `PRAGMA table_info` + `ALTER TABLE`). Gemara is seeded with
  `sync_source: 'daf_yomi'`, Tehillim with `'tehillim_cycle'`.
- `src/services/dailyLabelGenerators.js` is a small registry mapping a
  `sync_source` key to an `async (date) => label` function, looked up by
  the rollover service when creating that topic's task for the day and
  stored as the task's initial `note_text`.
- `src/utils/dafYomi.js` — resolves today's Daf Yomi page. Tries Sefaria's
  public calendar API first (authoritative); falls back to a local cycle
  calculation (cycle start 11 Sep 1923, standard Vilna Shas daf counts) if
  the device is offline.
- `src/utils/tehillimCycle.js` — the standard 30-day monthly Tehillim
  division, keyed by Hebrew-calendar day-of-month via `@hebcal/core`.
- Adding a new global-sync topic later just means writing one generator
  function and registering its key — no changes needed elsewhere.

**Live UI refresh without restart** (`src/services/rolloverBus.js`)
- A minimal pub-sub. `DashboardScreen` and `TopicDetailsScreen` both
  subscribe and re-fetch their data the instant a rollover fires, so
  progress rings, the overdue alert, and the "חוסרים" list all update on
  their own — no manual app restart required.

## Phase 5 — Visual Time-Blocking Schedule (Drag & Drop)

Built entirely on core React Native (`PanResponder` + `Animated`) — no
`react-native-gesture-handler` / `reanimated` dependency added, to keep the
Expo setup simple.

**Schema** — `schedule_items` table (`src/database/db.js`): one row per
item that has appeared in the planner, either still unplaced
(`start_minute IS NULL`, shown in the Task Bank) or placed on the timeline.
`kind` is `'study'` (linked to a `tasks` row via `task_id`) or `'custom'`
(a general activity added via the "+" button). Model in
`src/models/ScheduleItem.js`.

**Navigation**: the Dashboard's planner button now navigates to a new
`Schedule` screen (`src/screens/ScheduleScreen.js`).

**Task Bank** (`src/components/schedule/TaskBank.js`, `TaskBankCard.js`)
- Horizontal scrollable list of today's pending study tasks not yet
  placed on the timeline, plus unplaced custom activities.
- The "+" button opens `AddActivityModal.js` (name + icon picker) to add
  a general non-study activity into the bank.
- Each card is draggable: long-press (~260ms) arms the drag, then moving
  your finger drags a floating ghost (`DragGhost.js`) across the screen.

**Hourly Timeline** (`src/components/schedule/HourlyTimeline.js`)
- Vertical scrollable hour grid, 06:00–23:00 (`timelineConstants.js`).
- Registers itself as a drop zone with the shared `DragContext`
  (`src/context/DragContext.js`); on drop, converts the touch's screen
  position into a snapped (5-minute) timeline minute.

**Duration modal** (`src/components/schedule/DurationModal.js`)
- Pops up immediately after a drop: quick-select 15/30/45/60 minutes, or
  a custom manual minute entry. Confirming calls `placeItem()`, which
  either inserts a new `schedule_items` row (study task's first
  placement) or updates an already-existing unplaced row (custom
  activity).

**Timeline blocks** (`src/components/schedule/TimelineBlock.js`)
- Rendered as solid cards spanning their duration. Drag the block body to
  move it (updates `start_minute`, duration fixed); drag the top handle
  to resize by moving the start time (bottom edge fixed); drag the
  bottom handle to resize duration (start fixed). All snapped to 5
  minutes, minimum 15-minute duration, clamped to the visible hours.

**Dashboard sync**
- `getNextUpcomingBlock()` (`ScheduleItem.js`) finds the next
  chronologically scheduled item for today relative to the current time.
- The Dashboard fetches it on load, on focus, on rollover, and every
  60 seconds, and swaps the planner button's label to
  `הבא: <title> ב-<HH:MM>` whenever one exists — otherwise it falls back
  to the default `תכנון לו"ז יומי 📅`.

**Known trade-off**: dragging a Task Bank card starts the moment you
touch it (after the long-press delay), which means you can't scroll the
Task Bank strip by swiping directly across a card — only through the
small gaps between cards. A production build would likely reach for
`react-native-gesture-handler`'s simultaneous-gesture handling to fully
resolve that; this phase keeps the dependency footprint minimal instead.

## Phase 6 — Two-Way Google Calendar Integration

⚠️ **Requires setup before it will work**: unlike earlier phases, this one
needs real credentials from your own Google Cloud project. See
"Required setup" below — until that's done, every sync call no-ops
quietly (the app works exactly as in Phase 5, just without calendar sync).

**OAuth 2.0** (`src/config/googleConfig.js`, `src/services/googleAuthService.js`,
`src/context/GoogleAuthContext.js`)
- PKCE authorization-code flow via `expo-auth-session`, requesting the
  `calendar.events` scope (read/write events, nothing broader).
- Tokens are persisted in `expo-secure-store` (`secureTokenStore.js`) —
  device keychain / Keystore, never plain storage.
- `ensureValidAccessToken()` transparently refreshes an expired access
  token using the stored refresh token before any API call; every sync
  function in the app calls this rather than touching tokens directly.
- `GoogleSyncBar.js` on the Schedule screen shows connect/disconnect
  status and drives `signIn()`/`signOut()`.

**Pull — read-only busy blocks** (`googleCalendarSync.fetchGoogleBusyBlocksForDate`)
- Fetches today's existing Google events and renders them via
  `GoogleEventBlock.js`: semi-transparent grey, dashed border, a lock
  icon, `pointerEvents="none"` so they never intercept a drop — pure
  visual context for avoiding overlaps.

**Push — study tasks create real events** (`googleCalendarSync.pushScheduledItemToGoogle`)
- Fires right after `DurationModal` confirms a placement in
  `ScheduleScreen.js`. Creates a timed event titled with the study
  topic's plain name (`schedule_items.calendar_title`, kept separate
  from the app's display title, which may include a note like "פרק ג'").
  The resulting Google event id is stored back on the `schedule_items`
  row (`google_event_id` column, added via migration).
- Moving or resizing a placed block (`syncBlockTimingToGoogle`) patches
  the linked event's start/end to match, so the two stay in sync in both
  directions.

**Completion sync** (`googleCalendarSync.syncTaskCompletionToGoogle`)
- Hooked into `TopicDetailsScreen`'s checkbox toggle handler. Looks up
  the `schedule_items` row for that task; if it has a `google_event_id`,
  patches the event's title to `<calendar_title> ✓` on completion, or
  back to the plain title if un-checked.

**Daily achievement event** (`googleCalendarSync.maybeCreateAchievementEvent`)
- Called every time the Dashboard recomputes progress. The moment
  `completed === total` (and `total > 0`), creates an all-day event
  titled exactly `הספקים הושלמו בהצלחה ✓` for today. Guarded by a
  `kv_store` flag (`achievement_event_created_<date>`) so it only ever
  fires once per day, no matter how many times progress is recomputed.

### Required setup

1. In [Google Cloud Console](https://console.cloud.google.com), create a
   project (or reuse one), enable the **Google Calendar API**, and
   configure the OAuth consent screen (Testing mode is fine — add your
   own Google account as a test user).
2. Create three OAuth client IDs under **Credentials**:
   - **iOS** — bundle ID must match `app.json`'s `ios.bundleIdentifier`
     (`com.example.torahtracker` — change this to your own before building).
   - **Android** — package must match `app.json`'s `android.package`,
     plus your debug/release signing certificate's SHA-1.
   - **Web application** — used for the Expo Go / dev-client flow; add
     `https://auth.expo.io/@your-expo-username/torah-tracker` as an
     authorized redirect URI.
3. Paste all three client IDs into `src/config/googleConfig.js`.
4. Run the app — the Schedule screen's "התחבר ל-Google Calendar" pill
   starts the sign-in flow.

## Phase 7 — Smart and Conditional Notifications

Built on `expo-notifications` + `expo-task-manager`/`expo-background-fetch`.
All logic funnels through one function, `refreshEveningNotification()`
(`src/services/notifications/eveningScheduler.js`), which is safe to call
as often as needed — app launch, foreground, rollover, a task being
toggled, Focus Mode being toggled, and the periodic background task all
call it, and it always re-derives the correct state from scratch.

**Smart Silence — calendar-based muting** (`src/services/notifications/smartSilence.js`)
- `shouldSuppressNotifications()` is the single source of truth: true if
  either manual DND is on, or a Google Calendar event (from Phase 6's
  `fetchGoogleBusyBlocksForDate`) is active right now.
- Enforced at two layers:
  1. **Foreground handler** (`notificationSetup.js`) — checked live, in
     JS, the instant any notification would be presented while the app is
     open. This is the reliable enforcement point.
  2. **Background task** (`backgroundTask.js`) — an `expo-background-fetch`
     task that periodically re-runs `refreshEveningNotification()`, so a
     suppressed evening notification "self-heals" and gets rescheduled
     once a meeting ends or DND is turned off, even without reopening the
     app. ⚠️ Both iOS and Android throttle background fetch for battery
     reasons — the ~15-minute interval is advisory, not guaranteed. This
     is a fundamental constraint of Expo's managed workflow without a
     push-notification server, and is documented in the code.

**Conditional evening check** (`eveningScheduler.js`, `eveningMessage.js`)
- User-configurable time via a new **Settings** screen (gear icon on the
  Dashboard header), default 20:00, stored in `kv_store`
  (`notificationSettings.js`).
- Right before scheduling, evaluates today's progress
  (`getTodayProgress()`): if `completed === total`, silently aborts —
  no notification is scheduled at all.
- Otherwise schedules exactly one local notification with the required
  phrasing, `buildEveningMessage()` substituting a grammatically correct
  Hebrew count word for the number of remaining tasks (e.g. "לימוד קטן
  אחד" for one, "שני לימודים קטנים" for two, etc.).
- If the evening time has already passed today when this runs (e.g. it
  was held back by Smart Silence), it fires as an almost-immediate
  same-day catch-up instead of rolling over to tomorrow.
- A delivery listener (`notificationListeners.js`) flips a `kv_store`
  "delivered today" flag the moment the notification actually fires, so
  it's never sent twice in one day even as state keeps changing
  afterward.

**Focus Mode override** (`src/context/FocusModeContext.js`)
- The existing bell-icon DND toggle now also calls
  `refreshEveningNotification()` on every toggle, immediately cancelling
  any pending evening notification when DND is turned on.
- Per the spec's "remainder of the current day": DND is automatically
  cleared at the next midnight rollover (subscribed via `rolloverBus`)
  rather than persisting indefinitely, so it behaves as a "quiet today"
  toggle rather than a permanent setting.

## Next phases (not yet built)
- Habit streak statistics

## Phase 8 — Full Hebrew RTL Support, Custom Boards, CSV Import, Help Screen

**Hebrew & RTL audit**: every screen was already Hebrew/RTL from earlier
phases (I18nManager.forceRTL, row-reverse layouts, right-aligned text
throughout); this phase re-verified it end-to-end — a full grep pass
found zero leftover English UI strings and zero non-reversed row layouts
anywhere in the codebase.

**Custom boards / topic grouping** (`src/models/Board.js`)
- New `boards` table (`id`, `name`, `sort_order`) plus a `board_id`
  column on `topics` (migrated safely for existing installs).
- `BoardTabs.js` renders a horizontal tab row below the Dashboard header:
  "כל הנושאים" (all topics), each existing board, and a "+" to create a
  new one (`AddBoardModal.js`). Selecting a board filters `TopicsGrid` to
  only that board's topics via a `useMemo` filter in `DashboardScreen`.
- Since the 5 seeded mandatory topics start unassigned, long-pressing any
  topic card opens `BoardPickerModal.js` to assign (or unassign) it to a
  board — this is how existing topics get grouped, not just new ones.

**Bulk CSV import** (`src/services/csvImport/`)
- A highly visible "ייבוא מאקסל" button on the Settings screen, using
  `expo-document-picker` to pick a `.csv` file and `expo-file-system` to
  read it.
- `parseCsv.js` (via `papaparse`) validates the exact required Hebrew
  headers — `תאריך`, `שם הספק`, `משימה מפורטת` — and reports a clear
  Hebrew error if any are missing.
- `csvDateFormat.js` accepts `DD/MM/YYYY` (and `.`/`-` separators) or ISO
  dates.
- `importRunner.js` matches each row's topic name against existing
  topics (case/whitespace-insensitive), and `Task.batchImportTasks()`
  bulk-writes them: new tasks are created `pending` with the note text;
  a task that already exists for that topic+date only has its note
  updated, so re-importing never un-completes something already checked
  off.
- The result is shown as a Hebrew summary: rows imported, rows skipped
  for a bad date, and any topic names that didn't match — so the user
  can fix and re-import.

**Help & tutorial screen** (`src/screens/HelpScreen.js`)
- Reachable from Settings ("עזרה והסבר"). Plain-Hebrew sections covering
  the daily flow, marking tasks complete, boards, the schedule/Google
  Calendar sync, and rollover behavior.
- A dedicated, detailed CSV section walks through the exact column
  requirements and renders a hardcoded example table (using the same
  `CSV_COLUMNS` constants the parser validates against, so the
  instructions can never drift out of sync with the actual import logic).

## Phase 9 — Built-in Template Library and External API Integration

**Hebrew & RTL**: reconfirmed clean across every new file (see the
verification note below).

**Track Store** (`src/screens/TrackStoreScreen.js`, `src/data/trackTemplates.js`)
- New "מאגר הספקים" screen, reachable via a prominent button on the
  Dashboard (below the schedule planner button) and a link on the
  Settings screen.
- Pre-populated with the required templates — **דף יומי בבלי**,
  **משנה ברורה**, **תהילים יומי** — plus a bonus **משנה יומית** track
  demonstrating a second live provider (see below).
- Each card has a **הירשם** button. Subscribing creates the topic via
  the existing `Topic.createTopic()` (Phase 1), immediately fetches
  today's dynamic label (for synced tracks) and writes it via
  `ensureTaskForTopicAndDate()` (Phase 4) so the topic appears on the
  Dashboard already populated — no waiting for the next rollover. Already
  subscribed templates show a disabled "נרשמת ✓" state (checked by
  matching topic names, case/whitespace-insensitive).

**External API integration** (`src/utils/dafYomi.js`, `src/utils/hebcalDailyLearning.js`)
- Daf Yomi now tries **two independent live providers** before falling
  back to local calculation: Sefaria's calendars API first, then
  Hebcal's calendar API (`hebcalDailyLearning.js`, a small reusable
  helper for any of Hebcal's daily-learning flags), and only drops to
  the offline cycle calculation if both are unreachable.
- The new Mishnah Yomi track (`sync_source: 'mishna_yomi'`) is Hebcal-only
  (`mf=on`) — unlike Tehillim's division, it has no deterministic local
  fallback (it's a curated assignment, not calendar math), so it
  correctly returns no preset label rather than a guess if Hebcal is
  unreachable.
- Tehillim's local calculation remains as-is: it's genuinely
  self-sufficient calendar math (Hebrew day-of-month → chapter range)
  with no external "true" answer to synchronize against, so there's
  nothing an API adds there.

**Midnight rollover integration** — no changes needed to
`services/rollover.js` itself: it already calls the generic
`generateDailyLabel(topic, date)` registry from Phase 4, so both the
Hebcal fallback and the new Mishnah Yomi generator flow through
automatically for every subscribed topic, every night (or on first
launch of a new day), exactly like Daf Yomi and Tehillim already did.

## Phase 10 — State Persistence, Clean Edit Mode, and About Screen

**Hebrew & RTL**: reconfirmed clean; also caught and fixed one regression —
the About screen's app name was displaying in English ("Torah Tracker"),
now shown as "מעקב הספקים" to match the app's own Hebrew terminology.

**Navigation state persistence** (`src/navigation/RootNavigator.js`)
- Uses `@react-native-async-storage/async-storage` (React Navigation's
  own recommended approach) to save the full nav state on every change,
  debounced 300ms so rapid transitions don't spam storage writes.
- On launch, the saved state is validated against a known-routes allowlist
  before being restored — a mismatch (e.g. from a future screen rename)
  falls back to a fresh start on the Dashboard instead of crashing.
- Result: minimizing or closing the app and reopening it lands back on
  the exact screen — including a specific Topic Details or Schedule
  screen with the right params — rather than resetting to the Dashboard.

**Clean Edit Mode** (`src/components/TopicCard.js`, `EditTopicModal.js`)
- Topic cards stay clutter-free by default — no visible edit/delete
  icons. A "ערוך" toggle above the topics grid switches the whole
  Dashboard into edit mode; tapping it again ("סיום עריכה") exits.
- In edit mode, small pencil and trash badges appear on each card (trash
  hidden for the 5 protected mandatory topics, matching the existing
  `type: 'fixed'` protection from `Topic.deleteTopic()`); normal
  tap-to-open and long-press-to-assign-board are disabled so editing
  can't be triggered by accident.
- Pencil opens `EditTopicModal.js` (rename + change icon, reusing the
  same icon picker as the add-topic flow) → `Topic.updateTopic()`.
- Trash shows a native confirm dialog, then calls `Topic.deleteTopic()`;
  if it's a protected fixed topic, the model's existing Hebrew error is
  surfaced in an alert instead of silently failing.
- Edit mode automatically resets on navigating away, so it never lingers
  confusingly next time the Dashboard is revisited mid-flow.

**About & Contact screen** (`src/screens/AboutScreen.js`)
- Reachable from Settings ("אודות"). Displays the required non-profit
  statement verbatim, plus three deep-link contact buttons — התקשר
  (`tel:+972525253767`), וואטסאפ (`https://wa.me/972525253767`), אימייל
  (`mailto:Uriel.starik@gmail.com`) — each checked with
  `Linking.canOpenURL` first and falling back to a Hebrew alert if no
  matching app is available on the device.

## Next phases (not yet built)
- Habit streak statistics
