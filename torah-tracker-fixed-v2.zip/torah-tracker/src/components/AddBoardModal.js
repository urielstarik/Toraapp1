// src/components/AddBoardModal.js
import React, { useState } from 'react';
import {
  Modal, View, Text, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, Pressable,
} from 'react-native';
import colors from '../theme/colors';
import { typography } from '../theme/fonts';

export default function AddBoardModal({ visible, onClose, onSave }) {
  const [name, setName] = useState('');
  const [saving, setSaving] = useState(false);

  const canSave = name.trim().length > 0 && !saving;

  const reset = () => {
    setName('');
    setSaving(false);
  };

  const handleClose = () => {
    reset();
    onClose?.();
  };

  const handleSave = async () => {
    if (!canSave) return;
    setSaving(true);
    try {
      await onSave?.(name.trim());
      reset();
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={handleClose}>
      <Pressable style={styles.backdrop} onPress={handleClose}>
        <Pressable style={styles.sheet} onPress={(e) => e.stopPropagation()}>
          <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
            <View style={styles.handle} />
            <Text style={[typography.topicTitle, styles.title]}>לוח חדש</Text>
            <Text style={[typography.label, styles.subtitle]}>
              לדוגמה: "שגרת חול" או "הספקים חודש אלול"
            </Text>

            <TextInput
              style={[typography.body, styles.input]}
              placeholder="שם הלוח"
              placeholderTextColor={colors.textSecondary}
              value={name}
              onChangeText={setName}
              textAlign="right"
              maxLength={30}
              autoFocus
            />

            <View style={styles.actionsRow}>
              <TouchableOpacity onPress={handleClose} style={styles.cancelButton}>
                <Text style={[typography.body, styles.cancelText]}>ביטול</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={handleSave}
                disabled={!canSave}
                style={[styles.saveButton, !canSave && styles.saveButtonDisabled]}
              >
                <Text style={[typography.topicTitle, styles.saveText]}>
                  {saving ? 'יוצר...' : 'יצירה'}
                </Text>
              </TouchableOpacity>
            </View>
          </KeyboardAvoidingView>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.25)', justifyContent: 'flex-end' },
  sheet: {
    backgroundColor: colors.background,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 24,
    paddingTop: 12,
    paddingBottom: 32,
  },
  handle: {
    width: 40, height: 4, borderRadius: 2, backgroundColor: colors.divider,
    alignSelf: 'center', marginBottom: 16,
  },
  title: { textAlign: 'center', color: colors.textPrimary, marginBottom: 4 },
  subtitle: { textAlign: 'center', color: colors.textSecondary, marginBottom: 18 },
  input: {
    backgroundColor: colors.surface, borderRadius: 14, paddingHorizontal: 16,
    paddingVertical: 14, color: colors.textPrimary, marginBottom: 20,
    borderWidth: 1, borderColor: colors.divider,
  },
  actionsRow: { flexDirection: 'row-reverse', justifyContent: 'space-between' },
  cancelButton: { paddingVertical: 14, paddingHorizontal: 20 },
  cancelText: { color: colors.textSecondary },
  saveButton: {
    flex: 1, marginRight: 12, backgroundColor: colors.primary, borderRadius: 14,
    paddingVertical: 14, alignItems: 'center',
  },
  saveButtonDisabled: { opacity: 0.5 },
  saveText: { color: '#FFFFFF' },
});
