// src/components/AddTopicCard.js
import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';
import { Feather } from '@expo/vector-icons';
import colors from '../theme/colors';
import { typography } from '../theme/fonts';
import { CARD_MARGIN } from './TopicCard';

export default function AddTopicCard({ onPress }) {
  return (
    <TouchableOpacity
      style={styles.card}
      onPress={onPress}
      activeOpacity={0.85}
      accessibilityRole="button"
      accessibilityLabel="הוסף נושא לימוד חדש"
    >
      <Feather name="plus" size={30} color={colors.primaryLight} />
      <Text style={[typography.label, styles.text]}>נושא חדש</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    backgroundColor: colors.surfaceAlt,
    borderRadius: 18,
    borderWidth: 1.5,
    borderColor: colors.divider,
    borderStyle: 'dashed',
    paddingVertical: 22,
    paddingHorizontal: 14,
    margin: CARD_MARGIN,
    minHeight: 118,
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    color: colors.textSecondary,
    marginTop: 8,
  },
});
