// src/components/AddTopicModal.js
import React, { useState } from 'react';
import {
  Modal,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Pressable,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import colors from '../theme/colors';
import { typography } from '../theme/fonts';
import { TOPIC_ICON_OPTIONS, DEFAULT_TOPIC_ICON } from '../theme/topicIcons';

export default function AddTopicModal({ visible, onClose, onSave }) {
  const [name, setName] = useState('');
  const [selectedIcon, setSelectedIcon] = useState(DEFAULT_TOPIC_ICON);
  const [saving, setSaving] = useState(false);

  const canSave = name.trim().length > 0 && !saving;

  const reset = () => {
    setName('');
    setSelectedIcon(DEFAULT_TOPIC_ICON);
    setSaving(false);
  };

  const handleClose = () => {
    reset();
    onClose?.();
  };

  const handleSave = async () => {
    if (!canSave) return;
    setSaving(true);
    try {
      await onSave?.({ name: name.trim(), icon: selectedIcon });
      reset();
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={handleClose}
    >
      <Pressable style={styles.backdrop} onPress={handleClose}>
        <Pressable
          style={styles.sheet}
          onPress={(e) => e.stopPropagation()}
        >
          <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          >
            <View style={styles.handle} />
            <Text style={[typography.topicTitle, styles.title]}>
              נושא לימוד חדש
            </Text>

            <TextInput
              style={[typography.body, styles.input]}
              placeholder="שם הנושא"
              placeholderTextColor={colors.textSecondary}
              value={name}
              onChangeText={setName}
              textAlign="right"
              maxLength={40}
              autoFocus
            />

            <Text style={[typography.label, styles.iconLabel]}>בחר אייקון</Text>
            <ScrollView
              horizontal
              inverted // so the row reads right-to-left, matching the RTL layout
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.iconRow}
            >
              {TOPIC_ICON_OPTIONS.map((icon) => {
                const isSelected = icon === selectedIcon;
                return (
                  <TouchableOpacity
                    key={icon}
                    onPress={() => setSelectedIcon(icon)}
                    style={[
                      styles.iconOption,
                      isSelected && styles.iconOptionSelected,
                    ]}
                    accessibilityRole="button"
                    accessibilityState={{ selected: isSelected }}
                  >
                    <Feather
                      name={icon}
                      size={22}
                      color={isSelected ? '#FFFFFF' : colors.primary}
                    />
                  </TouchableOpacity>
                );
              })}
            </ScrollView>

            <View style={styles.actionsRow}>
              <TouchableOpacity onPress={handleClose} style={styles.cancelButton}>
                <Text style={[typography.body, styles.cancelText]}>ביטול</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={handleSave}
                disabled={!canSave}
                style={[styles.saveButton, !canSave && styles.saveButtonDisabled]}
              >
                <Text style={[typography.topicTitle, styles.saveText]}>
                  {saving ? 'שומר...' : 'שמירה'}
                </Text>
              </TouchableOpacity>
            </View>
          </KeyboardAvoidingView>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.25)',
    justifyContent: 'flex-end',
  },
  sheet: {
    backgroundColor: colors.background,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 24,
    paddingTop: 12,
    paddingBottom: 32,
  },
  handle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: colors.divider,
    alignSelf: 'center',
    marginBottom: 16,
  },
  title: {
    textAlign: 'center',
    color: colors.textPrimary,
    marginBottom: 18,
  },
  input: {
    backgroundColor: colors.surface,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    color: colors.textPrimary,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: colors.divider,
  },
  iconLabel: {
    color: colors.textSecondary,
    textAlign: 'right',
    marginBottom: 10,
  },
  iconRow: {
    paddingBottom: 8,
    gap: 10,
  },
  iconOption: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.divider,
  },
  iconOptionSelected: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  actionsRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    marginTop: 24,
  },
  cancelButton: {
    paddingVertical: 14,
    paddingHorizontal: 20,
  },
  cancelText: {
    color: colors.textSecondary,
  },
  saveButton: {
    flex: 1,
    marginRight: 12,
    backgroundColor: colors.primary,
    borderRadius: 14,
    paddingVertical: 14,
    alignItems: 'center',
  },
  saveButtonDisabled: {
    opacity: 0.5,
  },
  saveText: {
    color: '#FFFFFF',
  },
});
