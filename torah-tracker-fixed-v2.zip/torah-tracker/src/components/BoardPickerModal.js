// src/components/BoardPickerModal.js
import React from 'react';
import { Modal, View, Text, TouchableOpacity, StyleSheet, Pressable, ScrollView } from 'react-native';
import { Feather } from '@expo/vector-icons';
import colors from '../theme/colors';
import { typography } from '../theme/fonts';

export default function BoardPickerModal({ visible, topic, boards, onSelect, onClose }) {
  if (!topic) return null;

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable style={styles.backdrop} onPress={onClose}>
        <Pressable style={styles.sheet} onPress={(e) => e.stopPropagation()}>
          <View style={styles.handle} />
          <Text style={[typography.topicTitle, styles.title]}>שיוך ללוח</Text>
          <Text style={[typography.label, styles.subtitle]}>{topic.name}</Text>

          <ScrollView style={styles.list}>
            <TouchableOpacity
              style={styles.row}
              onPress={() => onSelect(null)}
              accessibilityRole="button"
            >
              <Text style={[typography.body, styles.rowText]}>ללא לוח</Text>
              {!topic.board_id && <Feather name="check" size={18} color={colors.primary} />}
            </TouchableOpacity>

            {boards.map((board) => (
              <TouchableOpacity
                key={board.id}
                style={styles.row}
                onPress={() => onSelect(board.id)}
                accessibilityRole="button"
              >
                <Text style={[typography.body, styles.rowText]}>{board.name}</Text>
                {topic.board_id === board.id && (
                  <Feather name="check" size={18} color={colors.primary} />
                )}
              </TouchableOpacity>
            ))}
          </ScrollView>

          <TouchableOpacity onPress={onClose} style={styles.closeButton}>
            <Text style={[typography.body, styles.closeText]}>סגירה</Text>
          </TouchableOpacity>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.25)', justifyContent: 'flex-end' },
  sheet: {
    backgroundColor: colors.background,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 24,
    paddingTop: 12,
    paddingBottom: 32,
    maxHeight: '70%',
  },
  handle: {
    width: 40, height: 4, borderRadius: 2, backgroundColor: colors.divider,
    alignSelf: 'center', marginBottom: 16,
  },
  title: { textAlign: 'center', color: colors.textPrimary },
  subtitle: { textAlign: 'center', color: colors.textSecondary, marginBottom: 16 },
  list: { marginBottom: 12 },
  row: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: 12,
    paddingVertical: 14,
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  rowText: { color: colors.textPrimary },
  closeButton: { alignSelf: 'center', paddingVertical: 10 },
  closeText: { color: colors.textSecondary },
});
