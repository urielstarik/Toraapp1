// src/components/BoardTabs.js
import React from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import { Feather } from '@expo/vector-icons';
import colors from '../theme/colors';
import { typography } from '../theme/fonts';

export const ALL_BOARDS_ID = 'all';

export default function BoardTabs({ boards, selectedBoardId, onSelect, onAddPress }) {
  return (
    <ScrollView
      horizontal
      inverted
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.container}
    >
      <TouchableOpacity
        onPress={onAddPress}
        style={styles.addPill}
        accessibilityRole="button"
        accessibilityLabel="לוח חדש"
      >
        <Feather name="plus" size={16} color={colors.primary} />
      </TouchableOpacity>

      {boards.map((board) => {
        const isSelected = board.id === selectedBoardId;
        return (
          <TouchableOpacity
            key={board.id}
            onPress={() => onSelect(board.id)}
            style={[styles.pill, isSelected && styles.pillSelected]}
          >
            <Text style={[typography.label, styles.pillText, isSelected && styles.pillTextSelected]}>
              {board.name}
            </Text>
          </TouchableOpacity>
        );
      })}

      <TouchableOpacity
        onPress={() => onSelect(ALL_BOARDS_ID)}
        style={[styles.pill, selectedBoardId === ALL_BOARDS_ID && styles.pillSelected]}
      >
        <Text
          style={[
            typography.label,
            styles.pillText,
            selectedBoardId === ALL_BOARDS_ID && styles.pillTextSelected,
          ]}
        >
          כל הנושאים
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 20,
    paddingBottom: 14,
    alignItems: 'center',
    gap: 8,
  },
  pill: {
    backgroundColor: colors.surfaceAlt,
    borderRadius: 18,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  pillSelected: {
    backgroundColor: colors.primary,
  },
  pillText: {
    color: colors.textSecondary,
  },
  pillTextSelected: {
    color: '#FFFFFF',
  },
  addPill: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.divider,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
