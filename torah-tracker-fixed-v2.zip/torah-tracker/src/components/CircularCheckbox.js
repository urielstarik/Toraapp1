// src/components/CircularCheckbox.js
//
// A large, round checkbox. Tapping it plays two soft, grounded animations
// in sequence: (1) the circle gently fills with a calming mint tone, then
// (2) the checkmark "draws" itself via an animated SVG stroke offset,
// finishing with a light fade-in. No bounce, no overshoot, no confetti —
// easing is a simple ease-out throughout.

import React, { useEffect, useRef } from 'react';
import { Animated, TouchableOpacity, StyleSheet, Easing } from 'react-native';
import Svg, { Path } from 'react-native-svg';
import colors from '../theme/colors';

const AnimatedPath = Animated.createAnimatedComponent(Path);

// Checkmark path drawn in a 24x24 box, approximate length ~16.5
const CHECK_PATH = 'M5 12.5L10 17L19 8';
const CHECK_PATH_LENGTH = 17;

export default function CircularCheckbox({ checked, onToggle, size = 40 }) {
  const fillAnim = useRef(new Animated.Value(checked ? 1 : 0)).current;
  const strokeAnim = useRef(new Animated.Value(checked ? 1 : 0)).current;

  useEffect(() => {
    if (checked) {
      // Fill first, then draw the checkmark stroke — sequential, unhurried.
      Animated.sequence([
        Animated.timing(fillAnim, {
          toValue: 1,
          duration: 220,
          easing: Easing.out(Easing.quad),
          useNativeDriver: false,
        }),
        Animated.timing(strokeAnim, {
          toValue: 1,
          duration: 260,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: false,
        }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(fillAnim, {
          toValue: 0,
          duration: 180,
          easing: Easing.out(Easing.quad),
          useNativeDriver: false,
        }),
        Animated.timing(strokeAnim, {
          toValue: 0,
          duration: 140,
          easing: Easing.out(Easing.quad),
          useNativeDriver: false,
        }),
      ]).start();
    }
  }, [checked]);

  const backgroundColor = fillAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [colors.surface, colors.accentMint],
  });

  const borderColor = fillAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [colors.divider, colors.accentMint],
  });

  const strokeDashoffset = strokeAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [CHECK_PATH_LENGTH, 0],
  });

  const checkOpacity = strokeAnim.interpolate({
    inputRange: [0, 0.15, 1],
    outputRange: [0, 1, 1],
  });

  return (
    <TouchableOpacity
      onPress={onToggle}
      activeOpacity={0.8}
      accessibilityRole="checkbox"
      accessibilityState={{ checked }}
      hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
    >
      <Animated.View
        style={[
          styles.circle,
          {
            width: size,
            height: size,
            borderRadius: size / 2,
            backgroundColor,
            borderColor,
          },
        ]}
      >
        <Svg width={size * 0.55} height={size * 0.55} viewBox="0 0 24 24">
          <AnimatedPath
            d={CHECK_PATH}
            stroke="#FFFFFF"
            strokeWidth={2.75}
            strokeLinecap="round"
            strokeLinejoin="round"
            fill="none"
            strokeDasharray={CHECK_PATH_LENGTH}
            strokeDashoffset={strokeDashoffset}
            opacity={checkOpacity}
          />
        </Svg>
      </Animated.View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  circle: {
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
