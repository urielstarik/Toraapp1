// src/components/DashboardHeader.js
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Feather } from '@expo/vector-icons';
import colors from '../theme/colors';
import { typography } from '../theme/fonts';
import { useFocusMode } from '../context/FocusModeContext';

export default function DashboardHeader({ quote, dualDate, onSettingsPress }) {
  const { isDoNotDisturb, toggleFocusMode } = useFocusMode();

  return (
    <View style={styles.container}>
      <TouchableOpacity
        onPress={toggleFocusMode}
        style={styles.bellButton}
        accessibilityRole="button"
        accessibilityLabel={
          isDoNotDisturb ? 'עבור למצב פעיל' : 'עבור למצב נא לא להפריע'
        }
        hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
      >
        <Feather
          name={isDoNotDisturb ? 'bell-off' : 'bell'}
          size={22}
          color={isDoNotDisturb ? colors.textSecondary : colors.primary}
        />
      </TouchableOpacity>

      <TouchableOpacity
        onPress={onSettingsPress}
        style={styles.settingsButton}
        accessibilityRole="button"
        accessibilityLabel="הגדרות תזכורות"
        hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
      >
        <Feather name="settings" size={20} color={colors.textSecondary} />
      </TouchableOpacity>

      <Text style={[typography.quote, styles.quote]}>{quote}</Text>

      <View style={styles.dateBlock}>
        <Text style={[typography.label, styles.hebrewDate]}>{dualDate.hebrew}</Text>
        <Text style={[typography.label, styles.gregorianDate]}>{dualDate.gregorian}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingTop: 56,
    paddingBottom: 20,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  bellButton: {
    position: 'absolute',
    top: 56,
    left: 20, // "top corner" — left corner reads naturally in an RTL layout
    padding: 6,
  },
  settingsButton: {
    position: 'absolute',
    top: 56,
    right: 20,
    padding: 6,
  },
  quote: {
    textAlign: 'center',
    color: colors.primary,
    marginBottom: 10,
    paddingHorizontal: 12,
  },
  dateBlock: {
    alignItems: 'center',
  },
  hebrewDate: {
    color: colors.textPrimary,
    marginBottom: 2,
  },
  gregorianDate: {
    color: colors.textSecondary,
  },
});
