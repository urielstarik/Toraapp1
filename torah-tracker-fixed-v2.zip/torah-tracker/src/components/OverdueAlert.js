// src/components/OverdueAlert.js
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Feather } from '@expo/vector-icons';
import colors from '../theme/colors';
import { typography } from '../theme/fonts';

export default function OverdueAlert({ count }) {
  if (!count || count <= 0) return null;

  return (
    <View style={styles.container}>
      <Feather name="clock" size={16} color={colors.textSecondary} style={styles.icon} />
      <Text style={[typography.body, styles.text]}>
        {`יש לך ${count} משימות להשלמה`}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    alignSelf: 'center',
    backgroundColor: colors.overdue + '26', // soft, low-opacity gray fill
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 16,
    marginTop: 4,
    marginBottom: 18,
  },
  icon: {
    marginLeft: 8,
  },
  text: {
    color: colors.textSecondary,
  },
});
