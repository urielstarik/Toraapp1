// src/components/ProgressRing.js
import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated, Easing } from 'react-native';
import Svg, { Circle } from 'react-native-svg';
import colors from '../theme/colors';
import { typography } from '../theme/fonts';

const AnimatedCircle = Animated.createAnimatedComponent(Circle);

export default function ProgressRing({
  completed = 0,
  total = 0,
  size = 128,
  strokeWidth = 12,
}) {
  const ratio = total > 0 ? completed / total : 0;
  const percent = Math.round(ratio * 100);

  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;

  const animatedValue = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(animatedValue, {
      toValue: ratio,
      duration: 500,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: false, // strokeDashoffset isn't supported by the native driver
    }).start();
  }, [ratio]);

  const strokeDashoffset = animatedValue.interpolate({
    inputRange: [0, 1],
    outputRange: [circumference, 0],
  });

  return (
    <View style={styles.wrapper}>
      <Svg width={size} height={size}>
        <Circle
          stroke={colors.surfaceAlt}
          fill="none"
          cx={size / 2}
          cy={size / 2}
          r={radius}
          strokeWidth={strokeWidth}
        />
        <AnimatedCircle
          stroke={colors.accentMint}
          fill="none"
          cx={size / 2}
          cy={size / 2}
          r={radius}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          // Start the arc at 12 o'clock instead of 3 o'clock
          rotation="-90"
          origin={`${size / 2}, ${size / 2}`}
        />
      </Svg>
      <View style={styles.labelContainer}>
        <Text style={[typography.topicTitle, styles.percent]}>{percent}%</Text>
        <Text style={[typography.label, styles.subLabel]}>
          {total > 0 ? `${completed} מתוך ${total}` : 'אין משימות היום'}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
    marginVertical: 12,
  },
  labelContainer: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
  },
  percent: {
    color: colors.primary,
    fontSize: 22,
  },
  subLabel: {
    color: colors.textSecondary,
    marginTop: 2,
  },
});
