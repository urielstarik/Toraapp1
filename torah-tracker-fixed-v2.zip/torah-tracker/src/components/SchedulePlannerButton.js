// src/components/SchedulePlannerButton.js
import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';
import colors from '../theme/colors';
import { typography } from '../theme/fonts';

// Phase 2: UI + styling only. Phase 5 adds drag-and-drop + dynamic label.
export default function SchedulePlannerButton({ onPress, label }) {
  return (
    <TouchableOpacity
      style={styles.button}
      onPress={onPress}
      activeOpacity={0.85}
      accessibilityRole="button"
    >
      <Text style={[typography.topicTitle, styles.label]}>
        {label || 'תכנון לו"ז יומי 📅'}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    backgroundColor: colors.primary,
    borderRadius: 16,
    paddingVertical: 16,
    marginHorizontal: 24,
    marginBottom: 24,
    alignItems: 'center',
    shadowColor: colors.shadow,
    shadowOpacity: 1,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 3 },
    elevation: 2,
  },
  label: {
    color: '#FFFFFF',
    fontSize: 16,
  },
});
