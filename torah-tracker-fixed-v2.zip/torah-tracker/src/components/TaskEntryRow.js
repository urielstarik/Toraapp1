// src/components/TaskEntryRow.js
//
// One row = one task. Pairs the CircularCheckbox with an optional,
// semi-transparent free-text input bound to `note_text`, so a user on a
// flexible-pace topic can jot exactly what they covered (e.g. "פרק ג'")
// whether they type it before or after checking the box.

import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet } from 'react-native';
import CircularCheckbox from './CircularCheckbox';
import colors from '../theme/colors';
import { typography } from '../theme/fonts';

export default function TaskEntryRow({ task, dateLabel, onChange }) {
  const [note, setNote] = useState(task.note_text || '');
  const checked = task.status === 'completed';

  const handleToggle = () => {
    onChange?.(task, { toggle: true, note });
  };

  const handleNoteBlur = () => {
    if (note !== (task.note_text || '')) {
      onChange?.(task, { toggle: false, note });
    }
  };

  return (
    <View style={styles.row}>
      <CircularCheckbox checked={checked} onToggle={handleToggle} size={40} />

      <View style={styles.middle}>
        {dateLabel ? (
          <Text style={[typography.label, styles.dateLabel]}>{dateLabel}</Text>
        ) : null}
        <TextInput
          style={[typography.body, styles.noteInput]}
          placeholder="מה למדת? (רשות)"
          placeholderTextColor={colors.textSecondary}
          value={note}
          onChangeText={setNote}
          onBlur={handleNoteBlur}
          textAlign="right"
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: 16,
    padding: 14,
    marginBottom: 12,
  },
  middle: {
    flex: 1,
    marginRight: 14,
  },
  dateLabel: {
    color: colors.textSecondary,
    marginBottom: 2,
  },
  noteInput: {
    // Semi-transparent, borderless — reads as optional/secondary,
    // not a mandatory form field.
    backgroundColor: colors.surfaceAlt + '80',
    borderRadius: 10,
    paddingVertical: 8,
    paddingHorizontal: 10,
    color: colors.textPrimary,
  },
});
