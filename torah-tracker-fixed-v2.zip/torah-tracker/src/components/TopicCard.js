// src/components/TopicCard.js
import React from 'react';
import { TouchableOpacity, View, Text, StyleSheet } from 'react-native';
import { Feather } from '@expo/vector-icons';
import colors from '../theme/colors';
import { typography } from '../theme/fonts';
import { DEFAULT_TOPIC_ICON } from '../theme/topicIcons';

export default function TopicCard({
  topic, onPress, onLongPress, editMode, onEditPress, onDeletePress,
}) {
  const canDelete = topic.type !== 'fixed';

  return (
    <TouchableOpacity
      style={styles.card}
      onPress={() => !editMode && onPress?.(topic)}
      onLongPress={() => !editMode && onLongPress?.(topic)}
      delayLongPress={350}
      activeOpacity={editMode ? 1 : 0.85}
      accessibilityRole="button"
      accessibilityLabel={topic.name}
    >
      <Feather
        name={topic.icon || DEFAULT_TOPIC_ICON}
        size={26}
        color={colors.primary}
        style={styles.icon}
      />
      <Text style={[typography.topicTitle, styles.name]} numberOfLines={2}>
        {topic.name}
      </Text>

      {editMode && (
        <>
          <TouchableOpacity
            style={[styles.badge, styles.editBadge]}
            onPress={() => onEditPress?.(topic)}
            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            accessibilityRole="button"
            accessibilityLabel="עריכת נושא"
          >
            <Feather name="edit-2" size={13} color={colors.primary} />
          </TouchableOpacity>

          {canDelete && (
            <TouchableOpacity
              style={[styles.badge, styles.deleteBadge]}
              onPress={() => onDeletePress?.(topic)}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              accessibilityRole="button"
              accessibilityLabel="מחיקת נושא"
            >
              <Feather name="trash-2" size={13} color="#B5544A" />
            </TouchableOpacity>
          )}
        </>
      )}
    </TouchableOpacity>
  );
}

export const CARD_MARGIN = 8;

const styles = StyleSheet.create({
  card: {
    flex: 1,
    backgroundColor: colors.surface,
    borderRadius: 18,
    paddingVertical: 22,
    paddingHorizontal: 14,
    margin: CARD_MARGIN,
    minHeight: 118,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: colors.shadow,
    shadowOpacity: 1,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
    elevation: 1,
  },
  icon: {
    marginBottom: 10,
  },
  name: {
    color: colors.textPrimary,
    textAlign: 'center',
  },
  badge: {
    position: 'absolute',
    top: 8,
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.divider,
    shadowColor: colors.shadow,
    shadowOpacity: 1,
    shadowRadius: 3,
    elevation: 2,
  },
  editBadge: {
    left: 8,
  },
  deleteBadge: {
    right: 8,
  },
});
