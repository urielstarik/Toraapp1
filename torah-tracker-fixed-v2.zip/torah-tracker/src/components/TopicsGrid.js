// src/components/TopicsGrid.js
import React from 'react';
import { View, StyleSheet } from 'react-native';
import TopicCard from './TopicCard';
import AddTopicCard from './AddTopicCard';

const NUM_COLUMNS = 2;

export default function TopicsGrid({
  topics, onTopicPress, onTopicLongPress, onAddPress, editMode, onEditTopic, onDeleteTopic,
}) {
  // Build rows of NUM_COLUMNS so the trailing "+" card lines up in the grid
  // even when the topic count is odd.
  const items = [...topics, { __addCard: true }];
  const rows = [];
  for (let i = 0; i < items.length; i += NUM_COLUMNS) {
    rows.push(items.slice(i, i + NUM_COLUMNS));
  }

  return (
    <View style={styles.container}>
      {rows.map((row, rowIndex) => (
        <View style={styles.row} key={`row-${rowIndex}`}>
          {row.map((item, i) =>
            item.__addCard ? (
              <AddTopicCard key="add-card" onPress={onAddPress} />
            ) : (
              <TopicCard
                key={item.id}
                topic={item}
                onPress={onTopicPress}
                onLongPress={onTopicLongPress}
                editMode={editMode}
                onEditPress={onEditTopic}
                onDeletePress={onDeleteTopic}
              />
            )
          )}
          {/* Pad the last row so a lone card doesn't stretch full width */}
          {row.length < NUM_COLUMNS &&
            Array.from({ length: NUM_COLUMNS - row.length }).map((_, i) => (
              <View key={`spacer-${i}`} style={{ flex: 1, margin: 8 }} />
            ))}
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 16,
  },
  row: {
    flexDirection: 'row-reverse',
  },
});
