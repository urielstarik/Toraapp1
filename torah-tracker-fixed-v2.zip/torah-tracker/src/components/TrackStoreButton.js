// src/components/TrackStoreButton.js
import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';
import { Feather } from '@expo/vector-icons';
import colors from '../theme/colors';
import { typography } from '../theme/fonts';

export default function TrackStoreButton({ onPress }) {
  return (
    <TouchableOpacity
      style={styles.button}
      onPress={onPress}
      activeOpacity={0.85}
      accessibilityRole="button"
    >
      <Feather name="compass" size={18} color={colors.primary} style={styles.icon} />
      <Text style={[typography.topicTitle, styles.label]}>מאגר הספקים 📚</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.surfaceAlt,
    borderRadius: 16,
    borderWidth: 1.5,
    borderColor: colors.divider,
    paddingVertical: 14,
    marginHorizontal: 24,
    marginBottom: 20,
  },
  icon: {
    marginLeft: 8,
  },
  label: {
    color: colors.primary,
    fontSize: 15,
  },
});
