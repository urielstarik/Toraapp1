// src/components/schedule/DragGhost.js
import React from 'react';
import { Animated, Text, StyleSheet, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useDrag } from '../../context/DragContext';
import colors from '../../theme/colors';
import { typography } from '../../theme/fonts';
import { DEFAULT_TOPIC_ICON } from '../../theme/topicIcons';

export default function DragGhost() {
  const { dragging, pan } = useDrag();
  if (!dragging) return null;

  const { item, width, height } = dragging;

  return (
    <Animated.View
      pointerEvents="none"
      style={[
        styles.ghost,
        {
          width,
          height,
          transform: pan.getTranslateTransform(),
        },
      ]}
    >
      <View style={styles.row}>
        <Feather
          name={item.icon || DEFAULT_TOPIC_ICON}
          size={18}
          color={colors.primary}
          style={styles.icon}
        />
        <Text style={[typography.label, styles.title]} numberOfLines={1}>
          {item.title}
        </Text>
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  ghost: {
    position: 'absolute',
    top: 0,
    left: 0,
    backgroundColor: colors.surface,
    borderRadius: 12,
    paddingHorizontal: 12,
    justifyContent: 'center',
    borderWidth: 1.5,
    borderColor: colors.primaryLight,
    shadowColor: colors.shadow,
    shadowOpacity: 1,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 6,
    opacity: 0.95,
    zIndex: 999,
  },
  row: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
  },
  icon: {
    marginLeft: 8,
  },
  title: {
    color: colors.textPrimary,
    flexShrink: 1,
  },
});
