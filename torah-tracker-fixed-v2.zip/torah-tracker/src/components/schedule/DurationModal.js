// src/components/schedule/DurationModal.js
import React, { useEffect, useState } from 'react';
import {
  Modal, View, Text, TextInput, TouchableOpacity, StyleSheet, Pressable,
} from 'react-native';
import colors from '../../theme/colors';
import { typography } from '../../theme/fonts';

const QUICK_OPTIONS = [15, 30, 45, 60];

function formatStartTime(startMinute) {
  const h = Math.floor(startMinute / 60);
  const m = startMinute % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

export default function DurationModal({ visible, pendingDrop, onConfirm, onCancel }) {
  const [customMinutes, setCustomMinutes] = useState('');

  useEffect(() => {
    if (visible) setCustomMinutes('');
  }, [visible]);

  if (!pendingDrop) return null;

  const handleQuickSelect = (minutes) => onConfirm(minutes);

  const handleCustomConfirm = () => {
    const parsed = parseInt(customMinutes, 10);
    if (Number.isFinite(parsed) && parsed > 0) {
      onConfirm(parsed);
    }
  };

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onCancel}>
      <Pressable style={styles.backdrop} onPress={onCancel}>
        <Pressable style={styles.card} onPress={(e) => e.stopPropagation()}>
          <Text style={[typography.topicTitle, styles.title]}>כמה זמן להקצות?</Text>
          <Text style={[typography.label, styles.subtitle]}>
            {`${pendingDrop.item.title} · החל מ-${formatStartTime(pendingDrop.startMinute)}`}
          </Text>

          <View style={styles.optionsRow}>
            {QUICK_OPTIONS.map((minutes) => (
              <TouchableOpacity
                key={minutes}
                style={styles.optionButton}
                onPress={() => handleQuickSelect(minutes)}
              >
                <Text style={[typography.topicTitle, styles.optionText]}>
                  {minutes < 60 ? `${minutes} דק'` : 'שעה'}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <View style={styles.customRow}>
            <TextInput
              style={[typography.body, styles.customInput]}
              placeholder="זמן מותאם (בדקות)"
              placeholderTextColor={colors.textSecondary}
              keyboardType="number-pad"
              value={customMinutes}
              onChangeText={setCustomMinutes}
              textAlign="right"
            />
            <TouchableOpacity
              style={[styles.customButton, !customMinutes && styles.customButtonDisabled]}
              onPress={handleCustomConfirm}
              disabled={!customMinutes}
            >
              <Text style={[typography.label, styles.customButtonText]}>אישור</Text>
            </TouchableOpacity>
          </View>

          <TouchableOpacity onPress={onCancel} style={styles.cancelLink}>
            <Text style={[typography.label, styles.cancelText]}>ביטול</Text>
          </TouchableOpacity>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.3)', alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: 32,
  },
  card: {
    width: '100%', backgroundColor: colors.background, borderRadius: 20, padding: 22,
  },
  title: { textAlign: 'center', color: colors.textPrimary, marginBottom: 4 },
  subtitle: { textAlign: 'center', color: colors.textSecondary, marginBottom: 20 },
  optionsRow: { flexDirection: 'row-reverse', justifyContent: 'space-between', marginBottom: 16 },
  optionButton: {
    flex: 1, marginHorizontal: 4, backgroundColor: colors.surface, borderRadius: 12,
    paddingVertical: 14, alignItems: 'center', borderWidth: 1, borderColor: colors.divider,
  },
  optionText: { color: colors.primary, fontSize: 15 },
  customRow: { flexDirection: 'row-reverse', alignItems: 'center', marginBottom: 8 },
  customInput: {
    flex: 1, backgroundColor: colors.surface, borderRadius: 12, paddingHorizontal: 14,
    paddingVertical: 12, color: colors.textPrimary, borderWidth: 1, borderColor: colors.divider,
  },
  customButton: {
    marginRight: 10, backgroundColor: colors.primary, borderRadius: 12,
    paddingHorizontal: 18, paddingVertical: 12,
  },
  customButtonDisabled: { opacity: 0.4 },
  customButtonText: { color: '#FFFFFF' },
  cancelLink: { alignSelf: 'center', marginTop: 14, padding: 6 },
  cancelText: { color: colors.textSecondary },
});
