// src/components/schedule/GoogleEventBlock.js
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Feather } from '@expo/vector-icons';
import colors from '../../theme/colors';
import { typography } from '../../theme/fonts';
import { PX_PER_MINUTE, TIMELINE_START_MINUTE } from './timelineConstants';

// Purely informational — not draggable, not resizable, ignores touches
// entirely so it never intercepts a drop meant for the timeline beneath it.
export default function GoogleEventBlock({ block }) {
  const top = (block.start_minute - TIMELINE_START_MINUTE) * PX_PER_MINUTE;
  const height = Math.max(block.duration_minutes * PX_PER_MINUTE, 18);

  return (
    <View pointerEvents="none" style={[styles.block, { top, height }]}>
      <View style={styles.row}>
        <Feather name="lock" size={11} color={colors.textSecondary} style={styles.icon} />
        <Text style={[typography.label, styles.title]} numberOfLines={1}>
          {block.title}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  block: {
    position: 'absolute',
    left: 12,
    right: 72,
    backgroundColor: 'rgba(120,120,120,0.16)',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(120,120,120,0.28)',
    borderStyle: 'dashed',
    justifyContent: 'center',
    paddingHorizontal: 10,
  },
  row: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
  },
  icon: {
    marginLeft: 6,
  },
  title: {
    color: colors.textSecondary,
    flexShrink: 1,
  },
});
