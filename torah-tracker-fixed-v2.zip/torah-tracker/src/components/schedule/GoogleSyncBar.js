// src/components/schedule/GoogleSyncBar.js
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useGoogleAuth } from '../../context/GoogleAuthContext';
import colors from '../../theme/colors';
import { typography } from '../../theme/fonts';

export default function GoogleSyncBar() {
  const { isSignedIn, isLoading, isAuthenticating, signIn, signOut } = useGoogleAuth();

  if (isLoading) return null;

  return (
    <View style={styles.container}>
      {isSignedIn ? (
        <TouchableOpacity style={styles.pillConnected} onPress={signOut} activeOpacity={0.8}>
          <Feather name="check-circle" size={14} color={colors.completed} style={styles.icon} />
          <Text style={[typography.label, styles.textConnected]}>מחובר ל-Google Calendar</Text>
        </TouchableOpacity>
      ) : (
        <TouchableOpacity
          style={styles.pill}
          onPress={signIn}
          activeOpacity={0.8}
          disabled={isAuthenticating}
        >
          {isAuthenticating ? (
            <ActivityIndicator size="small" color={colors.primary} style={styles.icon} />
          ) : (
            <Feather name="calendar" size={14} color={colors.primary} style={styles.icon} />
          )}
          <Text style={[typography.label, styles.text]}>
            {isAuthenticating ? 'מתחבר...' : 'התחבר ל-Google Calendar'}
          </Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    paddingTop: 10,
  },
  pill: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: colors.surfaceAlt,
    borderRadius: 20,
    paddingVertical: 7,
    paddingHorizontal: 14,
  },
  pillConnected: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: colors.completed + '22',
    borderRadius: 20,
    paddingVertical: 7,
    paddingHorizontal: 14,
  },
  icon: {
    marginLeft: 6,
  },
  text: {
    color: colors.primary,
  },
  textConnected: {
    color: colors.textSecondary,
  },
});
