// src/components/schedule/HourlyTimeline.js
import React, { useEffect, useRef } from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { useDrag } from '../../context/DragContext';
import colors from '../../theme/colors';
import { typography } from '../../theme/fonts';
import TimelineBlock from './TimelineBlock';
import GoogleEventBlock from './GoogleEventBlock';
import {
  START_HOUR, END_HOUR, HOUR_HEIGHT, TIMELINE_HEIGHT, TIMELINE_START_MINUTE,
  TIMELINE_END_MINUTE, MIN_DURATION_MINUTES, PX_PER_MINUTE, snap, clamp,
} from './timelineConstants';

const HOURS = Array.from({ length: END_HOUR - START_HOUR + 1 }, (_, i) => START_HOUR + i);

export default function HourlyTimeline({ blocks, googleBusyBlocks, onRequestDuration, onMove, onResize }) {
  const { registerDropZone } = useDrag();
  const scrollViewRef = useRef(null);
  const viewportRef = useRef({ x: 0, y: 0, width: 0, height: 0 });
  const scrollOffsetRef = useRef(0);

  const measureViewport = () => {
    // Slight delay so layout has settled (e.g. right after navigation transition).
    requestAnimationFrame(() => {
      scrollViewRef.current?.measureInWindow((x, y, width, height) => {
        viewportRef.current = { x, y, width, height };
      });
    });
  };

  const handleDrop = (touch, dragInfo) => {
    const localY = touch.pageY - viewportRef.current.y + scrollOffsetRef.current;
    const rawMinute = TIMELINE_START_MINUTE + localY / PX_PER_MINUTE;
    const maxStart = TIMELINE_END_MINUTE - MIN_DURATION_MINUTES;
    const startMinute = clamp(snap(rawMinute), TIMELINE_START_MINUTE, maxStart);
    onRequestDurationRef.current(dragInfo.item, startMinute);
  };

  const onRequestDurationRef = useRef(onRequestDuration);
  onRequestDurationRef.current = onRequestDuration;

  useEffect(() => {
    const unregister = registerDropZone({
      measure: () => viewportRef.current,
      onDrop: handleDrop,
    });
    return unregister;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [registerDropZone]);

  return (
    <ScrollView
      ref={scrollViewRef}
      style={styles.scroll}
      onLayout={measureViewport}
      onScroll={(e) => {
        scrollOffsetRef.current = e.nativeEvent.contentOffset.y;
      }}
      scrollEventThrottle={16}
      showsVerticalScrollIndicator={false}
    >
      <View style={[styles.content, { height: TIMELINE_HEIGHT }]}>
        {HOURS.map((hour, i) => (
          <View key={hour} style={[styles.hourRow, { top: i * HOUR_HEIGHT }]}>
            <View style={styles.hourLine} />
            <Text style={[typography.label, styles.hourLabel]}>
              {String(hour).padStart(2, '0')}:00
            </Text>
          </View>
        ))}

        {(googleBusyBlocks || []).map((block) => (
          <GoogleEventBlock key={`gcal-${block.id}`} block={block} />
        ))}

        {blocks.map((block) => (
          <TimelineBlock key={block.id} block={block} onMove={onMove} onResize={onResize} />
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scroll: {
    flex: 1,
  },
  content: {
    position: 'relative',
  },
  hourRow: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: HOUR_HEIGHT,
    flexDirection: 'row-reverse',
    alignItems: 'flex-start',
  },
  hourLine: {
    flex: 1,
    height: 1,
    backgroundColor: colors.divider,
    marginTop: 8,
    marginRight: 4,
  },
  hourLabel: {
    width: 56,
    textAlign: 'right',
    color: colors.textSecondary,
    paddingRight: 12,
    paddingTop: 0,
  },
});
