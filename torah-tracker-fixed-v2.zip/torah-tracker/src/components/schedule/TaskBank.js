// src/components/schedule/TaskBank.js
import React from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import { Feather } from '@expo/vector-icons';
import TaskBankCard from './TaskBankCard';
import colors from '../../theme/colors';
import { typography } from '../../theme/fonts';

export default function TaskBank({ items, onAddPress }) {
  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <Text style={[typography.topicTitle, styles.title]}>משימות להיום</Text>
        <TouchableOpacity
          onPress={onAddPress}
          style={styles.addButton}
          accessibilityRole="button"
          accessibilityLabel="הוסף פעילות"
        >
          <Feather name="plus" size={20} color={colors.primary} />
        </TouchableOpacity>
      </View>

      {items.length === 0 ? (
        <Text style={[typography.label, styles.emptyText]}>
          כל המשימות שובצו ביומן 🌿
        </Text>
      ) : (
        <ScrollView
          horizontal
          inverted
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.scrollContent}
        >
          {items.map((item) => (
            <TaskBankCard key={item.key} item={item} />
          ))}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingTop: 18,
    paddingBottom: 14,
    backgroundColor: colors.background,
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
  },
  headerRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    marginBottom: 10,
  },
  title: {
    color: colors.textPrimary,
  },
  addButton: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: colors.surfaceAlt,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scrollContent: {
    paddingHorizontal: 14,
  },
  emptyText: {
    color: colors.textSecondary,
    textAlign: 'center',
    paddingVertical: 8,
  },
});
