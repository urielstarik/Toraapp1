// src/components/schedule/TaskBankCard.js
//
// A card in the horizontally-scrolling Task Bank. Long-press to arm a
// drag, then move your finger to drag the ghost onto the timeline.
// Uses core React Native PanResponder (no extra gesture library needed).

import React, { useRef, useState } from 'react';
import { View, Text, StyleSheet, PanResponder } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useDrag } from '../../context/DragContext';
import colors from '../../theme/colors';
import { typography } from '../../theme/fonts';
import { DEFAULT_TOPIC_ICON } from '../../theme/topicIcons';

const LONG_PRESS_MS = 260;
const MOVE_CANCEL_THRESHOLD = 8; // px of movement before long-press fires that cancels the arm

const CARD_WIDTH = 132;
const CARD_HEIGHT = 84;

export default function TaskBankCard({ item }) {
  const { beginDrag, updateDrag, endDrag, cancelDrag } = useDrag();
  const [armed, setArmed] = useState(false);
  const armedRef = useRef(false);
  const longPressTimer = useRef(null);
  const startedDragRef = useRef(false);

  const clearTimer = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  };

  const panResponder = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onMoveShouldSetPanResponder: (evt, gesture) =>
      armedRef.current && (Math.abs(gesture.dx) > 2 || Math.abs(gesture.dy) > 2),

    onPanResponderGrant: (evt) => {
      startedDragRef.current = false;
      longPressTimer.current = setTimeout(() => {
        armedRef.current = true;
        setArmed(true);
      }, LONG_PRESS_MS);
    },

    onPanResponderMove: (evt, gesture) => {
      if (!armedRef.current) {
        // Moved too much before the long-press fired — treat as a scroll/tap, not a drag.
        if (Math.abs(gesture.dx) > MOVE_CANCEL_THRESHOLD || Math.abs(gesture.dy) > MOVE_CANCEL_THRESHOLD) {
          clearTimer();
        }
        return;
      }
      const touch = evt.nativeEvent;
      if (!startedDragRef.current) {
        startedDragRef.current = true;
        beginDrag(item, touch, { width: CARD_WIDTH, height: CARD_HEIGHT }, 'new');
      } else {
        updateDrag(touch, { width: CARD_WIDTH, height: CARD_HEIGHT });
      }
    },

    onPanResponderRelease: (evt) => {
      clearTimer();
      if (startedDragRef.current) {
        endDrag(evt.nativeEvent);
      } else {
        cancelDrag();
      }
      armedRef.current = false;
      setArmed(false);
      startedDragRef.current = false;
    },

    onPanResponderTerminate: () => {
      clearTimer();
      cancelDrag();
      armedRef.current = false;
      setArmed(false);
      startedDragRef.current = false;
    },
  });

  return (
    <View
      {...panResponder.panHandlers}
      style={[styles.card, armed && styles.cardArmed]}
    >
      <Feather
        name={item.icon || DEFAULT_TOPIC_ICON}
        size={20}
        color={colors.primary}
        style={styles.icon}
      />
      <Text style={[typography.label, styles.title]} numberOfLines={2}>
        {item.title}
      </Text>
    </View>
  );
}

export { CARD_WIDTH, CARD_HEIGHT };

const styles = StyleSheet.create({
  card: {
    width: CARD_WIDTH,
    height: CARD_HEIGHT,
    backgroundColor: colors.surface,
    borderRadius: 14,
    padding: 12,
    marginHorizontal: 6,
    justifyContent: 'center',
    shadowColor: colors.shadow,
    shadowOpacity: 1,
    shadowRadius: 5,
    shadowOffset: { width: 0, height: 2 },
    elevation: 1,
  },
  cardArmed: {
    opacity: 0.4,
    borderWidth: 1.5,
    borderColor: colors.primaryLight,
  },
  icon: {
    marginBottom: 6,
  },
  title: {
    color: colors.textPrimary,
  },
});
