// src/components/schedule/TimelineBlock.js
import React, { useRef } from 'react';
import { View, Text, Animated, PanResponder, StyleSheet } from 'react-native';
import { Feather } from '@expo/vector-icons';
import colors from '../../theme/colors';
import { typography } from '../../theme/fonts';
import { DEFAULT_TOPIC_ICON } from '../../theme/topicIcons';
import {
  PX_PER_MINUTE, TIMELINE_START_MINUTE, TIMELINE_END_MINUTE,
  MIN_DURATION_MINUTES, snap, clamp, formatHM,
} from './timelineConstants';

export default function TimelineBlock({ block, onMove, onResize }) {
  const top = (block.start_minute - TIMELINE_START_MINUTE) * PX_PER_MINUTE;
  const height = block.duration_minutes * PX_PER_MINUTE;

  const dragTranslateY = useRef(new Animated.Value(0)).current;
  const resizeTopDelta = useRef(new Animated.Value(0)).current;
  const resizeBottomDelta = useRef(new Animated.Value(0)).current;

  // --- Move whole block ---
  const movePanResponder = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onMoveShouldSetPanResponder: (evt, g) => Math.abs(g.dy) > 3,
    onPanResponderMove: (evt, gesture) => {
      dragTranslateY.setValue(gesture.dy);
    },
    onPanResponderRelease: (evt, gesture) => {
      const deltaMinutes = snap(gesture.dy / PX_PER_MINUTE);
      const maxStart = TIMELINE_END_MINUTE - block.duration_minutes;
      const newStart = clamp(block.start_minute + deltaMinutes, TIMELINE_START_MINUTE, maxStart);
      dragTranslateY.setValue(0);
      if (newStart !== block.start_minute) onMove(block, newStart);
    },
    onPanResponderTerminate: () => dragTranslateY.setValue(0),
  });

  // --- Resize via top handle: changes start_minute, keeps bottom fixed ---
  const topHandleResponder = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onMoveShouldSetPanResponder: () => true,
    onPanResponderMove: (evt, gesture) => {
      resizeTopDelta.setValue(gesture.dy);
    },
    onPanResponderRelease: (evt, gesture) => {
      const deltaMinutes = snap(gesture.dy / PX_PER_MINUTE);
      const blockEnd = block.start_minute + block.duration_minutes;
      const maxStart = blockEnd - MIN_DURATION_MINUTES;
      const newStart = clamp(block.start_minute + deltaMinutes, TIMELINE_START_MINUTE, maxStart);
      const newDuration = blockEnd - newStart;
      resizeTopDelta.setValue(0);
      if (newStart !== block.start_minute) onResize(block, newStart, newDuration);
    },
    onPanResponderTerminate: () => resizeTopDelta.setValue(0),
  });

  // --- Resize via bottom handle: changes duration, keeps start fixed ---
  const bottomHandleResponder = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onMoveShouldSetPanResponder: () => true,
    onPanResponderMove: (evt, gesture) => {
      resizeBottomDelta.setValue(gesture.dy);
    },
    onPanResponderRelease: (evt, gesture) => {
      const deltaMinutes = snap(gesture.dy / PX_PER_MINUTE);
      const maxDuration = TIMELINE_END_MINUTE - block.start_minute;
      const newDuration = clamp(
        block.duration_minutes + deltaMinutes,
        MIN_DURATION_MINUTES,
        maxDuration
      );
      resizeBottomDelta.setValue(0);
      if (newDuration !== block.duration_minutes) onResize(block, block.start_minute, newDuration);
    },
    onPanResponderTerminate: () => resizeBottomDelta.setValue(0),
  });

  const isCompact = height < 44;

  return (
    <Animated.View
      style={[
        styles.block,
        block.kind === 'custom' && styles.blockCustom,
        { top, height, transform: [{ translateY: dragTranslateY }] },
      ]}
    >
      <View {...movePanResponder.panHandlers} style={styles.body}>
        <View style={styles.row}>
          <Feather
            name={block.icon || DEFAULT_TOPIC_ICON}
            size={16}
            color={block.kind === 'custom' ? colors.primary : colors.primary}
            style={styles.icon}
          />
          <Text style={[typography.label, styles.title]} numberOfLines={isCompact ? 1 : 2}>
            {block.title}
          </Text>
        </View>
        {!isCompact && (
          <Text style={[typography.label, styles.timeRange]}>
            {`${formatHM(block.start_minute)} – ${formatHM(block.start_minute + block.duration_minutes)}`}
          </Text>
        )}
      </View>

      <View {...topHandleResponder.panHandlers} style={[styles.handle, styles.handleTop]} hitSlop={{ top: 10, bottom: 10, left: 20, right: 20 }}>
        <View style={styles.handleBar} />
      </View>
      <View {...bottomHandleResponder.panHandlers} style={[styles.handle, styles.handleBottom]} hitSlop={{ top: 10, bottom: 10, left: 20, right: 20 }}>
        <View style={styles.handleBar} />
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  block: {
    position: 'absolute',
    left: 12,
    right: 72,
    backgroundColor: colors.accentSage,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.accentMint,
    overflow: 'visible',
    shadowColor: colors.shadow,
    shadowOpacity: 1,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
    elevation: 1,
  },
  blockCustom: {
    backgroundColor: colors.surfaceAlt,
    borderColor: colors.divider,
  },
  body: {
    flex: 1,
    paddingHorizontal: 10,
    paddingVertical: 6,
    justifyContent: 'center',
  },
  row: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
  },
  icon: {
    marginLeft: 6,
  },
  title: {
    color: colors.textPrimary,
    flexShrink: 1,
  },
  timeRange: {
    color: colors.textSecondary,
    marginTop: 2,
    fontSize: 11,
  },
  handle: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  handleTop: {
    top: -8,
  },
  handleBottom: {
    bottom: -8,
  },
  handleBar: {
    width: 28,
    height: 4,
    borderRadius: 2,
    backgroundColor: colors.primaryLight,
  },
});
