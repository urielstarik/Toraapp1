// src/components/schedule/timelineConstants.js
export const START_HOUR = 6;
export const END_HOUR = 23;
export const PX_PER_MINUTE = 1; // 60px per hour — keeps drag-delta math exact
export const HOUR_HEIGHT = 60 * PX_PER_MINUTE;
export const SNAP_MINUTES = 5;
export const MIN_DURATION_MINUTES = 15;

export const TIMELINE_START_MINUTE = START_HOUR * 60;
export const TIMELINE_END_MINUTE = END_HOUR * 60;
export const TIMELINE_HEIGHT = (END_HOUR - START_HOUR) * HOUR_HEIGHT;

export function snap(minutes, step = SNAP_MINUTES) {
  return Math.round(minutes / step) * step;
}

export function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

export function formatHM(totalMinutes) {
  const h = Math.floor(totalMinutes / 60);
  const m = totalMinutes % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

export default {
  START_HOUR, END_HOUR, PX_PER_MINUTE, HOUR_HEIGHT, SNAP_MINUTES,
  MIN_DURATION_MINUTES, TIMELINE_START_MINUTE, TIMELINE_END_MINUTE,
  TIMELINE_HEIGHT, snap, clamp, formatHM,
};
