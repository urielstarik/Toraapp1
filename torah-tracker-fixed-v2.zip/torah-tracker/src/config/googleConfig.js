// src/config/googleConfig.js
//
// Fill these in with OAuth client IDs from your own Google Cloud project
// (console.cloud.google.com → APIs & Services → Credentials). You need:
//   - An "iOS" client (bundle ID matching app.json's ios.bundleIdentifier)
//   - An "Android" client (package matching app.json's android.package)
//   - A "Web application" client (used for the Expo Go / dev proxy flow
//     and as the "expoClientId" during development)
// The Calendar API must also be enabled on the same project, and your
// Google account added as a test user while the OAuth consent screen is
// in "Testing" mode.
//
// None of these are secrets — public OAuth "installed app" clients don't
// use a client secret on mobile, only a client ID + PKCE.

export const GOOGLE_OAUTH_CONFIG = {
  iosClientId: 'YOUR_IOS_CLIENT_ID.apps.googleusercontent.com',
  androidClientId: 'YOUR_ANDROID_CLIENT_ID.apps.googleusercontent.com',
  webClientId: 'YOUR_WEB_CLIENT_ID.apps.googleusercontent.com',
  // Used by expo-auth-session when running in Expo Go / the web browser flow.
  expoClientId: 'YOUR_WEB_CLIENT_ID.apps.googleusercontent.com',
};

// Read-write access to events, but not the broader calendar-management
// scope — the minimum needed for this app's create/read/update event calls.
export const GOOGLE_CALENDAR_SCOPES = [
  'https://www.googleapis.com/auth/calendar.events',
];

export const GOOGLE_DISCOVERY = {
  authorizationEndpoint: 'https://accounts.google.com/o/oauth2/v2/auth',
  tokenEndpoint: 'https://oauth2.googleapis.com/token',
  revocationEndpoint: 'https://oauth2.googleapis.com/revoke',
};

export const CALENDAR_API_BASE = 'https://www.googleapis.com/calendar/v3';

// 'primary' targets the user's main calendar. Swap for a specific
// calendar ID if you'd rather sync to a dedicated "Torah Tracker" calendar.
export const TARGET_CALENDAR_ID = 'primary';

export default {
  GOOGLE_OAUTH_CONFIG,
  GOOGLE_CALENDAR_SCOPES,
  GOOGLE_DISCOVERY,
  CALENDAR_API_BASE,
  TARGET_CALENDAR_ID,
};
