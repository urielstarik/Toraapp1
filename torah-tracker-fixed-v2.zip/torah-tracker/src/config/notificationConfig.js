// src/config/notificationConfig.js

export const BACKGROUND_TASK_NAME = 'evening-notification-check';

// Advisory minimum — the OS decides actual timing, especially on iOS.
export const MIN_BACKGROUND_FETCH_INTERVAL_SECONDS = 15 * 60;

export const DEFAULT_EVENING_HOUR = 20;
export const DEFAULT_EVENING_MINUTE = 0;

export const EVENING_NOTIFICATION_DATA_TYPE = 'evening-check';

export default {
  BACKGROUND_TASK_NAME,
  MIN_BACKGROUND_FETCH_INTERVAL_SECONDS,
  DEFAULT_EVENING_HOUR,
  DEFAULT_EVENING_MINUTE,
  EVENING_NOTIFICATION_DATA_TYPE,
};
