// src/context/DragContext.js
//
// A single shared drag session used by both the Task Bank cards (source)
// and existing timeline blocks (move/resize). Only one thing can be
// dragged at a time. Components read `dragging` to render a floating
// ghost, and call beginDrag/updateDrag/endDrag from their PanResponder
// callbacks.

import React, { createContext, useCallback, useContext, useRef, useState } from 'react';
import { Animated } from 'react-native';

const DragContext = createContext(null);

export function DragProvider({ children }) {
  const [dragging, setDragging] = useState(null); // { item, width, height, mode }
  const pan = useRef(new Animated.ValueXY()).current;
  const dropHandlersRef = useRef([]); // [{ measure, onDrop }]

  const registerDropZone = useCallback((zone) => {
    dropHandlersRef.current.push(zone);
    return () => {
      dropHandlersRef.current = dropHandlersRef.current.filter((z) => z !== zone);
    };
  }, []);

  const beginDrag = useCallback((item, touch, size, mode = 'new') => {
    pan.setOffset({ x: 0, y: 0 });
    pan.setValue({ x: touch.pageX - size.width / 2, y: touch.pageY - size.height / 2 });
    setDragging({ item, width: size.width, height: size.height, mode });
  }, [pan]);

  const updateDrag = useCallback((touch, size) => {
    pan.setValue({ x: touch.pageX - size.width / 2, y: touch.pageY - size.height / 2 });
  }, [pan]);

  const endDrag = useCallback((touch) => {
    const zones = dropHandlersRef.current;
    for (const zone of zones) {
      const rect = zone.measure();
      if (!rect) continue;
      if (
        touch.pageX >= rect.x &&
        touch.pageX <= rect.x + rect.width &&
        touch.pageY >= rect.y &&
        touch.pageY <= rect.y + rect.height
      ) {
        zone.onDrop(touch, dragging);
        break;
      }
    }
    setDragging(null);
  }, [dragging]);

  const cancelDrag = useCallback(() => setDragging(null), []);

  return (
    <DragContext.Provider
      value={{ dragging, pan, beginDrag, updateDrag, endDrag, cancelDrag, registerDropZone }}
    >
      {children}
    </DragContext.Provider>
  );
}

export function useDrag() {
  const ctx = useContext(DragContext);
  if (!ctx) throw new Error('useDrag must be used within a DragProvider');
  return ctx;
}

export default DragContext;
