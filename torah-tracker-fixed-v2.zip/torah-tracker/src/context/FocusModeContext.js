// src/context/FocusModeContext.js
//
// Tracks whether the app is in "Active Mode" (false) or
// "Do Not Disturb / Silent Mode" (true). Exposed as a boolean,
// toggled from the bell icon in the header. Persisted to the
// kv_store table so the choice survives app restarts. Per Phase 7,
// manually-activated DND blocks all proactive notifications for the
// remainder of the current day — so it's automatically cleared at the
// next midnight rollover rather than persisting indefinitely.

import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { getItem, setItem } from '../database/kv';
import { subscribeToRollover } from '../services/rolloverBus';
import { refreshEveningNotification } from '../services/notifications/eveningScheduler';

const KEY_FOCUS_MODE = 'focus_mode_dnd';

const FocusModeContext = createContext({
  isDoNotDisturb: false,
  toggleFocusMode: () => {},
  loading: true,
});

export function FocusModeProvider({ children }) {
  const [isDoNotDisturb, setIsDoNotDisturb] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const stored = await getItem(KEY_FOCUS_MODE);
      setIsDoNotDisturb(stored === '1');
      setLoading(false);
    })();
  }, []);

  useEffect(() => {
    const unsubscribe = subscribeToRollover(() => {
      setIsDoNotDisturb(false);
      setItem(KEY_FOCUS_MODE, '0');
      refreshEveningNotification();
    });
    return unsubscribe;
  }, []);

  const toggleFocusMode = useCallback(() => {
    setIsDoNotDisturb((prev) => {
      const next = !prev;
      setItem(KEY_FOCUS_MODE, next ? '1' : '0');
      refreshEveningNotification();
      return next;
    });
  }, []);

  return (
    <FocusModeContext.Provider value={{ isDoNotDisturb, toggleFocusMode, loading }}>
      {children}
    </FocusModeContext.Provider>
  );
}

export function useFocusMode() {
  return useContext(FocusModeContext);
}

export default FocusModeContext;
