// src/context/GoogleAuthContext.js
import React, {
  createContext, useContext, useEffect, useState, useCallback,
} from 'react';
import * as AuthSession from 'expo-auth-session';
import * as WebBrowser from 'expo-web-browser';
import {
  GOOGLE_OAUTH_CONFIG, GOOGLE_CALENDAR_SCOPES, GOOGLE_DISCOVERY,
} from '../config/googleConfig';
import {
  isSignedIn as checkIsSignedIn,
  exchangeCodeForTokens,
  signOut as authSignOut,
} from '../services/googleAuthService';

WebBrowser.maybeCompleteAuthSession();

const GoogleAuthContext = createContext(null);

const redirectUri = AuthSession.makeRedirectUri({ scheme: 'torahtracker' });

export function GoogleAuthProvider({ children }) {
  const [isSignedIn, setIsSignedIn] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  const [request, response, promptAsync] = AuthSession.useAuthRequest(
    {
      clientId: GOOGLE_OAUTH_CONFIG.webClientId,
      iosClientId: GOOGLE_OAUTH_CONFIG.iosClientId,
      androidClientId: GOOGLE_OAUTH_CONFIG.androidClientId,
      scopes: [...GOOGLE_CALENDAR_SCOPES, 'openid', 'email'],
      redirectUri,
      responseType: AuthSession.ResponseType.Code,
      usePKCE: true,
      extraParams: { access_type: 'offline', prompt: 'consent' },
    },
    GOOGLE_DISCOVERY
  );

  useEffect(() => {
    checkIsSignedIn().then((signedIn) => {
      setIsSignedIn(signedIn);
      setIsLoading(false);
    });
  }, []);

  useEffect(() => {
    async function handleResponse() {
      if (response?.type === 'success' && request?.codeVerifier) {
        setIsAuthenticating(true);
        try {
          await exchangeCodeForTokens(response.params.code, request.codeVerifier, redirectUri);
          setIsSignedIn(true);
        } finally {
          setIsAuthenticating(false);
        }
      }
    }
    handleResponse();
  }, [response, request]);

  const signIn = useCallback(async () => {
    await promptAsync();
  }, [promptAsync]);

  const signOut = useCallback(async () => {
    await authSignOut();
    setIsSignedIn(false);
  }, []);

  return (
    <GoogleAuthContext.Provider
      value={{ isSignedIn, isLoading, isAuthenticating, signIn, signOut }}
    >
      {children}
    </GoogleAuthContext.Provider>
  );
}

export function useGoogleAuth() {
  const ctx = useContext(GoogleAuthContext);
  if (!ctx) throw new Error('useGoogleAuth must be used within a GoogleAuthProvider');
  return ctx;
}

export default GoogleAuthContext;
