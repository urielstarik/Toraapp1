// src/data/quotes.js
// Inspirational quotes shown one-per-day (rotates at midnight).
// Text kept exactly as provided — do not alter.

export const QUOTES = [
  'בזכות התורה ולומדיה ינצל העולם',
  'כי הם חיינו ואורך ימינו',
  'כי הוא תכלית רעיון והשלמת הגיון לרומם הנעלה מערך ודמיון',
  'עץ חיים היא למחזיקים בה ותומכיה מאושר',
  'תורת השם תמימה משיבת נפש',
  'לכו לחמו בלחמי ושתו ביין מסכתי',
];

export default QUOTES;
