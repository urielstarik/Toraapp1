// src/data/topics.seed.js
// Default mandatory study topics, pre-populated on first app launch.
// type: 'fixed'    -> daily obligatory learning (cannot be deleted by user)
// type: 'flexible' -> can be reordered / customized later

export const DEFAULT_TOPICS = [
  {
    id: 'topic_gemara',
    name: 'גמרא (דף יומי)',
    icon: 'book-open',
    type: 'fixed',
    sync_source: 'daf_yomi',
  },
  {
    id: 'topic_mishna_berura',
    name: 'משנה ברורה',
    icon: 'book',
    type: 'fixed',
  },
  {
    id: 'topic_etz_chaim',
    name: 'עץ חיים',
    icon: 'feather',
    type: 'fixed',
  },
  {
    id: 'topic_tehillim',
    name: 'תהילים',
    icon: 'music',
    type: 'fixed',
    sync_source: 'tehillim_cycle',
  },
  {
    id: 'topic_zohar',
    name: 'זוהר',
    icon: 'sun',
    type: 'fixed',
  },
];

export default DEFAULT_TOPICS;
