// src/data/trackTemplates.js
//
// Pre-populated templates for the "מאגר הספקים" (Track Store) screen.
// syncSource, when set, wires the resulting topic into the dynamic
// daily-label generators (src/services/dailyLabelGenerators.js), so its
// daily task is auto-filled from a live external source rather than
// requiring manual entry.

export const TRACK_TEMPLATES = [
  {
    id: 'tmpl_daf_yomi',
    name: 'דף יומי בבלי',
    icon: 'book-open',
    syncSource: 'daf_yomi',
    description: 'דף גמרא אחד ליום, מסונכרן אוטומטית ללוח הדף היומי העולמי.',
  },
  {
    id: 'tmpl_mishna_berura',
    name: 'משנה ברורה',
    icon: 'book',
    syncSource: null,
    description: 'לימוד הלכה יומי בקצב אישי, עם מקום לרשום את הסימן הנלמד.',
  },
  {
    id: 'tmpl_tehillim',
    name: 'תהילים יומי',
    icon: 'music',
    syncSource: 'tehillim_cycle',
    description: 'חלוקה חודשית מלאה של ספר תהילים, מתעדכנת לפי היום בחודש העברי.',
  },
  {
    id: 'tmpl_mishna_yomi',
    name: 'משנה יומית',
    icon: 'feather',
    syncSource: 'mishna_yomi',
    description: 'שתי משניות ליום, מסונכרן ללוח המשנה היומית העולמי.',
  },
];

export default TRACK_TEMPLATES;
