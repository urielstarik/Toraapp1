// src/database/db.js
//
// SQLite schema + initialization for the app.
//
// Tables:
//   topics    - study subjects (fixed or flexible)
//   tasks     - one row per topic per day, tracks completion status
//   kv_store  - tiny generic key/value table (used e.g. for daily quote cache)

import * as SQLite from 'expo-sqlite';
import { DEFAULT_TOPICS } from '../data/topics.seed';

const DB_NAME = 'torah_tracker.db';
let dbInstance = null;

export async function getDb() {
  if (!dbInstance) {
    dbInstance = await SQLite.openDatabaseAsync(DB_NAME);
  }
  return dbInstance;
}

export async function initDatabase() {
  const db = await getDb();

  await db.execAsync(`
    PRAGMA journal_mode = WAL;

    CREATE TABLE IF NOT EXISTS topics (
      id       TEXT PRIMARY KEY NOT NULL,
      name     TEXT NOT NULL,
      icon     TEXT,
      type     TEXT NOT NULL CHECK (type IN ('fixed', 'flexible')),
      sort_order INTEGER DEFAULT 0,
      sync_source TEXT,          -- e.g. 'daf_yomi', 'tehillim_cycle'; NULL = no global cycle
      board_id TEXT              -- e.g. 'שגרת חול'; NULL = not assigned to any board
    );

    -- Custom boards/lists a user can group topics under (e.g. "שגרת חול",
    -- "הספקים חודש אלול"), selectable from the tab bar on the Dashboard.
    CREATE TABLE IF NOT EXISTS boards (
      id         TEXT PRIMARY KEY NOT NULL,
      name       TEXT NOT NULL,
      sort_order INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS tasks (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      topic_id   TEXT NOT NULL,
      date       TEXT NOT NULL,               -- 'YYYY-MM-DD'
      status     TEXT NOT NULL CHECK (status IN ('completed', 'pending', 'overdue')) DEFAULT 'pending',
      note_text  TEXT,
      FOREIGN KEY (topic_id) REFERENCES topics (id) ON DELETE CASCADE,
      UNIQUE (topic_id, date)
    );

    CREATE INDEX IF NOT EXISTS idx_tasks_date ON tasks (date);
    CREATE INDEX IF NOT EXISTS idx_tasks_topic ON tasks (topic_id);

    CREATE TABLE IF NOT EXISTS kv_store (
      key   TEXT PRIMARY KEY NOT NULL,
      value TEXT
    );

    -- One row per item that has appeared in the Daily Schedule planner,
    -- either still unplaced in the Task Bank (start_minute IS NULL) or
    -- placed on the timeline (start_minute + duration_minutes set).
    CREATE TABLE IF NOT EXISTS schedule_items (
      id               INTEGER PRIMARY KEY AUTOINCREMENT,
      date             TEXT NOT NULL,             -- 'YYYY-MM-DD'
      title            TEXT NOT NULL,
      icon             TEXT,
      kind             TEXT NOT NULL CHECK (kind IN ('study', 'custom')),
      task_id          INTEGER,                   -- set when kind = 'study'
      start_minute     INTEGER,                    -- minutes after midnight; NULL = in Task Bank
      duration_minutes INTEGER,
      google_event_id  TEXT,                       -- set once pushed to Google Calendar
      calendar_title   TEXT,                       -- exact title used on the Google event (pre-checkmark)
      FOREIGN KEY (task_id) REFERENCES tasks (id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_schedule_items_date ON schedule_items (date);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_schedule_items_task_date
      ON schedule_items (task_id, date) WHERE task_id IS NOT NULL;
  `);

  await migrateAddSyncSourceColumn(db);
  await migrateAddGoogleSyncColumns(db);
  await migrateAddBoardIdColumn(db);
  await seedTopicsIfEmpty(db);
  return db;
}

// Safe, idempotent migration for installs created before sync_source existed.
async function migrateAddSyncSourceColumn(db) {
  const columns = await db.getAllAsync('PRAGMA table_info(topics)');
  const hasColumn = columns.some((c) => c.name === 'sync_source');
  if (!hasColumn) {
    await db.execAsync('ALTER TABLE topics ADD COLUMN sync_source TEXT');
  }
}

// Safe, idempotent migration for installs created before boards existed.
async function migrateAddBoardIdColumn(db) {
  const columns = await db.getAllAsync('PRAGMA table_info(topics)');
  const hasColumn = columns.some((c) => c.name === 'board_id');
  if (!hasColumn) {
    await db.execAsync('ALTER TABLE topics ADD COLUMN board_id TEXT');
  }
}

// Safe, idempotent migration for installs created before Google Calendar
// sync existed.
async function migrateAddGoogleSyncColumns(db) {
  const columns = await db.getAllAsync('PRAGMA table_info(schedule_items)');
  const names = columns.map((c) => c.name);
  if (!names.includes('google_event_id')) {
    await db.execAsync('ALTER TABLE schedule_items ADD COLUMN google_event_id TEXT');
  }
  if (!names.includes('calendar_title')) {
    await db.execAsync('ALTER TABLE schedule_items ADD COLUMN calendar_title TEXT');
  }
}

async function seedTopicsIfEmpty(db) {
  const row = await db.getFirstAsync('SELECT COUNT(*) as count FROM topics');
  if (row && row.count > 0) return;

  for (let i = 0; i < DEFAULT_TOPICS.length; i++) {
    const t = DEFAULT_TOPICS[i];
    await db.runAsync(
      'INSERT INTO topics (id, name, icon, type, sort_order, sync_source) VALUES (?, ?, ?, ?, ?, ?)',
      [t.id, t.name, t.icon, t.type, i, t.sync_source ?? null]
    );
  }
}

export default { getDb, initDatabase };
