// src/database/kv.js
// Minimal async key/value helper backed by the kv_store SQLite table.

import { getDb } from './db';

export async function getItem(key) {
  const db = await getDb();
  const row = await db.getFirstAsync('SELECT value FROM kv_store WHERE key = ?', [key]);
  return row ? row.value : null;
}

export async function setItem(key, value) {
  const db = await getDb();
  await db.runAsync(
    'INSERT INTO kv_store (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value',
    [key, value]
  );
}

export async function deleteItem(key) {
  const db = await getDb();
  await db.runAsync('DELETE FROM kv_store WHERE key = ?', [key]);
}

export default { getItem, setItem, deleteItem };
