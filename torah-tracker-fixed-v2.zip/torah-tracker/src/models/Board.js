// src/models/Board.js
import { getDb } from '../database/db';

export async function getAllBoards() {
  const db = await getDb();
  return db.getAllAsync('SELECT * FROM boards ORDER BY sort_order ASC');
}

export async function createBoard(name) {
  const db = await getDb();
  const id = `board_${name.trim().toLowerCase().replace(/\s+/g, '_')}_${Date.now()}`;
  const row = await db.getFirstAsync('SELECT COUNT(*) as count FROM boards');
  const sortOrder = row ? row.count : 0;
  await db.runAsync(
    'INSERT INTO boards (id, name, sort_order) VALUES (?, ?, ?)',
    [id, name.trim(), sortOrder]
  );
  return id;
}

export async function deleteBoard(id) {
  const db = await getDb();
  // Topics that were in this board simply become unassigned again —
  // they're never deleted along with the board.
  await db.runAsync('UPDATE topics SET board_id = NULL WHERE board_id = ?', [id]);
  await db.runAsync('DELETE FROM boards WHERE id = ?', [id]);
}

export async function assignTopicToBoard(topicId, boardId) {
  const db = await getDb();
  await db.runAsync('UPDATE topics SET board_id = ? WHERE id = ?', [boardId, topicId]);
}

export default { getAllBoards, createBoard, deleteBoard, assignTopicToBoard };
