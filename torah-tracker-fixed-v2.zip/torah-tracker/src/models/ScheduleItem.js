// src/models/ScheduleItem.js
import { getDb } from '../database/db';
import { todayDateString } from './Task';

// --- Task Bank (unplaced items) --------------------------------------

// Today's pending study tasks that don't yet have a schedule_items row
// (i.e. haven't been dragged onto the timeline) — plus any unplaced
// custom activities added via the "+" button.
export async function getUnplacedItemsForDate(date = todayDateString()) {
  const db = await getDb();

  const studyItems = await db.getAllAsync(
    `SELECT
       tasks.id            AS task_id,
       tasks.note_text     AS note_text,
       topics.name         AS topic_name,
       topics.icon         AS icon
     FROM tasks
     JOIN topics ON topics.id = tasks.topic_id
     LEFT JOIN schedule_items
       ON schedule_items.task_id = tasks.id AND schedule_items.date = tasks.date
     WHERE tasks.date = ?
       AND tasks.status = 'pending'
       AND schedule_items.id IS NULL
     ORDER BY topics.sort_order ASC`,
    [date]
  );

  const customItems = await db.getAllAsync(
    `SELECT id, title, icon
     FROM schedule_items
     WHERE date = ? AND kind = 'custom' AND start_minute IS NULL
     ORDER BY id ASC`,
    [date]
  );

  return [
    ...studyItems.map((t) => ({
      key: `study-${t.task_id}`,
      kind: 'study',
      taskId: t.task_id,
      // Display title (shown in the app) can include the note; the
      // Google Calendar event uses topicName alone, per spec.
      title: t.note_text ? `${t.topic_name} — ${t.note_text}` : t.topic_name,
      topicName: t.topic_name,
      icon: t.icon,
    })),
    ...customItems.map((c) => ({
      key: `custom-${c.id}`,
      kind: 'custom',
      scheduleItemId: c.id,
      title: c.title,
      topicName: c.title, // custom activities use their own name as the calendar title too
      icon: c.icon,
    })),
  ];
}

// Adds a general (non-study) activity to the Task Bank, unplaced.
export async function addCustomActivity({ title, icon, date = todayDateString() }) {
  const db = await getDb();
  const result = await db.runAsync(
    `INSERT INTO schedule_items (date, title, icon, kind, start_minute, duration_minutes)
     VALUES (?, ?, ?, 'custom', NULL, NULL)`,
    [date, title, icon ?? null]
  );
  return result.lastInsertRowId;
}

// --- Timeline (placed blocks) -----------------------------------------

export async function getPlacedBlocksForDate(date = todayDateString()) {
  const db = await getDb();
  return db.getAllAsync(
    `SELECT * FROM schedule_items
     WHERE date = ? AND start_minute IS NOT NULL
     ORDER BY start_minute ASC`,
    [date]
  );
}

// Places a Task Bank item onto the timeline. For a 'study' item this is
// the first time a schedule_items row is created for it; for a 'custom'
// item that already has an unplaced row, pass scheduleItemId to update it.
// calendarTitle is the exact title to use for the linked Google Calendar
// event (topic name for study items; the activity name for custom ones).
export async function placeItem({
  scheduleItemId, kind, taskId, title, icon, calendarTitle, date, startMinute, durationMinutes,
}) {
  const db = await getDb();
  if (scheduleItemId) {
    await db.runAsync(
      'UPDATE schedule_items SET start_minute = ?, duration_minutes = ?, calendar_title = ? WHERE id = ?',
      [startMinute, durationMinutes, calendarTitle ?? title, scheduleItemId]
    );
    return scheduleItemId;
  }
  const result = await db.runAsync(
    `INSERT INTO schedule_items (date, title, icon, kind, task_id, start_minute, duration_minutes, calendar_title)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [date, title, icon ?? null, kind, taskId ?? null, startMinute, durationMinutes, calendarTitle ?? title]
  );
  return result.lastInsertRowId;
}

// Records the Google Calendar event id created for a placed block.
export async function setGoogleEventId(scheduleItemId, googleEventId) {
  const db = await getDb();
  await db.runAsync(
    'UPDATE schedule_items SET google_event_id = ? WHERE id = ?',
    [googleEventId, scheduleItemId]
  );
}

// Finds the schedule_items row linked to a given task (if any), used to
// look up whether a completed task has a Google Calendar event to update.
export async function getScheduleItemForTask(taskId, date) {
  const db = await getDb();
  return db.getFirstAsync(
    'SELECT * FROM schedule_items WHERE task_id = ? AND date = ?',
    [taskId, date]
  );
}

// Moves a placed block to a new start time (dragging the whole block).
export async function updateBlockStart(id, startMinute) {
  const db = await getDb();
  await db.runAsync('UPDATE schedule_items SET start_minute = ? WHERE id = ?', [startMinute, id]);
}

// Resizes/repositions a placed block (dragging an edge handle).
export async function updateBlockTiming(id, startMinute, durationMinutes) {
  const db = await getDb();
  await db.runAsync(
    'UPDATE schedule_items SET start_minute = ?, duration_minutes = ? WHERE id = ?',
    [startMinute, durationMinutes, id]
  );
}

// Un-places a block back into the Task Bank (kept in case it's useful
// later, e.g. a "remove from timeline" action).
export async function unplaceBlock(id, isCustom) {
  const db = await getDb();
  if (isCustom) {
    await db.runAsync(
      'UPDATE schedule_items SET start_minute = NULL, duration_minutes = NULL WHERE id = ?',
      [id]
    );
  } else {
    await db.runAsync('DELETE FROM schedule_items WHERE id = ?', [id]);
  }
}

// --- Dashboard sync -----------------------------------------------------

export function currentMinuteOfDay(date = new Date()) {
  return date.getHours() * 60 + date.getMinutes();
}

// The next chronologically scheduled block for today, relative to now.
export async function getNextUpcomingBlock(date, nowMinute) {
  const resolvedDate = date ?? todayDateString();
  const resolvedMinute = nowMinute ?? currentMinuteOfDay();
  const db = await getDb();
  return db.getFirstAsync(
    `SELECT * FROM schedule_items
     WHERE date = ? AND start_minute IS NOT NULL AND start_minute >= ?
     ORDER BY start_minute ASC
     LIMIT 1`,
    [resolvedDate, resolvedMinute]
  );
}

export default {
  getUnplacedItemsForDate,
  addCustomActivity,
  getPlacedBlocksForDate,
  placeItem,
  updateBlockStart,
  updateBlockTiming,
  unplaceBlock,
  getNextUpcomingBlock,
  currentMinuteOfDay,
  setGoogleEventId,
  getScheduleItemForTask,
};
