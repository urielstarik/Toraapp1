// src/models/Task.js
import { getDb } from '../database/db';

export function todayDateString(d = new Date()) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

// Get (or lazily create as 'pending') today's task row for a given topic.
export async function getOrCreateTaskForToday(topicId) {
  const db = await getDb();
  const date = todayDateString();
  let task = await db.getFirstAsync(
    'SELECT * FROM tasks WHERE topic_id = ? AND date = ?',
    [topicId, date]
  );
  if (!task) {
    await db.runAsync(
      'INSERT INTO tasks (topic_id, date, status) VALUES (?, ?, ?)',
      [topicId, date, 'pending']
    );
    task = await db.getFirstAsync(
      'SELECT * FROM tasks WHERE topic_id = ? AND date = ?',
      [topicId, date]
    );
  }
  return task;
}

export async function getTasksForDate(date) {
  const db = await getDb();
  return db.getAllAsync(
    `SELECT tasks.*, topics.name as topic_name, topics.icon as topic_icon
     FROM tasks
     JOIN topics ON topics.id = tasks.topic_id
     WHERE tasks.date = ?
     ORDER BY topics.sort_order ASC`,
    [date]
  );
}

export async function setTaskStatus(taskId, status, noteText = null) {
  const db = await getDb();
  await db.runAsync(
    'UPDATE tasks SET status = ?, note_text = ? WHERE id = ?',
    [status, noteText, taskId]
  );
}

// Marks any 'pending' task with a date before today as 'overdue'.
// Intended to be run once per app launch / daily background check.
export async function markPastPendingAsOverdue() {
  const db = await getDb();
  const today = todayDateString();
  await db.runAsync(
    "UPDATE tasks SET status = 'overdue' WHERE status = 'pending' AND date < ?",
    [today]
  );
}

// Total count of tasks currently marked 'overdue' (any date before today).
export async function getOverdueCount() {
  const db = await getDb();
  const row = await db.getFirstAsync(
    "SELECT COUNT(*) as count FROM tasks WHERE status = 'overdue'"
  );
  return row ? row.count : 0;
}

// { completed, total } for today's date — drives the progress ring.
export async function getTodayProgress() {
  const db = await getDb();
  const date = todayDateString();
  const row = await db.getFirstAsync(
    `SELECT
       COUNT(*) as total,
       SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
     FROM tasks WHERE date = ?`,
    [date]
  );
  return {
    completed: row?.completed ?? 0,
    total: row?.total ?? 0,
  };
}

// All overdue tasks for one topic, oldest first — feeds the "חוסרים" list.
export async function getOverdueTasksForTopic(topicId) {
  const db = await getDb();
  return db.getAllAsync(
    "SELECT * FROM tasks WHERE topic_id = ? AND status = 'overdue' ORDER BY date ASC",
    [topicId]
  );
}

// Toggle a task between 'completed' and its natural incomplete state
// ('pending' for today, 'overdue' for a past date), preserving/saving
// whatever note text was typed in the hybrid input alongside it.
export async function toggleTaskCompletion(task, noteText) {
  const today = todayDateString();
  const revertStatus = task.date < today ? 'overdue' : 'pending';
  const newStatus = task.status === 'completed' ? revertStatus : 'completed';
  await setTaskStatus(task.id, newStatus, noteText ?? task.note_text ?? null);
  return newStatus;
}

// Persist just the note text without changing the current status
// (used when the user edits the hybrid input without toggling the box).
export async function updateTaskNote(taskId, status, noteText) {
  await setTaskStatus(taskId, status, noteText);
}

// Ensures a task row exists for a topic on a given date. If it doesn't
// exist yet, creates it as 'pending' with the given preset note text
// (used by the rollover service to seed global-cycle labels like Daf
// Yomi). Never overwrites an existing row's note/status.
export async function ensureTaskForTopicAndDate(topicId, date, presetNote = null) {
  const db = await getDb();
  let task = await db.getFirstAsync(
    'SELECT * FROM tasks WHERE topic_id = ? AND date = ?',
    [topicId, date]
  );
  if (!task) {
    await db.runAsync(
      'INSERT INTO tasks (topic_id, date, status, note_text) VALUES (?, ?, ?, ?)',
      [topicId, date, 'pending', presetNote]
    );
    task = await db.getFirstAsync(
      'SELECT * FROM tasks WHERE topic_id = ? AND date = ?',
      [topicId, date]
    );
  }
  return task;
}

// Batch inserts/updates tasks from a parsed CSV import. Each row is
// { topicId, date, taskText }. If a task already exists for that
// topic+date, only its note_text is updated (status/completion is left
// alone, so re-importing never un-completes something the user already
// finished). Otherwise a fresh 'pending' task is created with the note.
// Returns the count actually written.
export async function batchImportTasks(rows) {
  const db = await getDb();
  let written = 0;

  for (const row of rows) {
    const existing = await db.getFirstAsync(
      'SELECT id FROM tasks WHERE topic_id = ? AND date = ?',
      [row.topicId, row.date]
    );
    if (existing) {
      await db.runAsync('UPDATE tasks SET note_text = ? WHERE id = ?', [row.taskText, existing.id]);
    } else {
      await db.runAsync(
        'INSERT INTO tasks (topic_id, date, status, note_text) VALUES (?, ?, ?, ?)',
        [row.topicId, row.date, 'pending', row.taskText]
      );
    }
    written += 1;
  }

  return written;
}

export default {
  getOrCreateTaskForToday,
  getTasksForDate,
  setTaskStatus,
  markPastPendingAsOverdue,
  getOverdueCount,
  getTodayProgress,
  getOverdueTasksForTopic,
  toggleTaskCompletion,
  updateTaskNote,
  ensureTaskForTopicAndDate,
  batchImportTasks,
};
