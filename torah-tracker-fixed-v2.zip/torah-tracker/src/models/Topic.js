// src/models/Topic.js
import { getDb } from '../database/db';

export async function getAllTopics() {
  const db = await getDb();
  return db.getAllAsync('SELECT * FROM topics ORDER BY sort_order ASC');
}

export async function getTopicById(id) {
  const db = await getDb();
  return db.getFirstAsync('SELECT * FROM topics WHERE id = ?', [id]);
}

export async function createTopic({
  id, name, icon, type = 'flexible', sortOrder = 0, syncSource = null,
}) {
  const db = await getDb();
  await db.runAsync(
    'INSERT INTO topics (id, name, icon, type, sort_order, sync_source) VALUES (?, ?, ?, ?, ?, ?)',
    [id, name, icon ?? null, type, sortOrder, syncSource]
  );
}

export async function getTopicByName(name) {
  const db = await getDb();
  return db.getFirstAsync(
    'SELECT * FROM topics WHERE lower(trim(name)) = lower(trim(?))',
    [name]
  );
}

export async function updateTopic(id, { name, icon }) {
  const db = await getDb();
  await db.runAsync('UPDATE topics SET name = ?, icon = ? WHERE id = ?', [name, icon ?? null, id]);
}

export async function deleteTopic(id) {
  // Fixed (mandatory) topics are protected from deletion.
  const db = await getDb();
  const topic = await getTopicById(id);
  if (!topic) return;
  if (topic.type === 'fixed') {
    throw new Error('לא ניתן למחוק נושא לימוד קבוע');
  }
  await db.runAsync('DELETE FROM topics WHERE id = ?', [id]);
}

export default {
  getAllTopics, getTopicById, getTopicByName, createTopic, updateTopic, deleteTopic,
};
