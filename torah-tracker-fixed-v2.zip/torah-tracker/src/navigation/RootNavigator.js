// src/navigation/RootNavigator.js
import React, { useEffect, useState, useRef } from 'react';
import { View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DashboardScreen from '../screens/DashboardScreen';
import TopicDetailsScreen from '../screens/TopicDetailsScreen';
import ScheduleScreen from '../screens/ScheduleScreen';
import SettingsScreen from '../screens/SettingsScreen';
import HelpScreen from '../screens/HelpScreen';
import TrackStoreScreen from '../screens/TrackStoreScreen';
import AboutScreen from '../screens/AboutScreen';
import colors from '../theme/colors';
import { fontFamilies } from '../theme/fonts';

const Stack = createNativeStackNavigator();

// Bump this if the screen/route structure changes in a way that could
// make a previously-saved state invalid (e.g. a renamed or removed
// screen) — a mismatch falls back to a fresh start instead of crashing.
const NAV_STATE_KEY = 'navigation_state_v1';
const NAV_PERSIST_DEBOUNCE_MS = 300;

const KNOWN_ROUTE_NAMES = new Set([
  'Dashboard', 'TopicDetails', 'Schedule', 'Settings', 'Help', 'TrackStore', 'About',
]);

function isStateValid(state) {
  if (!state?.routes) return false;
  return state.routes.every((route) => {
    if (!KNOWN_ROUTE_NAMES.has(route.name)) return false;
    // Nested navigator state (shouldn't occur in this flat stack, but
    // validated defensively in case that changes later).
    if (route.state) return isStateValid(route.state);
    return true;
  });
}

export default function RootNavigator() {
  const [isReady, setIsReady] = useState(false);
  const [initialState, setInitialState] = useState();
  const saveTimer = useRef(null);

  useEffect(() => {
    (async () => {
      try {
        const saved = await AsyncStorage.getItem(NAV_STATE_KEY);
        if (saved) {
          const parsed = JSON.parse(saved);
          if (isStateValid(parsed)) {
            setInitialState(parsed);
          } else {
            await AsyncStorage.removeItem(NAV_STATE_KEY);
          }
        }
      } catch (err) {
        // Corrupt/unreadable saved state — just start fresh on the Dashboard.
      } finally {
        setIsReady(true);
      }
    })();
  }, []);

  const handleStateChange = (state) => {
    // Debounced so rapid navigation transitions don't spam storage writes.
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      AsyncStorage.setItem(NAV_STATE_KEY, JSON.stringify(state)).catch(() => {});
    }, NAV_PERSIST_DEBOUNCE_MS);
  };

  if (!isReady) {
    return <View style={{ flex: 1, backgroundColor: colors.background }} />;
  }

  return (
    <NavigationContainer initialState={initialState} onStateChange={handleStateChange}>
      <Stack.Navigator
        screenOptions={{
          headerStyle: { backgroundColor: colors.background },
          headerShadowVisible: false,
          headerTintColor: colors.primary,
          headerTitleStyle: { fontFamily: fontFamilies.sansHebrewMedium },
          headerBackTitleVisible: false,
          contentStyle: { backgroundColor: colors.background },
        }}
      >
        <Stack.Screen
          name="Dashboard"
          component={DashboardScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="TopicDetails"
          component={TopicDetailsScreen}
          options={{ title: 'נושא לימוד' }}
        />
        <Stack.Screen
          name="Schedule"
          component={ScheduleScreen}
          options={{ title: 'תכנון לו"ז יומי' }}
        />
        <Stack.Screen
          name="Settings"
          component={SettingsScreen}
          options={{ title: 'הגדרות' }}
        />
        <Stack.Screen
          name="Help"
          component={HelpScreen}
          options={{ title: 'עזרה והסבר' }}
        />
        <Stack.Screen
          name="TrackStore"
          component={TrackStoreScreen}
          options={{ title: 'מאגר הספקים' }}
        />
        <Stack.Screen
          name="About"
          component={AboutScreen}
          options={{ title: 'אודות' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
