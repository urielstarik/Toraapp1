// src/screens/AboutScreen.js
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Linking, Alert } from 'react-native';
import { Feather } from '@expo/vector-icons';
import colors from '../theme/colors';
import { typography } from '../theme/fonts';

const CONTACT_ACTIONS = [
  { key: 'phone', label: 'התקשר', icon: 'phone', url: 'tel:+972525253767' },
  { key: 'whatsapp', label: 'וואטסאפ', icon: 'message-circle', url: 'https://wa.me/972525253767' },
  { key: 'email', label: 'אימייל', icon: 'mail', url: 'mailto:Uriel.starik@gmail.com' },
];

async function handleOpenLink(url) {
  try {
    const supported = await Linking.canOpenURL(url);
    if (supported) {
      await Linking.openURL(url);
    } else {
      Alert.alert('לא ניתן לפתוח', 'לא נמצאה אפליקציה מתאימה לפעולה זו במכשיר.');
    }
  } catch (err) {
    Alert.alert('שגיאה', 'אירעה שגיאה בניסיון לפתוח את הקישור.');
  }
}

export default function AboutScreen() {
  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
      <View style={styles.logoWrap}>
        <Feather name="book-open" size={40} color={colors.primary} />
      </View>

      <Text style={[typography.topicTitle, styles.appName]}>מעקב הספקים</Text>

      <Text style={[typography.body, styles.statement]}>
        האפליקציה נבנתה על ידי אוריאל סטריק שלא למטרות רווח
      </Text>

      <Text style={[typography.label, styles.contactHeading]}>יצירת קשר</Text>

      <View style={styles.buttonsRow}>
        {CONTACT_ACTIONS.map((action) => (
          <TouchableOpacity
            key={action.key}
            style={styles.contactButton}
            onPress={() => handleOpenLink(action.url)}
            activeOpacity={0.85}
            accessibilityRole="button"
            accessibilityLabel={action.label}
          >
            <Feather name={action.icon} size={20} color={colors.primary} />
            <Text style={[typography.label, styles.contactButtonText]}>{action.label}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: 24,
    paddingTop: 40,
    alignItems: 'center',
  },
  logoWrap: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: colors.surfaceAlt,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  appName: {
    color: colors.textPrimary,
    fontSize: 20,
    marginBottom: 20,
  },
  statement: {
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 36,
    paddingHorizontal: 12,
  },
  contactHeading: {
    color: colors.textSecondary,
    marginBottom: 14,
  },
  buttonsRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'center',
    gap: 12,
  },
  contactButton: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.surface,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.divider,
    paddingVertical: 16,
    paddingHorizontal: 20,
    minWidth: 92,
  },
  contactButtonText: {
    color: colors.primary,
    marginTop: 8,
  },
});
