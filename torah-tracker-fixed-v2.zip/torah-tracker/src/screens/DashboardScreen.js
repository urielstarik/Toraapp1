// src/screens/DashboardScreen.js
import React, { useCallback, useEffect, useState, useMemo } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, StatusBar, Alert } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { getAllTopics, createTopic, updateTopic, deleteTopic } from '../models/Topic';
import {
  getOrCreateTaskForToday,
  markPastPendingAsOverdue,
  getOverdueCount,
  getTodayProgress,
} from '../models/Task';
import { getAllBoards, createBoard, assignTopicToBoard } from '../models/Board';
import { getDailyQuote, msUntilNextMidnight } from '../utils/dailyQuote';
import { formatDualDate } from '../utils/dateFormat';
import { subscribeToRollover } from '../services/rolloverBus';
import { getNextUpcomingBlock } from '../models/ScheduleItem';
import { formatHM } from '../components/schedule/timelineConstants';
import { maybeCreateAchievementEvent } from '../services/googleCalendarSync';
import colors from '../theme/colors';
import { typography } from '../theme/fonts';

import DashboardHeader from '../components/DashboardHeader';
import BoardTabs, { ALL_BOARDS_ID } from '../components/BoardTabs';
import ProgressRing from '../components/ProgressRing';
import OverdueAlert from '../components/OverdueAlert';
import SchedulePlannerButton from '../components/SchedulePlannerButton';
import TopicsGrid from '../components/TopicsGrid';
import TrackStoreButton from '../components/TrackStoreButton';
import AddTopicModal from '../components/AddTopicModal';
import EditTopicModal from '../components/EditTopicModal';
import AddBoardModal from '../components/AddBoardModal';
import BoardPickerModal from '../components/BoardPickerModal';

function slugify(name) {
  const base = name
    .trim()
    .toLowerCase()
    .replace(/\s+/g, '_')
    .replace(/[^\w\u0590-\u05FF_]/g, '');
  return `topic_${base || 'custom'}_${Date.now()}`;
}

export default function DashboardScreen({ navigation }) {
  const [quote, setQuote] = useState('');
  const [dualDate, setDualDate] = useState(formatDualDate());
  const [topics, setTopics] = useState([]);
  const [boards, setBoards] = useState([]);
  const [selectedBoardId, setSelectedBoardId] = useState(ALL_BOARDS_ID);
  const [progress, setProgress] = useState({ completed: 0, total: 0 });
  const [overdueCount, setOverdueCount] = useState(0);
  const [modalVisible, setModalVisible] = useState(false);
  const [addBoardModalVisible, setAddBoardModalVisible] = useState(false);
  const [boardPickerTopic, setBoardPickerTopic] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [editingTopic, setEditingTopic] = useState(null);
  const [nextUpcoming, setNextUpcoming] = useState(null); // { title, start_minute } | null

  const refreshNextUpcoming = useCallback(async () => {
    const block = await getNextUpcomingBlock();
    setNextUpcoming(block || null);
  }, []);

  const refreshDashboardData = useCallback(async () => {
    await markPastPendingAsOverdue();

    const [allTopics, allBoards] = await Promise.all([getAllTopics(), getAllBoards()]);
    await Promise.all(allTopics.map((t) => getOrCreateTaskForToday(t.id)));

    const [todayProgress, overdue] = await Promise.all([
      getTodayProgress(),
      getOverdueCount(),
    ]);

    setTopics(allTopics);
    setBoards(allBoards);
    setProgress(todayProgress);
    setOverdueCount(overdue);

    // Listens to the daily progress state: the moment it reaches 100%,
    // this creates the all-day achievement event (idempotent — only
    // fires once per day, see maybeCreateAchievementEvent).
    maybeCreateAchievementEvent(todayProgress.completed, todayProgress.total);
  }, []);

  useEffect(() => {
    let quoteMidnightTimer;

    async function bootstrap() {
      await refreshDashboardData();
      await refreshNextUpcoming();
      setQuote(await getDailyQuote());

      quoteMidnightTimer = setTimeout(async () => {
        setQuote(await getDailyQuote());
        setDualDate(formatDualDate());
      }, msUntilNextMidnight());
    }

    bootstrap();
    return () => quoteMidnightTimer && clearTimeout(quoteMidnightTimer);
  }, [refreshDashboardData, refreshNextUpcoming]);

  // Instant refresh the moment a rollover completes (midnight while the
  // app is open, or a foreground re-check) — no manual restart needed.
  useEffect(() => {
    const unsubscribe = subscribeToRollover(() => {
      refreshDashboardData();
      refreshNextUpcoming();
      setDualDate(formatDualDate());
    });
    return unsubscribe;
  }, [refreshDashboardData, refreshNextUpcoming]);

  // Re-sync progress/overdue counts (and the next-upcoming label) whenever
  // the user returns from Topic Details or the Schedule planner.
  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      refreshDashboardData();
      refreshNextUpcoming();
    });
    return unsubscribe;
  }, [navigation, refreshDashboardData, refreshNextUpcoming]);

  // As the clock moves forward, "next upcoming" should advance past any
  // block whose start time has now arrived, even without navigating away.
  useEffect(() => {
    const interval = setInterval(refreshNextUpcoming, 60 * 1000);
    return () => clearInterval(interval);
  }, [refreshNextUpcoming]);

  // Exit edit mode whenever the user navigates away, so it doesn't linger
  // confusingly the next time they land back on the Dashboard mid-flow.
  useEffect(() => {
    const unsubscribe = navigation.addListener('blur', () => setEditMode(false));
    return unsubscribe;
  }, [navigation]);

  const visibleTopics = useMemo(() => {
    if (selectedBoardId === ALL_BOARDS_ID) return topics;
    return topics.filter((t) => t.board_id === selectedBoardId);
  }, [topics, selectedBoardId]);

  const handleAddTopic = async ({ name, icon }) => {
    await createTopic({ id: slugify(name), name, icon, type: 'flexible' });
    setModalVisible(false);
    await refreshDashboardData();
  };

  const handleAddBoard = async (name) => {
    const boardId = await createBoard(name);
    setAddBoardModalVisible(false);
    await refreshDashboardData();
    setSelectedBoardId(boardId);
  };

  const handleAssignBoard = async (boardId) => {
    if (boardPickerTopic) {
      await assignTopicToBoard(boardPickerTopic.id, boardId);
      setBoardPickerTopic(null);
      await refreshDashboardData();
    }
  };

  const handleTopicPress = (topic) => {
    navigation.navigate('TopicDetails', { topicId: topic.id, topicName: topic.name });
  };

  const handleSaveEditTopic = async (topicId, { name, icon }) => {
    await updateTopic(topicId, { name, icon });
    setEditingTopic(null);
    await refreshDashboardData();
  };

  const handleDeleteTopic = (topic) => {
    Alert.alert(
      'מחיקת נושא',
      `למחוק את "${topic.name}"? לא ניתן לשחזר את הפעולה.`,
      [
        { text: 'ביטול', style: 'cancel' },
        {
          text: 'מחיקה',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteTopic(topic.id);
              await refreshDashboardData();
            } catch (err) {
              Alert.alert('לא ניתן למחוק', err.message || 'אירעה שגיאה במחיקת הנושא.');
            }
          },
        },
      ]
    );
  };

  const handlePlannerPress = () => {
    navigation.navigate('Schedule');
  };

  const plannerLabel = nextUpcoming
    ? `הבא: ${nextUpcoming.title} ב-${formatHM(nextUpcoming.start_minute)}`
    : undefined;

  return (
    <View style={styles.screen}>
      <StatusBar barStyle="dark-content" backgroundColor={colors.background} />
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <DashboardHeader
          quote={quote}
          dualDate={dualDate}
          onSettingsPress={() => navigation.navigate('Settings')}
        />

        <BoardTabs
          boards={boards}
          selectedBoardId={selectedBoardId}
          onSelect={setSelectedBoardId}
          onAddPress={() => setAddBoardModalVisible(true)}
        />

        <ProgressRing completed={progress.completed} total={progress.total} />

        <OverdueAlert count={overdueCount} />

        <SchedulePlannerButton onPress={handlePlannerPress} label={plannerLabel} />

        <TrackStoreButton onPress={() => navigation.navigate('TrackStore')} />

        <View style={styles.topicsHeaderRow}>
          <Text style={[typography.topicTitle, styles.topicsHeaderTitle]}>נושאי לימוד</Text>
          <TouchableOpacity
            onPress={() => setEditMode((prev) => !prev)}
            style={styles.editToggle}
            accessibilityRole="button"
          >
            <Feather
              name={editMode ? 'check' : 'edit-2'}
              size={14}
              color={colors.primary}
              style={styles.editToggleIcon}
            />
            <Text style={[typography.label, styles.editToggleText]}>
              {editMode ? 'סיום עריכה' : 'ערוך'}
            </Text>
          </TouchableOpacity>
        </View>

        <TopicsGrid
          topics={visibleTopics}
          onTopicPress={handleTopicPress}
          onTopicLongPress={setBoardPickerTopic}
          onAddPress={() => setModalVisible(true)}
          editMode={editMode}
          onEditTopic={setEditingTopic}
          onDeleteTopic={handleDeleteTopic}
        />
      </ScrollView>

      <AddTopicModal
        visible={modalVisible}
        onClose={() => setModalVisible(false)}
        onSave={handleAddTopic}
      />

      <EditTopicModal
        visible={!!editingTopic}
        topic={editingTopic}
        onClose={() => setEditingTopic(null)}
        onSave={handleSaveEditTopic}
      />

      <AddBoardModal
        visible={addBoardModalVisible}
        onClose={() => setAddBoardModalVisible(false)}
        onSave={handleAddBoard}
      />

      <BoardPickerModal
        visible={!!boardPickerTopic}
        topic={boardPickerTopic}
        boards={boards}
        onSelect={handleAssignBoard}
        onClose={() => setBoardPickerTopic(null)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollContent: {
    paddingBottom: 40,
  },
  topicsHeaderRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    marginBottom: 10,
  },
  topicsHeaderTitle: {
    color: colors.textPrimary,
  },
  editToggle: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: colors.surfaceAlt,
    borderRadius: 14,
    paddingVertical: 6,
    paddingHorizontal: 12,
  },
  editToggleIcon: {
    marginLeft: 5,
  },
  editToggleText: {
    color: colors.primary,
  },
});
