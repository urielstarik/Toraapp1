// src/screens/HelpScreen.js
import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { Feather } from '@expo/vector-icons';
import colors from '../theme/colors';
import { typography } from '../theme/fonts';
import { CSV_COLUMNS } from '../services/csvImport/parseCsv';

function Section({ icon, title, children }) {
  return (
    <View style={styles.section}>
      <View style={styles.sectionHeader}>
        <Feather name={icon} size={18} color={colors.primary} style={styles.sectionIcon} />
        <Text style={[typography.topicTitle, styles.sectionTitle]}>{title}</Text>
      </View>
      {children}
    </View>
  );
}

function Paragraph({ children }) {
  return <Text style={[typography.body, styles.paragraph]}>{children}</Text>;
}

const EXAMPLE_ROWS = [
  { date: '01/08/2026', topic: 'גמרא (דף יומי)', task: 'בבא קמא דף ד' },
  { date: '01/08/2026', topic: 'תהילים', task: 'פרקים א-ט' },
  { date: '02/08/2026', topic: 'משנה ברורה', task: 'סימן ד' },
];

export default function HelpScreen() {
  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
      <Section icon="sun" title="איך היום שלך עובד">
        <Paragraph>
          בכל בוקר האפליקציה מכינה עבורך משימה אחת לכל נושא לימוד קבוע — זו
          "ההספק להיום". נושאים כמו דף יומי מתעדכנים אוטומטית לדף הנכון של
          אותו יום, ותהילים מתעדכן לפי החלוקה החודשית המקובלת.
        </Paragraph>
        <Paragraph>
          משימות שלא הושלמו עד סוף היום עוברות באופן אוטומטי לרשימת
          "חוסרים" בעמוד הנושא, כך שכלום לא נעלם — פשוט ממתין להשלמה.
        </Paragraph>
      </Section>

      <Section icon="check-circle" title="איך מסמנים משימה כהושלמה">
        <Paragraph>
          בכל עמוד נושא יש עיגול גדול ליד כל משימה. נגיעה בעיגול מסמנת אותה
          כהושלמה, עם אנימציה עדינה ושקטה. ליד העיגול יש גם שדה טקסט
          רשות — אפשר לרשום בדיוק מה למדת (למשל "פרק ג'"), לפני או אחרי
          הסימון.
        </Paragraph>
      </Section>

      <Section icon="compass" title="מאגר הספקים">
        <Paragraph>
          במסך "מאגר הספקים" (נגיש מהלוח הראשי או מההגדרות) אפשר להירשם
          במהירות למסלולי לימוד מוכנים — כמו דף יומי בבלי, משנה ברורה,
          תהילים יומי ומשנה יומית. מסלולים מסונכרנים מתעדכנים כל יום
          אוטומטית לתוכן המדויק, ישירות ממקור חיצוני אמין.
        </Paragraph>
      </Section>

      <Section icon="layers" title="לוחות ונושאים">
        <Paragraph>
          אפשר לקבץ נושאי לימוד ללוחות מותאמים אישית — למשל "שגרת חול" או
          "הספקים חודש אלול" — דרך שורת הלשוניות שמתחת לכותרת הראשית.
          לחיצה ארוכה על כרטיס נושא פותחת אפשרות לשייך אותו ללוח קיים.
        </Paragraph>
      </Section>

      <Section icon="calendar" title="תכנון היום ויומן Google">
        <Paragraph>
          הכפתור "תכנון לו"ז יומי" פותח מסך תזמון שבו אפשר לגרור משימות
          מהיום אל ציר שעות ולקבוע להן משך זמן. אם מחוברים ל-Google
          Calendar, המשימות המתוזמנות נוצרות גם שם באופן אוטומטי, וסימון
          משימה כהושלמת מוסיף לאירוע ✓.
        </Paragraph>
      </Section>

      <Section icon="upload" title="ייבוא מאקסל (CSV) — הוראות מפורטות">
        <Paragraph>
          במסך ההגדרות יש כפתור "ייבוא מאקסל" שמאפשר להעלות בבת אחת לוח
          זמנים שלם לחודש. הקובץ חייב להיות בפורמט CSV (אפשר לשמור כך מכל
          גיליון אקסל: קובץ ← שמירה בשם ← CSV) עם שלוש עמודות חובה בדיוק
          בשמות הבאים:
        </Paragraph>

        <View style={styles.columnList}>
          <Text style={[typography.body, styles.columnItem]}>
            • <Text style={styles.columnName}>{CSV_COLUMNS.DATE}</Text> — תאריך בפורמט
            יום/חודש/שנה, למשל 01/08/2026
          </Text>
          <Text style={[typography.body, styles.columnItem]}>
            • <Text style={styles.columnName}>{CSV_COLUMNS.TOPIC_NAME}</Text> — שם הנושא
            חייב להיות זהה בדיוק לשם נושא קיים באפליקציה
          </Text>
          <Text style={[typography.body, styles.columnItem]}>
            • <Text style={styles.columnName}>{CSV_COLUMNS.TASK_TEXT}</Text> — פירוט המשימה
            (רשות)
          </Text>
        </View>

        <Text style={[typography.label, styles.exampleLabel]}>דוגמה לקובץ תקין:</Text>

        <View style={styles.table}>
          <View style={[styles.tableRow, styles.tableHeaderRow]}>
            <Text style={[typography.label, styles.tableCell, styles.tableHeaderCell]}>
              {CSV_COLUMNS.TASK_TEXT}
            </Text>
            <Text style={[typography.label, styles.tableCell, styles.tableHeaderCell]}>
              {CSV_COLUMNS.TOPIC_NAME}
            </Text>
            <Text style={[typography.label, styles.tableCell, styles.tableHeaderCell]}>
              {CSV_COLUMNS.DATE}
            </Text>
          </View>
          {EXAMPLE_ROWS.map((row, i) => (
            <View key={i} style={styles.tableRow}>
              <Text style={[typography.label, styles.tableCell]}>{row.task}</Text>
              <Text style={[typography.label, styles.tableCell]}>{row.topic}</Text>
              <Text style={[typography.label, styles.tableCell]}>{row.date}</Text>
            </View>
          ))}
        </View>

        <Paragraph>
          שורה שהתאריך בה לא תקין, או שהנושא שלה לא נמצא באפליקציה, תדולג
          — ותקבל סיכום מלא בסוף הייבוא של כמה שורות יובאו וכמה דולגו,
          כדי שתוכל לתקן ולנסות שוב.
        </Paragraph>
        <Paragraph>
          ייבוא חוזר על אותו תאריך ונושא לא יפגע במשימה שכבר סימנת כהושלמה
          — הוא רק יעדכן את פירוט המשימה.
        </Paragraph>
      </Section>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: 20,
    paddingBottom: 48,
  },
  section: {
    marginBottom: 30,
  },
  sectionHeader: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    marginBottom: 10,
  },
  sectionIcon: {
    marginLeft: 8,
  },
  sectionTitle: {
    color: colors.textPrimary,
    textAlign: 'right',
  },
  paragraph: {
    color: colors.textSecondary,
    textAlign: 'right',
    lineHeight: 22,
    marginBottom: 10,
  },
  columnList: {
    marginBottom: 14,
  },
  columnItem: {
    color: colors.textSecondary,
    textAlign: 'right',
    lineHeight: 24,
  },
  columnName: {
    color: colors.primary,
  },
  exampleLabel: {
    color: colors.textPrimary,
    textAlign: 'right',
    marginBottom: 8,
  },
  table: {
    borderWidth: 1,
    borderColor: colors.divider,
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 16,
  },
  tableRow: {
    flexDirection: 'row-reverse',
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
  },
  tableHeaderRow: {
    backgroundColor: colors.surfaceAlt,
  },
  tableCell: {
    flex: 1,
    color: colors.textPrimary,
    textAlign: 'center',
    paddingVertical: 10,
    paddingHorizontal: 6,
  },
  tableHeaderCell: {
    color: colors.primary,
  },
});
