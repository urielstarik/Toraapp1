// src/screens/ScheduleScreen.js
import React, { useCallback, useEffect, useState } from 'react';
import { View, StyleSheet, StatusBar } from 'react-native';
import {
  getUnplacedItemsForDate,
  getPlacedBlocksForDate,
  addCustomActivity,
  placeItem,
  updateBlockStart,
  updateBlockTiming,
} from '../models/ScheduleItem';
import { todayDateString } from '../models/Task';
import { subscribeToRollover } from '../services/rolloverBus';
import {
  fetchGoogleBusyBlocksForDate,
  pushScheduledItemToGoogle,
  syncBlockTimingToGoogle,
} from '../services/googleCalendarSync';
import { useGoogleAuth } from '../context/GoogleAuthContext';
import { DragProvider } from '../context/DragContext';
import colors from '../theme/colors';

import GoogleSyncBar from '../components/schedule/GoogleSyncBar';
import TaskBank from '../components/schedule/TaskBank';
import HourlyTimeline from '../components/schedule/HourlyTimeline';
import DurationModal from '../components/schedule/DurationModal';
import AddActivityModal from '../components/schedule/AddActivityModal';
import DragGhost from '../components/schedule/DragGhost';

export default function ScheduleScreen() {
  const date = todayDateString();
  const { isSignedIn } = useGoogleAuth();

  const [unplacedItems, setUnplacedItems] = useState([]);
  const [placedBlocks, setPlacedBlocks] = useState([]);
  const [googleBusyBlocks, setGoogleBusyBlocks] = useState([]);
  const [pendingDrop, setPendingDrop] = useState(null); // { item, startMinute }
  const [addModalVisible, setAddModalVisible] = useState(false);

  const refresh = useCallback(async () => {
    const [unplaced, placed] = await Promise.all([
      getUnplacedItemsForDate(date),
      getPlacedBlocksForDate(date),
    ]);
    setUnplacedItems(unplaced);
    setPlacedBlocks(placed);
  }, [date]);

  const refreshGoogleBusyBlocks = useCallback(async () => {
    if (!isSignedIn) {
      setGoogleBusyBlocks([]);
      return;
    }
    const blocks = await fetchGoogleBusyBlocksForDate(date);
    setGoogleBusyBlocks(blocks);
  }, [date, isSignedIn]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  useEffect(() => {
    refreshGoogleBusyBlocks();
  }, [refreshGoogleBusyBlocks]);

  // Keep the planner in sync if a rollover fires while it's open.
  useEffect(() => {
    const unsubscribe = subscribeToRollover(() => {
      refresh();
      refreshGoogleBusyBlocks();
    });
    return unsubscribe;
  }, [refresh, refreshGoogleBusyBlocks]);

  const handleRequestDuration = (item, startMinute) => {
    setPendingDrop({ item, startMinute });
  };

  const handleConfirmDuration = async (durationMinutes) => {
    if (!pendingDrop) return;
    const { item, startMinute } = pendingDrop;

    const scheduleItemId = await placeItem({
      scheduleItemId: item.scheduleItemId,
      kind: item.kind,
      taskId: item.taskId,
      title: item.title,
      icon: item.icon,
      calendarTitle: item.topicName || item.title,
      date,
      startMinute,
      durationMinutes,
    });

    setPendingDrop(null);
    await refresh();

    // Push to Google Calendar (best-effort; no-ops if not signed in).
    await pushScheduledItemToGoogle({
      scheduleItemId,
      calendarTitle: item.topicName || item.title,
      date,
      startMinute,
      durationMinutes,
    });
    await refresh();
  };

  const handleAddActivity = async ({ title, icon }) => {
    await addCustomActivity({ title, icon, date });
    setAddModalVisible(false);
    await refresh();
  };

  const handleMoveBlock = async (block, newStartMinute) => {
    await updateBlockStart(block.id, newStartMinute);
    await refresh();
    await syncBlockTimingToGoogle(block, newStartMinute, block.duration_minutes, date);
  };

  const handleResizeBlock = async (block, newStartMinute, newDurationMinutes) => {
    await updateBlockTiming(block.id, newStartMinute, newDurationMinutes);
    await refresh();
    await syncBlockTimingToGoogle(block, newStartMinute, newDurationMinutes, date);
  };

  return (
    <DragProvider>
      <View style={styles.screen}>
        <StatusBar barStyle="dark-content" backgroundColor={colors.background} />

        <GoogleSyncBar />

        <TaskBank items={unplacedItems} onAddPress={() => setAddModalVisible(true)} />

        <HourlyTimeline
          blocks={placedBlocks}
          googleBusyBlocks={googleBusyBlocks}
          onRequestDuration={handleRequestDuration}
          onMove={handleMoveBlock}
          onResize={handleResizeBlock}
        />

        <DurationModal
          visible={!!pendingDrop}
          pendingDrop={pendingDrop}
          onConfirm={handleConfirmDuration}
          onCancel={() => setPendingDrop(null)}
        />

        <AddActivityModal
          visible={addModalVisible}
          onClose={() => setAddModalVisible(false)}
          onSave={handleAddActivity}
        />

        <DragGhost />
      </View>
    </DragProvider>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.background,
  },
});
