// src/screens/SettingsScreen.js
import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { getEveningTime, setEveningTime } from '../services/notifications/notificationSettings';
import { refreshEveningNotification } from '../services/notifications/eveningScheduler';
import { pickCsvFile, runCsvImport } from '../services/csvImport/importRunner';
import colors from '../theme/colors';
import { typography } from '../theme/fonts';

const PRESETS = [
  { hour: 19, minute: 0 },
  { hour: 20, minute: 0 },
  { hour: 21, minute: 0 },
  { hour: 22, minute: 0 },
];

function formatHM(hour, minute) {
  return `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
}

function buildImportSummaryMessage(summary) {
  if (summary.headerError) {
    return summary.headerError;
  }
  const lines = [`יובאו ${summary.imported} משימות מתוך ${summary.totalRows} שורות.`];
  if (summary.dateErrors.length > 0) {
    lines.push(`${summary.dateErrors.length} שורות דולגו עקב תאריך לא תקין.`);
  }
  if (summary.unmatchedTopics.length > 0) {
    const names = summary.unmatchedTopics.map((u) => `"${u.name}"`).join(', ');
    lines.push(`נושאים שלא נמצאו באפליקציה ולכן דולגו: ${names}`);
  }
  return lines.join('\n');
}

export default function SettingsScreen({ navigation }) {
  const [current, setCurrent] = useState({ hour: 20, minute: 0 });
  const [loading, setLoading] = useState(true);
  const [importing, setImporting] = useState(false);

  useEffect(() => {
    getEveningTime().then((t) => {
      setCurrent(t);
      setLoading(false);
    });
  }, []);

  const handleSelect = async (hour, minute) => {
    setCurrent({ hour, minute });
    await setEveningTime(hour, minute);
    await refreshEveningNotification();
  };

  const handleImportPress = async () => {
    try {
      const file = await pickCsvFile();
      if (!file) return;

      setImporting(true);
      const summary = await runCsvImport(file.uri);
      setImporting(false);

      Alert.alert(
        summary.headerError ? 'הקובץ אינו תקין' : 'ייבוא הושלם',
        buildImportSummaryMessage(summary)
      );
    } catch (err) {
      setImporting(false);
      Alert.alert('שגיאה בייבוא', 'לא ניתן היה לקרוא את הקובץ. ודאו שהוא בפורמט CSV תקין.');
    }
  };

  if (loading) return <View style={styles.screen} />;

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
      <Text style={[typography.topicTitle, styles.sectionTitle]}>תזכורת ערב</Text>
      <Text style={[typography.body, styles.description]}>
        אם עדיין נשארו לך משימות לא שלמות, תישלח תזכורת עדינה בשעה שתבחר.
        {'\n'}אם כל המשימות הושלמו, לא תישלח שום תזכורת.
      </Text>

      <View style={styles.presetsRow}>
        {PRESETS.map((p) => {
          const isSelected = p.hour === current.hour && p.minute === current.minute;
          return (
            <TouchableOpacity
              key={`${p.hour}:${p.minute}`}
              style={[styles.presetButton, isSelected && styles.presetButtonSelected]}
              onPress={() => handleSelect(p.hour, p.minute)}
            >
              <Text
                style={[
                  typography.topicTitle,
                  styles.presetText,
                  isSelected && styles.presetTextSelected,
                ]}
              >
                {formatHM(p.hour, p.minute)}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      <View style={styles.infoRow}>
        <Feather name="bell" size={16} color={colors.textSecondary} style={styles.infoIcon} />
        <Text style={[typography.label, styles.infoText]}>
          {`התזכורת מוגדרת כרגע לשעה ${formatHM(current.hour, current.minute)}`}
        </Text>
      </View>

      <View style={styles.infoRow}>
        <Feather name="moon" size={16} color={colors.textSecondary} style={styles.infoIcon} />
        <Text style={[typography.label, styles.infoText]}>
          במצב "נא לא להפריע" (פעמון בראש המסך) לא תישלח שום תזכורת עד סוף היום.
        </Text>
      </View>

      <View style={styles.divider} />

      <Text style={[typography.topicTitle, styles.sectionTitle]}>ייבוא נתונים</Text>
      <Text style={[typography.body, styles.description]}>
        ניתן לייבא לוח זמנים שלם לחודש מקובץ אקסל (CSV) בבת אחת. לפירוט
        מדויק של פורמט הקובץ הנדרש, ראו את מסך העזרה.
      </Text>

      <TouchableOpacity
        style={styles.importButton}
        onPress={handleImportPress}
        disabled={importing}
        activeOpacity={0.85}
      >
        {importing ? (
          <ActivityIndicator size="small" color="#FFFFFF" style={styles.importIcon} />
        ) : (
          <Feather name="upload" size={18} color="#FFFFFF" style={styles.importIcon} />
        )}
        <Text style={[typography.topicTitle, styles.importText]}>
          {importing ? 'מייבא...' : 'ייבוא מאקסל'}
        </Text>
      </TouchableOpacity>

      <View style={styles.divider} />

      <TouchableOpacity
        style={styles.helpRow}
        onPress={() => navigation.navigate('TrackStore')}
        activeOpacity={0.8}
      >
        <Feather name="compass" size={20} color={colors.primary} style={styles.infoIcon} />
        <Text style={[typography.topicTitle, styles.helpText]}>מאגר הספקים</Text>
        <Feather name="chevron-left" size={18} color={colors.textSecondary} />
      </TouchableOpacity>

      <View style={{ height: 10 }} />

      <TouchableOpacity
        style={styles.helpRow}
        onPress={() => navigation.navigate('Help')}
        activeOpacity={0.8}
      >
        <Feather name="help-circle" size={20} color={colors.primary} style={styles.infoIcon} />
        <Text style={[typography.topicTitle, styles.helpText]}>עזרה והסבר</Text>
        <Feather name="chevron-left" size={18} color={colors.textSecondary} />
      </TouchableOpacity>

      <View style={{ height: 10 }} />

      <TouchableOpacity
        style={styles.helpRow}
        onPress={() => navigation.navigate('About')}
        activeOpacity={0.8}
      >
        <Feather name="info" size={20} color={colors.primary} style={styles.infoIcon} />
        <Text style={[typography.topicTitle, styles.helpText]}>אודות</Text>
        <Feather name="chevron-left" size={18} color={colors.textSecondary} />
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: 20,
    paddingBottom: 48,
  },
  sectionTitle: {
    color: colors.textPrimary,
    textAlign: 'right',
    marginBottom: 10,
  },
  description: {
    color: colors.textSecondary,
    textAlign: 'right',
    marginBottom: 22,
    lineHeight: 22,
  },
  presetsRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    marginBottom: 28,
  },
  presetButton: {
    flex: 1,
    marginHorizontal: 4,
    backgroundColor: colors.surface,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.divider,
  },
  presetButtonSelected: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  presetText: {
    color: colors.primary,
    fontSize: 15,
  },
  presetTextSelected: {
    color: '#FFFFFF',
  },
  infoRow: {
    flexDirection: 'row-reverse',
    alignItems: 'flex-start',
    marginBottom: 14,
  },
  infoIcon: {
    marginLeft: 8,
    marginTop: 2,
  },
  infoText: {
    color: colors.textSecondary,
    flex: 1,
    textAlign: 'right',
    lineHeight: 20,
  },
  divider: {
    height: 1,
    backgroundColor: colors.divider,
    marginVertical: 24,
  },
  importButton: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.primary,
    borderRadius: 14,
    paddingVertical: 16,
    shadowColor: colors.shadow,
    shadowOpacity: 1,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 3 },
    elevation: 2,
  },
  importIcon: {
    marginLeft: 8,
  },
  importText: {
    color: '#FFFFFF',
    fontSize: 16,
  },
  helpRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: 14,
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderColor: colors.divider,
  },
  helpText: {
    color: colors.textPrimary,
    flex: 1,
    marginRight: 4,
    textAlign: 'right',
  },
});
