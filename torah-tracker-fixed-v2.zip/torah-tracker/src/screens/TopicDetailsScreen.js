// src/screens/TopicDetailsScreen.js
import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { getTopicById } from '../models/Topic';
import {
  getOrCreateTaskForToday,
  getOverdueTasksForTopic,
  toggleTaskCompletion,
  updateTaskNote,
} from '../models/Task';
import { DEFAULT_TOPIC_ICON } from '../theme/topicIcons';
import { subscribeToRollover } from '../services/rolloverBus';
import { syncTaskCompletionToGoogle } from '../services/googleCalendarSync';
import { refreshEveningNotification } from '../services/notifications/eveningScheduler';
import colors from '../theme/colors';
import { typography } from '../theme/fonts';
import TaskEntryRow from '../components/TaskEntryRow';

function formatShortDate(dateStr) {
  // dateStr is 'YYYY-MM-DD'
  const [y, m, d] = dateStr.split('-');
  return `${d}.${m}.${y}`;
}

export default function TopicDetailsScreen({ route, navigation }) {
  const { topicId, topicName } = route.params;

  const [topic, setTopic] = useState(null);
  const [todayTask, setTodayTask] = useState(null);
  const [overdueTasks, setOverdueTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadData = useCallback(async () => {
    const [t, today, overdue] = await Promise.all([
      getTopicById(topicId),
      getOrCreateTaskForToday(topicId),
      getOverdueTasksForTopic(topicId),
    ]);
    setTopic(t);
    setTodayTask(today);
    setOverdueTasks(overdue);
    setLoading(false);
  }, [topicId]);

  useEffect(() => {
    navigation.setOptions({ title: topicName || 'נושא לימוד' });
  }, [navigation, topicName]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  useEffect(() => {
    const unsubscribe = subscribeToRollover(loadData);
    return unsubscribe;
  }, [loadData]);

  const handleTaskChange = async (task, { toggle, note }) => {
    if (toggle) {
      const newStatus = await toggleTaskCompletion(task, note);
      await syncTaskCompletionToGoogle(task.id, newStatus === 'completed', task.date);
      await refreshEveningNotification();
    } else {
      await updateTaskNote(task.id, task.status, note);
    }
    await loadData();
  };

  if (loading || !topic) {
    return <View style={styles.screen} />;
  }

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
      <View style={styles.topicHeader}>
        <Feather
          name={topic.icon || DEFAULT_TOPIC_ICON}
          size={30}
          color={colors.primary}
        />
        <Text style={[typography.topicTitle, styles.topicName]}>{topic.name}</Text>
      </View>

      <View style={styles.section}>
        <Text style={[typography.topicTitle, styles.sectionTitle]}>ההספק להיום</Text>
        {todayTask ? (
          <TaskEntryRow task={todayTask} onChange={handleTaskChange} />
        ) : null}
      </View>

      <View style={styles.section}>
        <Text style={[typography.topicTitle, styles.sectionTitle]}>חוסרים</Text>
        {overdueTasks.length === 0 ? (
          <Text style={[typography.body, styles.emptyText]}>
            אין משימות פתוחות מימים קודמים
          </Text>
        ) : (
          overdueTasks.map((task) => (
            <TaskEntryRow
              key={task.id}
              task={task}
              dateLabel={formatShortDate(task.date)}
              onChange={handleTaskChange}
            />
          ))
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: 20,
    paddingBottom: 48,
  },
  topicHeader: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    marginBottom: 28,
  },
  topicName: {
    color: colors.textPrimary,
    fontSize: 20,
    marginRight: 12,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    color: colors.primary,
    marginBottom: 14,
    textAlign: 'right',
  },
  emptyText: {
    color: colors.textSecondary,
    textAlign: 'center',
    paddingVertical: 12,
  },
});
