// src/screens/TrackStoreScreen.js
import React, { useCallback, useEffect, useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ScrollView, ActivityIndicator,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { TRACK_TEMPLATES } from '../data/trackTemplates';
import { getAllTopics, createTopic } from '../models/Topic';
import { ensureTaskForTopicAndDate, todayDateString } from '../models/Task';
import { generateDailyLabel } from '../services/dailyLabelGenerators';
import colors from '../theme/colors';
import { typography } from '../theme/fonts';

function normalize(name) {
  return String(name || '').trim().replace(/\s+/g, ' ').toLowerCase();
}

function slugify(name) {
  const base = name
    .trim()
    .toLowerCase()
    .replace(/\s+/g, '_')
    .replace(/[^\w\u0590-\u05FF_]/g, '');
  return `topic_${base || 'template'}_${Date.now()}`;
}

export default function TrackStoreScreen({ navigation }) {
  const [subscribedNames, setSubscribedNames] = useState(new Set());
  const [loading, setLoading] = useState(true);
  const [subscribingId, setSubscribingId] = useState(null);

  const refreshSubscriptions = useCallback(async () => {
    const topics = await getAllTopics();
    setSubscribedNames(new Set(topics.map((t) => normalize(t.name))));
    setLoading(false);
  }, []);

  useEffect(() => {
    refreshSubscriptions();
  }, [refreshSubscriptions]);

  const handleSubscribe = async (template) => {
    setSubscribingId(template.id);
    try {
      const topicId = slugify(template.name);
      await createTopic({
        id: topicId,
        name: template.name,
        icon: template.icon,
        type: 'flexible',
        syncSource: template.syncSource,
      });

      // Fetch today's dynamic label right away (if this track has one) so
      // the topic shows up on the dashboard already populated, instead of
      // waiting for the next midnight rollover.
      const label = template.syncSource
        ? await generateDailyLabel({ sync_source: template.syncSource })
        : null;
      await ensureTaskForTopicAndDate(topicId, todayDateString(), label);

      await refreshSubscriptions();
    } finally {
      setSubscribingId(null);
    }
  };

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
      <Text style={[typography.body, styles.intro]}>
        בחרו מסלולי לימוד מוכנים להוספה מיידית ללוח הבית. מסלולים
        מסונכרנים (כמו דף יומי) יתעדכנו כל יום אוטומטית לתוכן הנכון.
      </Text>

      {loading ? (
        <ActivityIndicator style={styles.loader} color={colors.primary} />
      ) : (
        TRACK_TEMPLATES.map((template) => {
          const isSubscribed = subscribedNames.has(normalize(template.name));
          const isBusy = subscribingId === template.id;
          return (
            <View key={template.id} style={styles.card}>
              <View style={styles.cardRow}>
                <Feather
                  name={template.icon}
                  size={26}
                  color={colors.primary}
                  style={styles.cardIcon}
                />
                <View style={styles.cardTextWrap}>
                  <Text style={[typography.topicTitle, styles.cardTitle]}>
                    {template.name}
                  </Text>
                  <Text style={[typography.label, styles.cardDescription]}>
                    {template.description}
                  </Text>
                  {template.syncSource ? (
                    <View style={styles.syncBadge}>
                      <Feather name="zap" size={11} color={colors.primary} />
                      <Text style={[typography.label, styles.syncBadgeText]}>
                        מתעדכן אוטומטית
                      </Text>
                    </View>
                  ) : null}
                </View>
              </View>

              <TouchableOpacity
                style={[styles.subscribeButton, isSubscribed && styles.subscribeButtonDone]}
                onPress={() => !isSubscribed && handleSubscribe(template)}
                disabled={isSubscribed || isBusy}
                activeOpacity={0.85}
              >
                {isBusy ? (
                  <ActivityIndicator size="small" color="#FFFFFF" />
                ) : (
                  <>
                    <Feather
                      name={isSubscribed ? 'check' : 'plus-circle'}
                      size={16}
                      color={isSubscribed ? colors.completed : '#FFFFFF'}
                      style={styles.subscribeIcon}
                    />
                    <Text
                      style={[
                        typography.topicTitle,
                        styles.subscribeText,
                        isSubscribed && styles.subscribeTextDone,
                      ]}
                    >
                      {isSubscribed ? 'נרשמת' : 'הירשם'}
                    </Text>
                  </>
                )}
              </TouchableOpacity>
            </View>
          );
        })
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: 20,
    paddingBottom: 48,
  },
  intro: {
    color: colors.textSecondary,
    textAlign: 'right',
    lineHeight: 22,
    marginBottom: 20,
  },
  loader: {
    marginTop: 24,
  },
  card: {
    backgroundColor: colors.surface,
    borderRadius: 16,
    padding: 16,
    marginBottom: 14,
    shadowColor: colors.shadow,
    shadowOpacity: 1,
    shadowRadius: 5,
    shadowOffset: { width: 0, height: 2 },
    elevation: 1,
  },
  cardRow: {
    flexDirection: 'row-reverse',
    marginBottom: 14,
  },
  cardIcon: {
    marginLeft: 12,
    marginTop: 2,
  },
  cardTextWrap: {
    flex: 1,
  },
  cardTitle: {
    color: colors.textPrimary,
    textAlign: 'right',
    marginBottom: 4,
  },
  cardDescription: {
    color: colors.textSecondary,
    textAlign: 'right',
    lineHeight: 19,
  },
  syncBadge: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    alignSelf: 'flex-end',
    backgroundColor: colors.accentSage,
    borderRadius: 10,
    paddingVertical: 3,
    paddingHorizontal: 8,
    marginTop: 8,
  },
  syncBadgeText: {
    color: colors.primary,
    marginRight: 4,
    fontSize: 11,
  },
  subscribeButton: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.primary,
    borderRadius: 12,
    paddingVertical: 12,
  },
  subscribeButtonDone: {
    backgroundColor: colors.completed + '22',
  },
  subscribeIcon: {
    marginLeft: 6,
  },
  subscribeText: {
    color: '#FFFFFF',
    fontSize: 15,
  },
  subscribeTextDone: {
    color: colors.completed,
  },
});
