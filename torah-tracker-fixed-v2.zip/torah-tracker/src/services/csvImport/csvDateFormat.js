// src/services/csvImport/csvDateFormat.js

/**
 * Accepts DD/MM/YYYY, DD.MM.YYYY, DD-MM-YYYY, or already-ISO YYYY-MM-DD,
 * and returns 'YYYY-MM-DD', or null if the value can't be parsed.
 */
export function parseCsvDate(raw) {
  if (!raw) return null;
  const value = String(raw).trim();

  // Already ISO.
  const isoMatch = value.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (isoMatch) {
    const [, y, m, d] = isoMatch;
    return toIso(Number(y), Number(m), Number(d));
  }

  // DD/MM/YYYY, DD.MM.YYYY, DD-MM-YYYY (day-first, standard Israeli usage).
  const dmyMatch = value.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{2,4})$/);
  if (dmyMatch) {
    const [, d, m, yRaw] = dmyMatch;
    const y = yRaw.length === 2 ? 2000 + Number(yRaw) : Number(yRaw);
    return toIso(y, Number(m), Number(d));
  }

  return null;
}

function toIso(year, month, day) {
  if (
    !Number.isInteger(year) || !Number.isInteger(month) || !Number.isInteger(day) ||
    month < 1 || month > 12 || day < 1 || day > 31
  ) {
    return null;
  }
  const mm = String(month).padStart(2, '0');
  const dd = String(day).padStart(2, '0');
  return `${year}-${mm}-${dd}`;
}

export default { parseCsvDate };
