// src/services/csvImport/importRunner.js
import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system';
import { parseCsvText } from './parseCsv';
import { getAllTopics } from '../../models/Topic';
import { batchImportTasks } from '../../models/Task';

/**
 * Opens the system file picker for a CSV file. Returns { uri, name } or
 * null if the user cancelled.
 */
export async function pickCsvFile() {
  const result = await DocumentPicker.getDocumentAsync({
    type: ['text/csv', 'text/comma-separated-values', 'application/vnd.ms-excel', '*/*'],
    copyToCacheDirectory: true,
  });
  if (result.canceled || !result.assets?.length) return null;
  const asset = result.assets[0];
  return { uri: asset.uri, name: asset.name };
}

/**
 * Runs the full import pipeline against an already-picked file: reads its
 * text, parses and validates it, matches each row's topic name against
 * existing topics (case/whitespace-insensitive), and batch-inserts the
 * matched rows.
 *
 * Returns a summary object the Settings screen can present to the user:
 *   { headerError, totalRows, imported, dateErrors, unmatchedTopics }
 */
export async function runCsvImport(fileUri) {
  const csvText = await FileSystem.readAsStringAsync(fileUri, {
    encoding: FileSystem.EncodingType.UTF8,
  });

  const { rows, errors, headerError } = parseCsvText(csvText);
  if (headerError) {
    return { headerError, totalRows: 0, imported: 0, dateErrors: [], unmatchedTopics: [] };
  }

  const topics = await getAllTopics();
  const topicByNormalizedName = new Map(
    topics.map((t) => [normalizeTopicName(t.name), t])
  );

  const importRows = [];
  const unmatchedCounts = new Map(); // topicName -> count

  for (const row of rows) {
    const topic = topicByNormalizedName.get(normalizeTopicName(row.topicName));
    if (!topic) {
      unmatchedCounts.set(row.topicName, (unmatchedCounts.get(row.topicName) || 0) + 1);
      continue;
    }
    importRows.push({ topicId: topic.id, date: row.date, taskText: row.taskText });
  }

  const imported = importRows.length > 0 ? await batchImportTasks(importRows) : 0;

  return {
    headerError: null,
    totalRows: rows.length + errors.length,
    imported,
    dateErrors: errors,
    unmatchedTopics: Array.from(unmatchedCounts.entries()).map(([name, count]) => ({ name, count })),
  };
}

function normalizeTopicName(name) {
  return String(name || '').trim().replace(/\s+/g, ' ').toLowerCase();
}

export default { pickCsvFile, runCsvImport };
