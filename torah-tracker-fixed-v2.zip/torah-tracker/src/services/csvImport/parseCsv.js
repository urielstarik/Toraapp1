// src/services/csvImport/parseCsv.js
import Papa from 'papaparse';
import { parseCsvDate } from './csvDateFormat';

// The exact expected header names (see the Help screen for the full guide).
export const CSV_COLUMNS = {
  DATE: 'תאריך',
  TOPIC_NAME: 'שם הספק',
  TASK_TEXT: 'משימה מפורטת',
};

/**
 * Parses raw CSV text into { rows, errors, headerError }.
 *
 * rows:  [{ rowNumber, date, topicName, taskText }] — only rows that
 *        parsed successfully (valid date, non-empty topic name).
 * errors: [{ rowNumber, reason }] — rows that failed to parse, with a
 *        Hebrew explanation, so the import screen can show a clear summary.
 * headerError: a Hebrew string if the required columns are missing
 *        entirely (in which case rows/errors are both empty).
 */
export function parseCsvText(csvText) {
  const result = Papa.parse(csvText.trim(), {
    header: true,
    skipEmptyLines: true,
    transformHeader: (h) => h.trim(),
  });

  const headers = result.meta.fields || [];
  const missing = Object.values(CSV_COLUMNS).filter((col) => !headers.includes(col));
  if (missing.length > 0) {
    return {
      rows: [],
      errors: [],
      headerError: `חסרות עמודות חובה בקובץ: ${missing.join(', ')}`,
    };
  }

  const rows = [];
  const errors = [];

  result.data.forEach((raw, index) => {
    const rowNumber = index + 2; // +1 for 1-based, +1 for the header row
    const dateRaw = (raw[CSV_COLUMNS.DATE] || '').trim();
    const topicName = (raw[CSV_COLUMNS.TOPIC_NAME] || '').trim();
    const taskText = (raw[CSV_COLUMNS.TASK_TEXT] || '').trim();

    if (!dateRaw && !topicName && !taskText) return; // fully blank row, ignore silently

    const date = parseCsvDate(dateRaw);
    if (!date) {
      errors.push({ rowNumber, reason: `תאריך לא תקין: "${dateRaw}"` });
      return;
    }
    if (!topicName) {
      errors.push({ rowNumber, reason: 'שם הספק חסר' });
      return;
    }

    rows.push({ rowNumber, date, topicName, taskText: taskText || null });
  });

  return { rows, errors, headerError: null };
}

export default { parseCsvText, CSV_COLUMNS };
