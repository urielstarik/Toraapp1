// src/services/dailyLabelGenerators.js
//
// Pluggable registry for topics that follow a fixed global calendar cycle
// (Daf Yomi, the monthly Tehillim division, etc.). A topic opts in by
// setting its `sync_source` column to one of these keys; the rollover
// service looks up the matching generator when creating that topic's
// task for the day and stores the result as the initial note_text, so
// the task shows real content ("בבא קמא דף ד'") instead of a blank field.
//
// To add a new global-sync topic later: write an async (date) => string
// generator, register it here under a new key, and set that key as the
// topic's sync_source.

import { getDafYomiLabel } from '../utils/dafYomi';
import { getTehillimLabel } from '../utils/tehillimCycle';
import { fetchHebcalDailyLearning } from '../utils/hebcalDailyLearning';

export const DAILY_LABEL_GENERATORS = {
  daf_yomi: async (date) => getDafYomiLabel(date),
  tehillim_cycle: async (date) => getTehillimLabel(date),
  // Mishnah Yomi has no local fallback — it's a curated daily assignment
  // (two mishnayot per day, cycling through all six orders), not
  // something derivable from calendar math the way Tehillim's monthly
  // division is. If Hebcal is unreachable this simply returns null, and
  // the task is created without a preset label rather than a guess.
  mishna_yomi: async (date) => fetchHebcalDailyLearning('mf', date),
};

/** Returns a label string, or null if the topic has no sync_source / no matching generator. */
export async function generateDailyLabel(topic, date = new Date()) {
  const generator = topic?.sync_source && DAILY_LABEL_GENERATORS[topic.sync_source];
  if (!generator) return null;
  try {
    return await generator(date);
  } catch (err) {
    return null; // Fail quietly — the task still gets created, just without a preset label.
  }
}

export default { DAILY_LABEL_GENERATORS, generateDailyLabel };
