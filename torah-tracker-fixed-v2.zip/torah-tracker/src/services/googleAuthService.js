// src/services/googleAuthService.js
import { Platform } from 'react-native';
import * as AuthSession from 'expo-auth-session';
import { GOOGLE_OAUTH_CONFIG, GOOGLE_DISCOVERY } from '../config/googleConfig';
import { saveTokens, loadTokens, clearTokens } from './secureTokenStore';

const CLIENT_ID = Platform.select({
  ios: GOOGLE_OAUTH_CONFIG.iosClientId,
  android: GOOGLE_OAUTH_CONFIG.androidClientId,
  default: GOOGLE_OAUTH_CONFIG.webClientId,
});

const EXPIRY_SAFETY_MARGIN_MS = 60 * 1000; // refresh a minute early

export async function isSignedIn() {
  const tokens = await loadTokens();
  return !!tokens?.refreshToken;
}

/**
 * Exchanges an authorization code (from the interactive sign-in flow)
 * for an access + refresh token pair, and persists them.
 */
export async function exchangeCodeForTokens(code, codeVerifier, redirectUri) {
  const result = await AuthSession.exchangeCodeAsync(
    {
      clientId: CLIENT_ID,
      code,
      redirectUri,
      extraParams: { code_verifier: codeVerifier },
    },
    GOOGLE_DISCOVERY
  );

  await saveTokens({
    accessToken: result.accessToken,
    refreshToken: result.refreshToken,
    expiresAt: Date.now() + (result.expiresIn ?? 3600) * 1000,
  });

  return result;
}

/**
 * Returns a currently-valid access token, transparently refreshing it
 * first if it's expired (or about to expire). Returns null if the user
 * has never signed in.
 */
export async function ensureValidAccessToken() {
  const tokens = await loadTokens();
  if (!tokens?.refreshToken) return null;

  const isExpired = !tokens.expiresAt || Date.now() > tokens.expiresAt - EXPIRY_SAFETY_MARGIN_MS;
  if (!isExpired) return tokens.accessToken;

  try {
    const refreshed = await AuthSession.refreshAsync(
      { clientId: CLIENT_ID, refreshToken: tokens.refreshToken },
      GOOGLE_DISCOVERY
    );
    const nextTokens = {
      accessToken: refreshed.accessToken,
      // Google doesn't always return a new refresh token — keep the old one.
      refreshToken: refreshed.refreshToken || tokens.refreshToken,
      expiresAt: Date.now() + (refreshed.expiresIn ?? 3600) * 1000,
    };
    await saveTokens(nextTokens);
    return nextTokens.accessToken;
  } catch (err) {
    // Refresh token is likely revoked/invalid — force a fresh sign-in.
    await clearTokens();
    return null;
  }
}

export async function signOut() {
  const tokens = await loadTokens();
  if (tokens?.accessToken) {
    try {
      await AuthSession.revokeAsync(
        { clientId: CLIENT_ID, token: tokens.accessToken },
        GOOGLE_DISCOVERY
      );
    } catch (err) {
      // Best-effort revoke — proceed to clear local tokens regardless.
    }
  }
  await clearTokens();
}

export default { isSignedIn, exchangeCodeForTokens, ensureValidAccessToken, signOut };
