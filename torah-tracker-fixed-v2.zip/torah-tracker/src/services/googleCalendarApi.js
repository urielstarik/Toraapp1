// src/services/googleCalendarApi.js
import { CALENDAR_API_BASE, TARGET_CALENDAR_ID } from '../config/googleConfig';

async function calendarFetch(accessToken, path, options = {}) {
  const res = await fetch(`${CALENDAR_API_BASE}${path}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
  });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`Google Calendar API ${res.status}: ${body}`);
  }
  // DELETE requests return an empty body.
  const text = await res.text();
  return text ? JSON.parse(text) : null;
}

/**
 * Fetches events for a single calendar day, for rendering read-only
 * "busy" blocks on the timeline.
 */
export async function listEventsForDate(accessToken, dateStr) {
  const timeMin = new Date(`${dateStr}T00:00:00`).toISOString();
  const timeMax = new Date(`${dateStr}T23:59:59`).toISOString();
  const params = new URLSearchParams({
    timeMin,
    timeMax,
    singleEvents: 'true',
    orderBy: 'startTime',
  });
  const data = await calendarFetch(
    accessToken,
    `/calendars/${encodeURIComponent(TARGET_CALENDAR_ID)}/events?${params.toString()}`
  );
  return (data?.items || []).filter((e) => e.start?.dateTime); // skip all-day events here
}

/**
 * Creates a timed event (used when a study task or activity is placed
 * on the timeline).
 */
export async function insertTimedEvent(accessToken, { summary, startISO, endISO }) {
  return calendarFetch(
    accessToken,
    `/calendars/${encodeURIComponent(TARGET_CALENDAR_ID)}/events`,
    {
      method: 'POST',
      body: JSON.stringify({
        summary,
        start: { dateTime: startISO },
        end: { dateTime: endISO },
      }),
    }
  );
}

/** Updates an event's title, e.g. to append a completion checkmark. */
export async function patchEventSummary(accessToken, eventId, summary) {
  return calendarFetch(
    accessToken,
    `/calendars/${encodeURIComponent(TARGET_CALENDAR_ID)}/events/${encodeURIComponent(eventId)}`,
    {
      method: 'PATCH',
      body: JSON.stringify({ summary }),
    }
  );
}

/** Updates an event's time span, e.g. after the block is moved/resized. */
export async function patchEventTime(accessToken, eventId, { startISO, endISO }) {
  return calendarFetch(
    accessToken,
    `/calendars/${encodeURIComponent(TARGET_CALENDAR_ID)}/events/${encodeURIComponent(eventId)}`,
    {
      method: 'PATCH',
      body: JSON.stringify({
        start: { dateTime: startISO },
        end: { dateTime: endISO },
      }),
    }
  );
}

/** Creates a full-day event, e.g. the "daily achievement" celebration. */
export async function insertAllDayEvent(accessToken, { summary, dateStr }) {
  const nextDay = new Date(`${dateStr}T00:00:00`);
  nextDay.setDate(nextDay.getDate() + 1);
  const nextDayStr = nextDay.toISOString().slice(0, 10);

  return calendarFetch(
    accessToken,
    `/calendars/${encodeURIComponent(TARGET_CALENDAR_ID)}/events`,
    {
      method: 'POST',
      body: JSON.stringify({
        summary,
        start: { date: dateStr },
        end: { date: nextDayStr }, // Google's all-day events use an exclusive end date
      }),
    }
  );
}

export default {
  listEventsForDate,
  insertTimedEvent,
  patchEventSummary,
  patchEventTime,
  insertAllDayEvent,
};
