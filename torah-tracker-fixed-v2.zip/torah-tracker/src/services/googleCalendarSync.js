// src/services/googleCalendarSync.js
import { ensureValidAccessToken } from './googleAuthService';
import {
  listEventsForDate, insertTimedEvent, patchEventSummary, patchEventTime, insertAllDayEvent,
} from './googleCalendarApi';
import { setGoogleEventId, getScheduleItemForTask } from '../models/ScheduleItem';
import { getItem, setItem } from '../database/kv';
import { todayDateString } from '../models/Task';

const ACHIEVEMENT_TITLE = 'הספקים הושלמו בהצלחה ✓';

function achievementFlagKey(date) {
  return `achievement_event_created_${date}`;
}

function buildDateTimeISO(dateStr, minutesFromMidnight) {
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(y, m - 1, d, 0, 0, 0, 0);
  dt.setMinutes(minutesFromMidnight);
  return dt.toISOString();
}

function isoToMinutesOfDay(iso) {
  const dt = new Date(iso);
  return dt.getHours() * 60 + dt.getMinutes();
}

// --- Pull: read-only busy blocks for the timeline ------------------------

/**
 * Fetches today's existing Google Calendar events and converts them into
 * the same {start_minute, duration_minutes} shape the timeline uses, for
 * rendering as read-only grey blocks. Returns [] if not signed in, or if
 * the request fails (e.g. offline) — the timeline just shows none.
 */
export async function fetchGoogleBusyBlocksForDate(date = todayDateString()) {
  const accessToken = await ensureValidAccessToken();
  if (!accessToken) return [];

  try {
    const events = await listEventsForDate(accessToken, date);
    return events.map((event) => {
      const startMinute = isoToMinutesOfDay(event.start.dateTime);
      const endMinute = isoToMinutesOfDay(event.end.dateTime);
      return {
        id: event.id,
        title: event.summary || '(ללא כותרת)',
        start_minute: startMinute,
        duration_minutes: Math.max(endMinute - startMinute, 5),
      };
    });
  } catch (err) {
    return [];
  }
}

// --- Push: create a Google event when a task is placed on the timeline --

/**
 * Creates a Google Calendar event for a just-placed schedule item and
 * records the resulting event id. No-ops quietly if not signed in.
 */
export async function pushScheduledItemToGoogle({
  scheduleItemId, calendarTitle, date, startMinute, durationMinutes,
}) {
  const accessToken = await ensureValidAccessToken();
  if (!accessToken) return null;

  try {
    const startISO = buildDateTimeISO(date, startMinute);
    const endISO = buildDateTimeISO(date, startMinute + durationMinutes);
    const event = await insertTimedEvent(accessToken, {
      summary: calendarTitle,
      startISO,
      endISO,
    });
    if (event?.id) {
      await setGoogleEventId(scheduleItemId, event.id);
    }
    return event;
  } catch (err) {
    return null; // Sync is best-effort — the local schedule item still exists either way.
  }
}

// --- Completion sync: append/remove the checkmark on the linked event ---

/**
 * When a task is toggled complete/incomplete, updates the title of its
 * linked Google Calendar event (if one exists) to append or remove the
 * "✓" suffix. No-ops quietly if the task was never placed on the
 * timeline, or the user isn't signed in.
 */
export async function syncTaskCompletionToGoogle(taskId, isCompleted, date) {
  const accessToken = await ensureValidAccessToken();
  if (!accessToken) return;

  const item = await getScheduleItemForTask(taskId, date);
  if (!item?.google_event_id) return;

  const baseTitle = item.calendar_title || item.title;
  const nextTitle = isCompleted ? `${baseTitle} ✓` : baseTitle;

  try {
    await patchEventSummary(accessToken, item.google_event_id, nextTitle);
  } catch (err) {
    // Best-effort — local completion state is unaffected either way.
  }
}

// --- Daily achievement: all-day event the moment progress hits 100% -----

/**
 * Called whenever the dashboard's progress is recomputed. If today's
 * progress has just reached 100% and the achievement event hasn't
 * already been created today, creates the all-day celebration event.
 * Idempotent via a kv_store flag, so it only ever fires once per day.
 */
export async function maybeCreateAchievementEvent(completed, total, date = todayDateString()) {
  if (total <= 0 || completed < total) return;

  const flagKey = achievementFlagKey(date);
  let alreadyCreated = null;
  try {
    const stored = await getItem(flagKey);
    alreadyCreated = stored;
  } catch (err) {
    alreadyCreated = null;
  }
  if (alreadyCreated === '1') return;

  const accessToken = await ensureValidAccessToken();
  if (!accessToken) return;

  try {
    await insertAllDayEvent(accessToken, { summary: ACHIEVEMENT_TITLE, dateStr: date });
    await setItem(flagKey, '1');
  } catch (err) {
    // Leave the flag unset so it retries on the next progress refresh.
  }
}

// --- Timing sync: keep a moved/resized block's Google event in sync -----

/**
 * When an already-placed block is dragged to a new time or resized,
 * updates the linked Google Calendar event's start/end to match.
 * No-ops quietly if the block has no linked event or the user isn't
 * signed in.
 */
export async function syncBlockTimingToGoogle(block, newStartMinute, newDurationMinutes, date) {
  if (!block?.google_event_id) return;
  const accessToken = await ensureValidAccessToken();
  if (!accessToken) return;

  try {
    const startISO = buildDateTimeISO(date, newStartMinute);
    const endISO = buildDateTimeISO(date, newStartMinute + newDurationMinutes);
    await patchEventTime(accessToken, block.google_event_id, { startISO, endISO });
  } catch (err) {
    // Best-effort — local timing is unaffected either way.
  }
}

export default {
  fetchGoogleBusyBlocksForDate,
  pushScheduledItemToGoogle,
  syncTaskCompletionToGoogle,
  maybeCreateAchievementEvent,
  syncBlockTimingToGoogle,
};
