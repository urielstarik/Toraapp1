// src/services/notifications/backgroundTask.js
//
// Registers a background fetch task so the evening-notification logic
// keeps getting re-evaluated even while the app isn't open — this is
// what lets Smart Silence "un-suppress" shortly after a calendar event
// ends, or DND being manually toggled off, without requiring the user
// to reopen the app.
//
// Important caveat: the OS controls exactly when background fetch tasks
// actually run (both iOS and Android throttle and batch these for
// battery reasons). MIN_BACKGROUND_FETCH_INTERVAL_SECONDS is advisory,
// not a guarantee — in practice this typically runs every 15 minutes to
// a few hours depending on device usage patterns. The foreground handler
// (notificationSetup.js) is the reliable enforcement point; this task is
// a best-effort background top-up.

import * as TaskManager from 'expo-task-manager';
import * as BackgroundFetch from 'expo-background-fetch';
import {
  BACKGROUND_TASK_NAME, MIN_BACKGROUND_FETCH_INTERVAL_SECONDS,
} from '../../config/notificationConfig';
import { initDatabase } from '../../database/db';
import { refreshEveningNotification } from './eveningScheduler';

TaskManager.defineTask(BACKGROUND_TASK_NAME, async () => {
  try {
    await initDatabase(); // background tasks run in a fresh JS context
    const result = await refreshEveningNotification();
    return result.scheduled
      ? BackgroundFetch.BackgroundFetchResult.NewData
      : BackgroundFetch.BackgroundFetchResult.NoData;
  } catch (err) {
    return BackgroundFetch.BackgroundFetchResult.Failed;
  }
});

export async function registerBackgroundTask() {
  const isRegistered = await TaskManager.isTaskRegisteredAsync(BACKGROUND_TASK_NAME);
  if (isRegistered) return;

  await BackgroundFetch.registerTaskAsync(BACKGROUND_TASK_NAME, {
    minimumInterval: MIN_BACKGROUND_FETCH_INTERVAL_SECONDS,
    stopOnTerminate: false,
    startOnBoot: true,
  });
}

export async function unregisterBackgroundTask() {
  const isRegistered = await TaskManager.isTaskRegisteredAsync(BACKGROUND_TASK_NAME);
  if (isRegistered) {
    await BackgroundFetch.unregisterTaskAsync(BACKGROUND_TASK_NAME);
  }
}

export default { registerBackgroundTask, unregisterBackgroundTask };
