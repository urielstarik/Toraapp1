// src/services/notifications/eveningMessage.js

// Hebrew counting words (masculine, matching "לימודים") for small counts —
// covers the realistic range of daily study topics. Falls back to the
// plain digit for anything larger, which still reads fine in Hebrew.
const COUNT_WORDS = {
  2: 'שני', 3: 'שלושה', 4: 'ארבעה', 5: 'חמישה',
  6: 'שישה', 7: 'שבעה', 8: 'שמונה', 9: 'תשעה', 10: 'עשרה',
};

/**
 * Returns the exact notification body text, or null if no notification
 * should be sent (progress is already 100%, or there's nothing to do).
 */
export function buildEveningMessage(completed, total) {
  const remaining = total - completed;
  if (total <= 0 || remaining <= 0) return null;

  if (remaining === 1) {
    return 'נשאר לך עוד לימוד קטן אחד לסגור את היום בראש שקט';
  }

  const countWord = COUNT_WORDS[remaining] || String(remaining);
  return `נשארו לך עוד ${countWord} לימודים קטנים לסגור את היום בראש שקט`;
}

export default { buildEveningMessage };
