// src/services/notifications/eveningScheduler.js
import * as Notifications from 'expo-notifications';
import { getItem, setItem, deleteItem } from '../../database/kv';
import { getTodayProgress, todayDateString } from '../../models/Task';
import { getEveningTime } from './notificationSettings';
import { buildEveningMessage } from './eveningMessage';
import { shouldSuppressNotifications } from './smartSilence';
import { EVENING_NOTIFICATION_DATA_TYPE } from '../../config/notificationConfig';

const KEY_SCHEDULED_ID = 'evening_notification_scheduled_id';
const KEY_SCHEDULED_DATE = 'evening_notification_scheduled_date';

function deliveredFlagKey(date) {
  return `evening_notification_delivered_${date}`;
}

async function cancelExistingScheduledNotification() {
  const id = await getItem(KEY_SCHEDULED_ID);
  if (id) {
    try {
      await Notifications.cancelScheduledNotificationAsync(id);
    } catch (err) {
      // Already fired or already cancelled — fine either way.
    }
  }
  await deleteItem(KEY_SCHEDULED_ID).catch(() => {});
  await deleteItem(KEY_SCHEDULED_DATE).catch(() => {});
}

async function wasAlreadyDeliveredToday(date) {
  const flag = await getItem(deliveredFlagKey(date));
  return flag === '1';
}

/**
 * Marks today's evening notification as delivered, so it's never
 * scheduled again for the same day even if state changes afterward.
 * Call this from a Notifications.addNotificationReceivedListener.
 */
export async function markEveningNotificationDelivered(date = todayDateString()) {
  await setItem(deliveredFlagKey(date), '1');
  await cancelExistingScheduledNotification();
}

/**
 * The single entry point for keeping the evening notification correct.
 * Call this whenever anything relevant changes: app launch, rollover,
 * a task being completed, Focus Mode being toggled, or periodically from
 * the background task. It's always safe to call — cheap, idempotent, and
 * fully re-derives the right state from scratch each time.
 */
export async function refreshEveningNotification() {
  const date = todayDateString();

  // Already sent today — never schedule again, no matter what changes.
  if (await wasAlreadyDeliveredToday(date)) {
    await cancelExistingScheduledNotification();
    return { scheduled: false, reason: 'already_delivered' };
  }

  // Manual Focus Mode strictly blocks all proactive notifications for
  // the rest of the day, regardless of progress.
  const { suppressed, reason } = await shouldSuppressNotifications();
  if (suppressed) {
    await cancelExistingScheduledNotification();
    return { scheduled: false, reason };
  }

  // If progress is already 100%, silently abort — nothing to remind about.
  const { completed, total } = await getTodayProgress();
  const message = buildEveningMessage(completed, total);
  if (!message) {
    await cancelExistingScheduledNotification();
    return { scheduled: false, reason: 'progress_complete' };
  }

  // Always cancel and re-create with fresh content: this function is only
  // called on meaningful events (see the callers list above), not on
  // every render, so the extra OS call is cheap — and it's what keeps
  // the remaining-task count in the message accurate as tasks are
  // completed throughout the day.
  await cancelExistingScheduledNotification();

  const { hour, minute } = await getEveningTime();
  const nowMinuteOfDay = new Date().getHours() * 60 + new Date().getMinutes();
  const targetMinuteOfDay = hour * 60 + minute;

  // If today's evening time has already passed (e.g. it was held back by
  // a meeting or DND until now), fire almost immediately as a same-day
  // catch-up rather than letting a plain {hour, minute} trigger roll over
  // to tomorrow.
  const trigger = nowMinuteOfDay >= targetMinuteOfDay
    ? { seconds: 2, repeats: false }
    : { hour, minute, repeats: false };

  const id = await Notifications.scheduleNotificationAsync({
    content: {
      title: 'תזכורת יומית',
      body: message,
      data: { type: EVENING_NOTIFICATION_DATA_TYPE, date },
    },
    trigger,
  });

  await setItem(KEY_SCHEDULED_ID, id);
  await setItem(KEY_SCHEDULED_DATE, date);

  return { scheduled: true, reason: 'scheduled' };
}

export default { refreshEveningNotification, markEveningNotificationDelivered };
