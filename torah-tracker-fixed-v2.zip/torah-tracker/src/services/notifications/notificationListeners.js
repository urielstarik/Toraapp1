// src/services/notifications/notificationListeners.js
import * as Notifications from 'expo-notifications';
import { EVENING_NOTIFICATION_DATA_TYPE } from '../../config/notificationConfig';
import { markEveningNotificationDelivered } from './eveningScheduler';

/**
 * Registers the listener that flips the "already delivered today" flag
 * the moment our evening notification actually fires (whether the app is
 * foregrounded, backgrounded, or the notification tray is checked while
 * the app was closed and then reopened). Returns an unsubscribe function.
 */
export function registerEveningNotificationDeliveryListener() {
  const subscription = Notifications.addNotificationReceivedListener((notification) => {
    const data = notification?.request?.content?.data;
    if (data?.type === EVENING_NOTIFICATION_DATA_TYPE) {
      markEveningNotificationDelivered(data.date);
    }
  });
  return () => subscription.remove();
}

export default { registerEveningNotificationDeliveryListener };
