// src/services/notifications/notificationSettings.js
import { getItem, setItem } from '../../database/kv';
import { DEFAULT_EVENING_HOUR, DEFAULT_EVENING_MINUTE } from '../../config/notificationConfig';

const KEY_HOUR = 'evening_notification_hour';
const KEY_MINUTE = 'evening_notification_minute';

export async function getEveningTime() {
  const [hourRaw, minuteRaw] = await Promise.all([getItem(KEY_HOUR), getItem(KEY_MINUTE)]);
  return {
    hour: hourRaw !== null ? Number(hourRaw) : DEFAULT_EVENING_HOUR,
    minute: minuteRaw !== null ? Number(minuteRaw) : DEFAULT_EVENING_MINUTE,
  };
}

export async function setEveningTime(hour, minute) {
  await setItem(KEY_HOUR, String(hour));
  await setItem(KEY_MINUTE, String(minute));
}

export default { getEveningTime, setEveningTime };
