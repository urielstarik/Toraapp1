// src/services/notifications/notificationSetup.js
import * as Notifications from 'expo-notifications';
import { shouldSuppressNotifications } from './smartSilence';

export async function requestNotificationPermissions() {
  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  if (existingStatus === 'granted') return true;
  const { status } = await Notifications.requestPermissionsAsync();
  return status === 'granted';
}

/**
 * Governs any notification that's about to be presented while the app is
 * in the foreground. This is the most reliable Smart Silence enforcement
 * point — it runs live, in JS, right at delivery time — unlike the
 * background task, which is subject to OS scheduling delays.
 */
export function configureNotificationHandler() {
  Notifications.setNotificationHandler({
    handleNotification: async () => {
      const { suppressed } = await shouldSuppressNotifications();
      if (suppressed) {
        return {
          shouldShowAlert: false,
          shouldPlaySound: false,
          shouldSetBadge: false,
        };
      }
      return {
        shouldShowAlert: true,
        shouldPlaySound: true,
        shouldSetBadge: false,
      };
    },
  });
}

export default { requestNotificationPermissions, configureNotificationHandler };
