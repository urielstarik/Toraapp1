// src/services/notifications/smartSilence.js
import { getItem } from '../../database/kv';
import { fetchGoogleBusyBlocksForDate } from '../googleCalendarSync';
import { currentMinuteOfDay } from '../../models/ScheduleItem';
import { todayDateString } from '../../models/Task';

const KEY_FOCUS_MODE = 'focus_mode_dnd'; // must match FocusModeContext's storage key

async function isManualDoNotDisturbOn() {
  const stored = await getItem(KEY_FOCUS_MODE);
  return stored === '1';
}

/**
 * True if a Google Calendar event is happening right now. Only meaningful
 * when signed in; if not signed in (or the fetch fails), calendar sync
 * simply contributes nothing and this returns false.
 */
async function isCalendarEventActiveNow() {
  const blocks = await fetchGoogleBusyBlocksForDate(todayDateString());
  const nowMinute = currentMinuteOfDay();
  return blocks.some(
    (b) => nowMinute >= b.start_minute && nowMinute < b.start_minute + b.duration_minutes
  );
}

/**
 * The single source of truth for whether the app should hold back any
 * notification right now — used both by the foreground notification
 * handler and by the background evening-check task.
 */
export async function shouldSuppressNotifications() {
  const [manualDnd, calendarBusy] = await Promise.all([
    isManualDoNotDisturbOn(),
    isCalendarEventActiveNow(),
  ]);
  return {
    suppressed: manualDnd || calendarBusy,
    reason: manualDnd ? 'focus_mode' : (calendarBusy ? 'calendar_event' : null),
  };
}

export default { shouldSuppressNotifications };
