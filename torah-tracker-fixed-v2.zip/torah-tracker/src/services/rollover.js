// src/services/rollover.js
//
// The end-of-day rollover routine. React Native apps have no true
// background cron, so this runs as an in-app scheduler with two triggers:
//
//   1. On every app launch (via runRolloverIfNeeded, called from App.js) —
//      catches "first launch of a new calendar day" even if the device
//      was off/asleep through midnight.
//   2. A self-rescheduling setTimeout aimed at the next local midnight —
//      catches the case where the app is left open across midnight.
//
// Each run:
//   - migrates any 'pending' task dated before today to 'overdue'
//   - generates today's task row for every topic (status 'pending'),
//     pre-filling note_text for global-cycle topics (Daf Yomi, Tehillim)
//   - records the date it ran, so it only does this once per day
//   - emits 'rollover complete' so mounted screens can refresh instantly

import { getDb } from '../database/db';
import { getItem, setItem } from '../database/kv';
import { getAllTopics } from '../models/Topic';
import {
  markPastPendingAsOverdue,
  ensureTaskForTopicAndDate,
  todayDateString,
} from '../models/Task';
import { generateDailyLabel } from './dailyLabelGenerators';
import { emitRolloverComplete } from './rolloverBus';

const KEY_LAST_ROLLOVER_DATE = 'last_rollover_date';

let midnightTimer = null;

async function migrateOverdue() {
  await markPastPendingAsOverdue();
}

async function generateTodaysTasks(date = new Date()) {
  const dateStr = todayDateString(date);
  const topics = await getAllTopics();

  await Promise.all(
    topics.map(async (topic) => {
      const label = await generateDailyLabel(topic, date);
      await ensureTaskForTopicAndDate(topic.id, dateStr, label);
    })
  );

  return topics.length;
}

/**
 * Runs the rollover exactly once per calendar day. Safe to call as often
 * as you like (e.g. every app foreground) — it no-ops if already run today.
 * Returns true if it actually ran, false if it was already up to date.
 */
export async function runRolloverIfNeeded(now = new Date()) {
  await getDb(); // ensure DB is open before touching kv_store
  const today = todayDateString(now);
  const lastRun = await getItem(KEY_LAST_ROLLOVER_DATE);

  if (lastRun === today) {
    return false;
  }

  await migrateOverdue();
  const topicCount = await generateTodaysTasks(now);
  await setItem(KEY_LAST_ROLLOVER_DATE, today);

  emitRolloverComplete({ date: today, topicCount });
  return true;
}

function msUntilNextMidnight(now = new Date()) {
  const next = new Date(now);
  next.setHours(24, 0, 0, 0);
  return next.getTime() - now.getTime();
}

/**
 * Starts the self-rescheduling midnight scheduler. Call once from the
 * app root (after the initial runRolloverIfNeeded). Returns a cleanup
 * function to cancel the pending timer (e.g. on unmount).
 */
export function startMidnightScheduler() {
  function scheduleNext() {
    const delay = msUntilNextMidnight();
    midnightTimer = setTimeout(async () => {
      await runRolloverIfNeeded();
      scheduleNext();
    }, delay);
  }

  scheduleNext();

  return () => {
    if (midnightTimer) {
      clearTimeout(midnightTimer);
      midnightTimer = null;
    }
  };
}

export default { runRolloverIfNeeded, startMidnightScheduler };
