// src/services/rolloverBus.js
//
// Tiny pub-sub so any screen can react the instant a rollover finishes —
// no manual app restart needed to see fresh tasks / cleared overdue items.

const listeners = new Set();

export function subscribeToRollover(callback) {
  listeners.add(callback);
  return () => listeners.delete(callback);
}

export function emitRolloverComplete(payload) {
  for (const cb of listeners) {
    try {
      cb(payload);
    } catch (err) {
      // A misbehaving listener shouldn't break the others.
    }
  }
}

export default { subscribeToRollover, emitRolloverComplete };
