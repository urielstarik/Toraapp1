// src/services/secureTokenStore.js
import * as SecureStore from 'expo-secure-store';

const KEY = 'google_oauth_tokens';

// Shape: { accessToken, refreshToken, expiresAt (ms epoch) }

export async function saveTokens(tokens) {
  await SecureStore.setItemAsync(KEY, JSON.stringify(tokens));
}

export async function loadTokens() {
  const raw = await SecureStore.getItemAsync(KEY);
  return raw ? JSON.parse(raw) : null;
}

export async function clearTokens() {
  await SecureStore.deleteItemAsync(KEY);
}

export default { saveTokens, loadTokens, clearTokens };
