// src/theme/colors.js
// Soft, calm palette: pastels, earth tones, mint, deep blue.
// Overdue/missing items use a gentle gray — never alarming red.

export const colors = {
  background: '#F7F5F0',      // warm off-white / sand
  surface: '#FFFFFF',
  surfaceAlt: '#EFEAE1',      // soft earth tone card background

  primary: '#3A5A6B',         // deep, muted blue
  primaryLight: '#7FA8B5',

  accentMint: '#A8CBB7',      // mint accent for completed items
  accentSage: '#C9D6C5',

  textPrimary: '#3B3B3B',
  textSecondary: '#7A7A75',

  // Status colors
  completed: '#8FB99F',       // muted mint-green
  pending: '#C9B896',         // soft tan
  overdue: '#B5B0A8',         // gentle neutral gray — intentionally NOT red

  divider: '#E4DFD5',
  shadow: 'rgba(0,0,0,0.06)',
};

export default colors;
