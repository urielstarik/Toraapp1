// src/theme/fonts.js
// Classic, respectable, highly-legible fonts with solid Hebrew glyph support.
// Frank Ruhl Libre / David Libre read as "traditional sefer" typography;
// Assistant is a clean, modern fallback for UI chrome.

export const fontFamilies = {
  serifHebrew: 'FrankRuhlLibre-Regular',   // headings, quotes, topic names
  serifHebrewBold: 'FrankRuhlLibre-Bold',
  sansHebrew: 'Assistant-Regular',         // body text, buttons, labels
  sansHebrewMedium: 'Assistant-Medium',
};

// Load these via expo-font in App.js, e.g.:
// await Font.loadAsync({
//   'FrankRuhlLibre-Regular': require('../assets/fonts/FrankRuhlLibre-Regular.ttf'),
//   'FrankRuhlLibre-Bold': require('../assets/fonts/FrankRuhlLibre-Bold.ttf'),
//   'Assistant-Regular': require('../assets/fonts/Assistant-Regular.ttf'),
//   'Assistant-Medium': require('../assets/fonts/Assistant-Medium.ttf'),
// });

export const typography = {
  quote: {
    fontFamily: fontFamilies.serifHebrew,
    fontSize: 18,
    lineHeight: 28,
    writingDirection: 'rtl',
  },
  topicTitle: {
    fontFamily: fontFamilies.serifHebrewBold,
    fontSize: 17,
    writingDirection: 'rtl',
  },
  body: {
    fontFamily: fontFamilies.sansHebrew,
    fontSize: 15,
    writingDirection: 'rtl',
  },
  label: {
    fontFamily: fontFamilies.sansHebrewMedium,
    fontSize: 13,
    writingDirection: 'rtl',
  },
};

export default typography;
