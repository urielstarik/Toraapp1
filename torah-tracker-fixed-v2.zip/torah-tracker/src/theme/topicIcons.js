// src/theme/topicIcons.js
// Maps stored icon keys (Feather icon names) to a curated selectable set.
// Keeping this list small keeps the icon picker calm and uncluttered.

export const TOPIC_ICON_OPTIONS = [
  'book-open',
  'book',
  'feather',
  'moon',
  'sun',
  'star',
  'heart',
  'bookmark',
  'music',
  'anchor',
  'compass',
  'sunrise',
];

// Fallback for topics whose icon isn't recognized.
export const DEFAULT_TOPIC_ICON = 'book-open';

export default { TOPIC_ICON_OPTIONS, DEFAULT_TOPIC_ICON };
