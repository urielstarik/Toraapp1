// src/utils/dafYomi.js
//
// Resolves today's Daf Yomi (Talmud Bavli daily page) as a Hebrew label,
// e.g. "בבא קמא דף ד'". Three strategies, in order:
//
//   1. Live lookup against Sefaria's public calendars API — authoritative,
//      no cycle-math drift risk.
//   2. Live lookup against Hebcal's calendar API — a second independent
//      source, tried if Sefaria is unreachable.
//   3. Local fallback: calculate from the well-known cycle start date
//      (Rosh Hashanah 5684 / Sept 11, 1923) and the standard Vilna Shas
//      daf count per tractate, for when the device is fully offline.
//
// The fallback table is public, static calendrical data (not creative
// content), so it's safe to ship as a constant.

import { fetchHebcalDailyLearning } from './hebcalDailyLearning';

const CYCLE_START = new Date(Date.UTC(1923, 8, 11)); // 1923-09-11, cycle start
const MS_PER_DAY = 24 * 60 * 60 * 1000;

// [tractate name (Hebrew), number of dapim counted in the cycle
//  (i.e. daf 2 through the final daf)]
const TRACTATE_DAF_COUNTS = [
  ['ברכות', 63], ['שבת', 156], ['עירובין', 104], ['פסחים', 120],
  ['שקלים', 21], ['יומא', 87], ['סוכה', 55], ['ביצה', 39],
  ['ראש השנה', 34], ['תענית', 30], ['מגילה', 31], ['מועד קטן', 28],
  ['חגיגה', 26], ['יבמות', 121], ['כתובות', 111], ['נדרים', 90],
  ['נזיר', 65], ['סוטה', 48], ['גיטין', 89], ['קידושין', 81],
  ['בבא קמא', 118], ['בבא מציעא', 118], ['בבא בתרא', 175],
  ['סנהדרין', 112], ['מכות', 23], ['שבועות', 48], ['עבודה זרה', 75],
  ['הוריות', 13], ['זבחים', 119], ['מנחות', 109], ['חולין', 141],
  ['בכורות', 60], ['ערכין', 33], ['תמורה', 33], ['כריתות', 27],
  ['מעילה', 21], ['תמיד', 8], ['נדה', 72],
];

const CYCLE_LENGTH = TRACTATE_DAF_COUNTS.reduce((sum, [, n]) => sum + n, 0);

function toUtcMidnight(date) {
  return Date.UTC(date.getFullYear(), date.getMonth(), date.getDate());
}

/** Local, offline calculation. Returns { tractate, daf } (daf is a number, starting at 2). */
export function calculateDafYomiLocal(date = new Date()) {
  const daysSinceStart = Math.floor((toUtcMidnight(date) - CYCLE_START.getTime()) / MS_PER_DAY);
  const dayInCycle = ((daysSinceStart % CYCLE_LENGTH) + CYCLE_LENGTH) % CYCLE_LENGTH;

  let remaining = dayInCycle;
  for (const [tractate, count] of TRACTATE_DAF_COUNTS) {
    if (remaining < count) {
      return { tractate, daf: remaining + 2 };
    }
    remaining -= count;
  }
  // Should be unreachable given CYCLE_LENGTH is the sum of all counts.
  return { tractate: TRACTATE_DAF_COUNTS[0][0], daf: 2 };
}

function formatDafLabel({ tractate, daf }) {
  return `${tractate} דף ${daf}`;
}

async function fetchFromSefaria(date) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 4000);
  try {
    const res = await fetch(
      `https://www.sefaria.org/api/calendars?year=${date.getFullYear()}&month=${date.getMonth() + 1}&day=${date.getDate()}`,
      { signal: controller.signal }
    );
    if (!res.ok) return null;
    const data = await res.json();
    const dafItem = (data.calendar_items || []).find((item) => item.title?.en === 'Daf Yomi');
    return dafItem?.displayValue?.he || null;
  } catch (err) {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

/**
 * Resolves today's label: Sefaria first, then Hebcal, then the local
 * cycle calculation if both live providers are unreachable (e.g. offline).
 */
export async function getDafYomiLabel(date = new Date()) {
  const fromSefaria = await fetchFromSefaria(date);
  if (fromSefaria) return fromSefaria;

  const fromHebcal = await fetchHebcalDailyLearning('ss', date);
  if (fromHebcal) return fromHebcal;

  return formatDafLabel(calculateDafYomiLocal(date));
}

export default { getDafYomiLabel, calculateDafYomiLocal };
