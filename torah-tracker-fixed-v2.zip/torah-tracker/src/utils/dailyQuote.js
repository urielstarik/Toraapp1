// src/utils/dailyQuote.js
//
// Picks one quote at random from QUOTES and keeps it stable for the
// entire calendar day. A new random quote is chosen the first time
// the app is opened after local midnight.
//
// Persistence uses the app's key-value store (see src/database/kv.js).
// Swap `getItem`/`setItem` for AsyncStorage if you prefer that instead
// of SQLite-backed storage.

import { QUOTES } from '../data/quotes';
import { getItem, setItem } from '../database/kv';

const KEY_QUOTE_DATE = 'daily_quote_date';   // 'YYYY-MM-DD' the cached quote belongs to
const KEY_QUOTE_INDEX = 'daily_quote_index'; // index into QUOTES

function todayDateString(d = new Date()) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function pickRandomIndex(excludeIndex = null) {
  if (QUOTES.length <= 1) return 0;
  let idx;
  do {
    idx = Math.floor(Math.random() * QUOTES.length);
  } while (idx === excludeIndex);
  return idx;
}

/**
 * Returns today's quote text, generating + caching a new random pick
 * the first time this is called after midnight.
 */
export async function getDailyQuote() {
  const today = todayDateString();
  const storedDate = await getItem(KEY_QUOTE_DATE);
  const storedIndexRaw = await getItem(KEY_QUOTE_INDEX);
  const storedIndex = storedIndexRaw !== null ? Number(storedIndexRaw) : null;

  if (storedDate === today && storedIndex !== null && !Number.isNaN(storedIndex)) {
    return QUOTES[storedIndex];
  }

  // New day (or first launch) — pick a fresh random quote.
  // Avoid repeating yesterday's quote back-to-back when possible.
  const newIndex = pickRandomIndex(storedIndex);
  await setItem(KEY_QUOTE_DATE, today);
  await setItem(KEY_QUOTE_INDEX, String(newIndex));
  return QUOTES[newIndex];
}

/**
 * Milliseconds until the next local midnight — useful for scheduling
 * an in-app refresh (e.g. setTimeout) while the app stays open overnight.
 */
export function msUntilNextMidnight(now = new Date()) {
  const next = new Date(now);
  next.setHours(24, 0, 0, 0);
  return next.getTime() - now.getTime();
}

export default { getDailyQuote, msUntilNextMidnight };
