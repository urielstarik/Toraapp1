// src/utils/dateFormat.js
import { HDate } from '@hebcal/core';

const GREGORIAN_MONTHS_HE = [
  'ינואר', 'פברואר', 'מרץ', 'אפריל', 'מאי', 'יוני',
  'יולי', 'אוגוסט', 'ספטמבר', 'אוקטובר', 'נובמבר', 'דצמבר',
];

const WEEKDAYS_HE = [
  'יום ראשון', 'יום שני', 'יום שלישי', 'יום רביעי',
  'יום חמישי', 'יום שישי', 'שבת',
];

/** e.g. "יום שלישי, 5 באוגוסט 2026" */
export function formatGregorianHebrew(date = new Date()) {
  const weekday = WEEKDAYS_HE[date.getDay()];
  const day = date.getDate();
  const month = GREGORIAN_MONTHS_HE[date.getMonth()];
  const year = date.getFullYear();
  return `${weekday}, ${day} ב${month} ${year}`;
}

/** e.g. "כ״א באב תשפ״ו" using the Hebrew (Jewish) calendar */
export function formatHebrewDate(date = new Date()) {
  const hdate = new HDate(date);
  return hdate.render('he');
}

/** Combined string for the dashboard header, Hebrew date first. */
export function formatDualDate(date = new Date()) {
  return {
    hebrew: formatHebrewDate(date),
    gregorian: formatGregorianHebrew(date),
  };
}

export default { formatGregorianHebrew, formatHebrewDate, formatDualDate };
