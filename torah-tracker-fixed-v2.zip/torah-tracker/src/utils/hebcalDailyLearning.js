// src/utils/hebcalDailyLearning.js
//
// Hebcal's calendar API can return various daily-learning tracks (Daf
// Yomi, Mishnah Yomi, Yerushalmi Yomi, etc.) via boolean query flags.
// This is used as a secondary provider (Sefaria is tried first for Daf
// Yomi) and as the primary provider for tracks Sefaria doesn't expose,
// like Mishnah Yomi.

const HEBCAL_BASE = 'https://www.hebcal.com/hebcal';

/**
 * Fetches today's item for a given Hebcal daily-learning flag (e.g.
 * 'ss' for Daf Yomi, 'mf' for Mishnah Yomi) and returns its Hebrew
 * title, or null if not found / the request fails.
 */
export async function fetchHebcalDailyLearning(flag, date = new Date()) {
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();

  const params = new URLSearchParams({
    cfg: 'json',
    v: '1',
    year: String(year),
    month: String(month),
    maj: 'off',
    min: 'off',
    nx: 'off',
    mf: 'off',
    ss: 'off',
    lg: 'h', // Hebrew titles
  });
  params.set(flag, 'on');

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 4000);
    const res = await fetch(`${HEBCAL_BASE}?${params.toString()}`, { signal: controller.signal });
    clearTimeout(timeout);
    if (!res.ok) return null;

    const data = await res.json();
    const todayStr = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const items = data.items || [];
    const match = items.find((item) => item.date?.slice(0, 10) === todayStr);
    return match?.hebrew || match?.title || null;
  } catch (err) {
    return null;
  }
}

export default { fetchHebcalDailyLearning };
