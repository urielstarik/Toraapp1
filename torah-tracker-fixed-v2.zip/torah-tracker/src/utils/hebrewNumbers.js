// src/utils/hebrewNumbers.js
// Masculine cardinal number words (agrees with "לימודים"), for counts
// small enough to plausibly appear as a remaining-tasks count in one day.

const MASCULINE_CARDINALS = {
  1: 'אחד', 2: 'שני', 3: 'שלושה', 4: 'ארבעה', 5: 'חמישה',
  6: 'שישה', 7: 'שבעה', 8: 'שמונה', 9: 'תשעה', 10: 'עשרה',
};

export function hebrewCardinal(n) {
  return MASCULINE_CARDINALS[n] || String(n);
}

export default { hebrewCardinal };
