// src/utils/tehillimCycle.js
//
// The widely-used monthly Tehillim (Psalms) division: 150 chapters split
// across the ~29-30 days of a Hebrew month so the whole book is completed
// every month. Keyed by Hebrew calendar day-of-month (1-30), using the
// Hebrew day rather than the Gregorian one since that's the cycle this
// custom actually follows. On 29-day Hebrew months, day 29 and day 30's
// portions are combined.

import { HDate } from '@hebcal/core';

// day-of-month (1-30) -> [startChapter, endChapter]
const MONTHLY_DIVISION = {
  1: [1, 9], 2: [10, 17], 3: [18, 22], 4: [23, 28], 5: [29, 34],
  6: [35, 38], 7: [39, 43], 8: [44, 48], 9: [49, 54], 10: [55, 59],
  11: [60, 65], 12: [66, 68], 13: [69, 71], 14: [72, 76], 15: [77, 78],
  16: [79, 82], 17: [83, 87], 18: [88, 89], 19: [90, 96], 20: [97, 103],
  21: [104, 105], 22: [106, 107], 23: [108, 112], 24: [113, 118],
  25: [119, 119], // day 25: Psalm 119, first half
  26: [119, 119], // day 26: Psalm 119, second half
  27: [120, 134], 28: [135, 139], 29: [140, 144], 30: [145, 150],
};

function chapterRangeLabel(day, isLastDayOfMonth, monthLength) {
  // 29-day month: fold day 30's portion into day 29 so the book still
  // finishes by the end of the month.
  if (monthLength === 29 && day === 29) {
    return `פרקים ${MONTHLY_DIVISION[29][0]}-${MONTHLY_DIVISION[30][1]}`;
  }
  const [start, end] = MONTHLY_DIVISION[day] || MONTHLY_DIVISION[30];
  if (day === 25) return `פרק קיט (חלק א׳)`;
  if (day === 26) return `פרק קיט (חלק ב׳)`;
  return start === end ? `פרק ${start}` : `פרקים ${start}-${end}`;
}

export function getTehillimLabel(date = new Date()) {
  const hdate = new HDate(date);
  const day = hdate.getDate();
  const monthLength = HDate.daysInMonth(hdate.getMonth(), hdate.getFullYear());
  return chapterRangeLabel(day, day === monthLength, monthLength);
}

export default { getTehillimLabel };
